ShaderGlass - overlay for running GPU shaders over Windows desktop
https://github.com/mausimus/ShaderGlass
https://mausimus.itch.io/shaderglass

Includes RetroArch/libretro shader library
https://github.com/libretro/slang-shaders
