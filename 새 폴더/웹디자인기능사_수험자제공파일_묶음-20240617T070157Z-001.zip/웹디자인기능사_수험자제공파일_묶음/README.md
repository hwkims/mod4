#수험자제공파일 폴더
모든 이미지파일은 pixabay.com에서 무료 이미지를 사용했습니다.

#웹디자인기능사-요구사항-묶음 폴더
큐넷 사이트에서도 다운받을 수 있습니다.
링크 : 
https://www.q-net.or.kr/cst006.do?id=cst00602&gSite=Q&gId=&artlSeq=5199079&brdId=Q006&code=1204