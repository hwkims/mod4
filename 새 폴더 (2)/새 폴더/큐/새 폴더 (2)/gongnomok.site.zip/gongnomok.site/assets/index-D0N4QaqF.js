function e0(e, t) {
    for (var n = 0; n < t.length; n++) {
        const r = t[n];
        if (typeof r != "string" && !Array.isArray(r)) {
            for (const o in r)
                if (o !== "default" && !(o in e)) {
                    const l = Object.getOwnPropertyDescriptor(r, o);
                    l && Object.defineProperty(e, o, l.get ? l : {
                        enumerable: !0,
                        get: () => r[o]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }))
}(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const o of document.querySelectorAll('link[rel="modulepreload"]')) r(o);
    new MutationObserver(o => {
        for (const l of o)
            if (l.type === "childList")
                for (const s of l.addedNodes) s.tagName === "LINK" && s.rel === "modulepreload" && r(s)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(o) {
        const l = {};
        return o.integrity && (l.integrity = o.integrity), o.referrerPolicy && (l.referrerPolicy = o.referrerPolicy), o.crossOrigin === "use-credentials" ? l.credentials = "include" : o.crossOrigin === "anonymous" ? l.credentials = "omit" : l.credentials = "same-origin", l
    }

    function r(o) {
        if (o.ep) return;
        o.ep = !0;
        const l = n(o);
        fetch(o.href, l)
    }
})();

function tp(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var np = {
        exports: {}
    },
    wa = {},
    rp = {
        exports: {}
    },
    fe = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var El = Symbol.for("react.element"),
    t0 = Symbol.for("react.portal"),
    n0 = Symbol.for("react.fragment"),
    r0 = Symbol.for("react.strict_mode"),
    o0 = Symbol.for("react.profiler"),
    l0 = Symbol.for("react.provider"),
    s0 = Symbol.for("react.context"),
    a0 = Symbol.for("react.forward_ref"),
    i0 = Symbol.for("react.suspense"),
    u0 = Symbol.for("react.memo"),
    c0 = Symbol.for("react.lazy"),
    Jd = Symbol.iterator;

function d0(e) {
    return e === null || typeof e != "object" ? null : (e = Jd && e[Jd] || e["@@iterator"], typeof e == "function" ? e : null)
}
var op = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    lp = Object.assign,
    sp = {};

function po(e, t, n) {
    this.props = e, this.context = t, this.refs = sp, this.updater = n || op
}
po.prototype.isReactComponent = {};
po.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
};
po.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function ap() {}
ap.prototype = po.prototype;

function Pc(e, t, n) {
    this.props = e, this.context = t, this.refs = sp, this.updater = n || op
}
var Oc = Pc.prototype = new ap;
Oc.constructor = Pc;
lp(Oc, po.prototype);
Oc.isPureReactComponent = !0;
var Zd = Array.isArray,
    ip = Object.prototype.hasOwnProperty,
    bc = {
        current: null
    },
    up = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function cp(e, t, n) {
    var r, o = {},
        l = null,
        s = null;
    if (t != null)
        for (r in t.ref !== void 0 && (s = t.ref), t.key !== void 0 && (l = "" + t.key), t) ip.call(t, r) && !up.hasOwnProperty(r) && (o[r] = t[r]);
    var i = arguments.length - 2;
    if (i === 1) o.children = n;
    else if (1 < i) {
        for (var u = Array(i), c = 0; c < i; c++) u[c] = arguments[c + 2];
        o.children = u
    }
    if (e && e.defaultProps)
        for (r in i = e.defaultProps, i) o[r] === void 0 && (o[r] = i[r]);
    return {
        $$typeof: El,
        type: e,
        key: l,
        ref: s,
        props: o,
        _owner: bc.current
    }
}

function f0(e, t) {
    return {
        $$typeof: El,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function Ic(e) {
    return typeof e == "object" && e !== null && e.$$typeof === El
}

function m0(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var ef = /\/+/g;

function Pi(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? m0("" + e.key) : t.toString(36)
}

function js(e, t, n, r, o) {
    var l = typeof e;
    (l === "undefined" || l === "boolean") && (e = null);
    var s = !1;
    if (e === null) s = !0;
    else switch (l) {
        case "string":
        case "number":
            s = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case El:
                case t0:
                    s = !0
            }
    }
    if (s) return s = e, o = o(s), e = r === "" ? "." + Pi(s, 0) : r, Zd(o) ? (n = "", e != null && (n = e.replace(ef, "$&/") + "/"), js(o, t, n, "", function(c) {
        return c
    })) : o != null && (Ic(o) && (o = f0(o, n + (!o.key || s && s.key === o.key ? "" : ("" + o.key).replace(ef, "$&/") + "/") + e)), t.push(o)), 1;
    if (s = 0, r = r === "" ? "." : r + ":", Zd(e))
        for (var i = 0; i < e.length; i++) {
            l = e[i];
            var u = r + Pi(l, i);
            s += js(l, t, n, u, o)
        } else if (u = d0(e), typeof u == "function")
            for (e = u.call(e), i = 0; !(l = e.next()).done;) l = l.value, u = r + Pi(l, i++), s += js(l, t, n, u, o);
        else if (l === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return s
}

function es(e, t, n) {
    if (e == null) return e;
    var r = [],
        o = 0;
    return js(e, r, "", "", function(l) {
        return t.call(n, l, o++)
    }), r
}

function p0(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
        }), e._status === -1 && (e._status = 0, e._result = t)
    }
    if (e._status === 1) return e._result.default;
    throw e._result
}
var it = {
        current: null
    },
    Cs = {
        transition: null
    },
    h0 = {
        ReactCurrentDispatcher: it,
        ReactCurrentBatchConfig: Cs,
        ReactCurrentOwner: bc
    };
fe.Children = {
    map: es,
    forEach: function(e, t, n) {
        es(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return es(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return es(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!Ic(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
fe.Component = po;
fe.Fragment = n0;
fe.Profiler = o0;
fe.PureComponent = Pc;
fe.StrictMode = r0;
fe.Suspense = i0;
fe.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = h0;
fe.cloneElement = function(e, t, n) {
    if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = lp({}, e.props),
        o = e.key,
        l = e.ref,
        s = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (l = t.ref, s = bc.current), t.key !== void 0 && (o = "" + t.key), e.type && e.type.defaultProps) var i = e.type.defaultProps;
        for (u in t) ip.call(t, u) && !up.hasOwnProperty(u) && (r[u] = t[u] === void 0 && i !== void 0 ? i[u] : t[u])
    }
    var u = arguments.length - 2;
    if (u === 1) r.children = n;
    else if (1 < u) {
        i = Array(u);
        for (var c = 0; c < u; c++) i[c] = arguments[c + 2];
        r.children = i
    }
    return {
        $$typeof: El,
        type: e.type,
        key: o,
        ref: l,
        props: r,
        _owner: s
    }
};
fe.createContext = function(e) {
    return e = {
        $$typeof: s0,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    }, e.Provider = {
        $$typeof: l0,
        _context: e
    }, e.Consumer = e
};
fe.createElement = cp;
fe.createFactory = function(e) {
    var t = cp.bind(null, e);
    return t.type = e, t
};
fe.createRef = function() {
    return {
        current: null
    }
};
fe.forwardRef = function(e) {
    return {
        $$typeof: a0,
        render: e
    }
};
fe.isValidElement = Ic;
fe.lazy = function(e) {
    return {
        $$typeof: c0,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: p0
    }
};
fe.memo = function(e, t) {
    return {
        $$typeof: u0,
        type: e,
        compare: t === void 0 ? null : t
    }
};
fe.startTransition = function(e) {
    var t = Cs.transition;
    Cs.transition = {};
    try {
        e()
    } finally {
        Cs.transition = t
    }
};
fe.unstable_act = function() {
    throw Error("act(...) is not supported in production builds of React.")
};
fe.useCallback = function(e, t) {
    return it.current.useCallback(e, t)
};
fe.useContext = function(e) {
    return it.current.useContext(e)
};
fe.useDebugValue = function() {};
fe.useDeferredValue = function(e) {
    return it.current.useDeferredValue(e)
};
fe.useEffect = function(e, t) {
    return it.current.useEffect(e, t)
};
fe.useId = function() {
    return it.current.useId()
};
fe.useImperativeHandle = function(e, t, n) {
    return it.current.useImperativeHandle(e, t, n)
};
fe.useInsertionEffect = function(e, t) {
    return it.current.useInsertionEffect(e, t)
};
fe.useLayoutEffect = function(e, t) {
    return it.current.useLayoutEffect(e, t)
};
fe.useMemo = function(e, t) {
    return it.current.useMemo(e, t)
};
fe.useReducer = function(e, t, n) {
    return it.current.useReducer(e, t, n)
};
fe.useRef = function(e) {
    return it.current.useRef(e)
};
fe.useState = function(e) {
    return it.current.useState(e)
};
fe.useSyncExternalStore = function(e, t, n) {
    return it.current.useSyncExternalStore(e, t, n)
};
fe.useTransition = function() {
    return it.current.useTransition()
};
fe.version = "18.2.0";
rp.exports = fe;
var y = rp.exports;
const Ce = tp(y),
    v0 = e0({
        __proto__: null,
        default: Ce
    }, [y]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var g0 = y,
    y0 = Symbol.for("react.element"),
    _0 = Symbol.for("react.fragment"),
    S0 = Object.prototype.hasOwnProperty,
    w0 = g0.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    E0 = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function dp(e, t, n) {
    var r, o = {},
        l = null,
        s = null;
    n !== void 0 && (l = "" + n), t.key !== void 0 && (l = "" + t.key), t.ref !== void 0 && (s = t.ref);
    for (r in t) S0.call(t, r) && !E0.hasOwnProperty(r) && (o[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps, t) o[r] === void 0 && (o[r] = t[r]);
    return {
        $$typeof: y0,
        type: e,
        key: l,
        ref: s,
        props: o,
        _owner: w0.current
    }
}
wa.Fragment = _0;
wa.jsx = dp;
wa.jsxs = dp;
np.exports = wa;
var a = np.exports,
    wu = {},
    fp = {
        exports: {}
    },
    xt = {},
    mp = {
        exports: {}
    },
    pp = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(I, Y) {
        var b = I.length;
        I.push(Y);
        e: for (; 0 < b;) {
            var q = b - 1 >>> 1,
                E = I[q];
            if (0 < o(E, Y)) I[q] = Y, I[b] = E, b = q;
            else break e
        }
    }

    function n(I) {
        return I.length === 0 ? null : I[0]
    }

    function r(I) {
        if (I.length === 0) return null;
        var Y = I[0],
            b = I.pop();
        if (b !== Y) {
            I[0] = b;
            e: for (var q = 0, E = I.length, P = E >>> 1; q < P;) {
                var O = 2 * (q + 1) - 1,
                    Q = I[O],
                    $ = O + 1,
                    ne = I[$];
                if (0 > o(Q, b)) $ < E && 0 > o(ne, Q) ? (I[q] = ne, I[$] = b, q = $) : (I[q] = Q, I[O] = b, q = O);
                else if ($ < E && 0 > o(ne, b)) I[q] = ne, I[$] = b, q = $;
                else break e
            }
        }
        return Y
    }

    function o(I, Y) {
        var b = I.sortIndex - Y.sortIndex;
        return b !== 0 ? b : I.id - Y.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var l = performance;
        e.unstable_now = function() {
            return l.now()
        }
    } else {
        var s = Date,
            i = s.now();
        e.unstable_now = function() {
            return s.now() - i
        }
    }
    var u = [],
        c = [],
        f = 1,
        d = null,
        g = 3,
        S = !1,
        v = !1,
        _ = !1,
        R = typeof setTimeout == "function" ? setTimeout : null,
        p = typeof clearTimeout == "function" ? clearTimeout : null,
        m = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function h(I) {
        for (var Y = n(c); Y !== null;) {
            if (Y.callback === null) r(c);
            else if (Y.startTime <= I) r(c), Y.sortIndex = Y.expirationTime, t(u, Y);
            else break;
            Y = n(c)
        }
    }

    function x(I) {
        if (_ = !1, h(I), !v)
            if (n(u) !== null) v = !0, Re(k);
            else {
                var Y = n(c);
                Y !== null && Ve(x, Y.startTime - I)
            }
    }

    function k(I, Y) {
        v = !1, _ && (_ = !1, p(M), M = -1), S = !0;
        var b = g;
        try {
            for (h(Y), d = n(u); d !== null && (!(d.expirationTime > Y) || I && !ge());) {
                var q = d.callback;
                if (typeof q == "function") {
                    d.callback = null, g = d.priorityLevel;
                    var E = q(d.expirationTime <= Y);
                    Y = e.unstable_now(), typeof E == "function" ? d.callback = E : d === n(u) && r(u), h(Y)
                } else r(u);
                d = n(u)
            }
            if (d !== null) var P = !0;
            else {
                var O = n(c);
                O !== null && Ve(x, O.startTime - Y), P = !1
            }
            return P
        } finally {
            d = null, g = b, S = !1
        }
    }
    var C = !1,
        L = null,
        M = -1,
        oe = 5,
        H = -1;

    function ge() {
        return !(e.unstable_now() - H < oe)
    }

    function Ue() {
        if (L !== null) {
            var I = e.unstable_now();
            H = I;
            var Y = !0;
            try {
                Y = L(!0, I)
            } finally {
                Y ? de() : (C = !1, L = null)
            }
        } else C = !1
    }
    var de;
    if (typeof m == "function") de = function() {
        m(Ue)
    };
    else if (typeof MessageChannel < "u") {
        var Ne = new MessageChannel,
            Xe = Ne.port2;
        Ne.port1.onmessage = Ue, de = function() {
            Xe.postMessage(null)
        }
    } else de = function() {
        R(Ue, 0)
    };

    function Re(I) {
        L = I, C || (C = !0, de())
    }

    function Ve(I, Y) {
        M = R(function() {
            I(e.unstable_now())
        }, Y)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(I) {
        I.callback = null
    }, e.unstable_continueExecution = function() {
        v || S || (v = !0, Re(k))
    }, e.unstable_forceFrameRate = function(I) {
        0 > I || 125 < I ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : oe = 0 < I ? Math.floor(1e3 / I) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
        return g
    }, e.unstable_getFirstCallbackNode = function() {
        return n(u)
    }, e.unstable_next = function(I) {
        switch (g) {
            case 1:
            case 2:
            case 3:
                var Y = 3;
                break;
            default:
                Y = g
        }
        var b = g;
        g = Y;
        try {
            return I()
        } finally {
            g = b
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(I, Y) {
        switch (I) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                I = 3
        }
        var b = g;
        g = I;
        try {
            return Y()
        } finally {
            g = b
        }
    }, e.unstable_scheduleCallback = function(I, Y, b) {
        var q = e.unstable_now();
        switch (typeof b == "object" && b !== null ? (b = b.delay, b = typeof b == "number" && 0 < b ? q + b : q) : b = q, I) {
            case 1:
                var E = -1;
                break;
            case 2:
                E = 250;
                break;
            case 5:
                E = 1073741823;
                break;
            case 4:
                E = 1e4;
                break;
            default:
                E = 5e3
        }
        return E = b + E, I = {
            id: f++,
            callback: Y,
            priorityLevel: I,
            startTime: b,
            expirationTime: E,
            sortIndex: -1
        }, b > q ? (I.sortIndex = b, t(c, I), n(u) === null && I === n(c) && (_ ? (p(M), M = -1) : _ = !0, Ve(x, b - q))) : (I.sortIndex = E, t(u, I), v || S || (v = !0, Re(k))), I
    }, e.unstable_shouldYield = ge, e.unstable_wrapCallback = function(I) {
        var Y = g;
        return function() {
            var b = g;
            g = Y;
            try {
                return I.apply(this, arguments)
            } finally {
                g = b
            }
        }
    }
})(pp);
mp.exports = pp;
var x0 = mp.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hp = y,
    Et = x0;

function D(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var vp = new Set,
    nl = {};

function wr(e, t) {
    eo(e, t), eo(e + "Capture", t)
}

function eo(e, t) {
    for (nl[e] = t, e = 0; e < t.length; e++) vp.add(t[e])
}
var mn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
    Eu = Object.prototype.hasOwnProperty,
    N0 = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    tf = {},
    nf = {};

function R0(e) {
    return Eu.call(nf, e) ? !0 : Eu.call(tf, e) ? !1 : N0.test(e) ? nf[e] = !0 : (tf[e] = !0, !1)
}

function k0(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function A0(e, t, n, r) {
    if (t === null || typeof t > "u" || k0(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function ut(e, t, n, r, o, l, s) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = o, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = l, this.removeEmptyString = s
}
var tt = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    tt[e] = new ut(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    tt[t] = new ut(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    tt[e] = new ut(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    tt[e] = new ut(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    tt[e] = new ut(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    tt[e] = new ut(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    tt[e] = new ut(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    tt[e] = new ut(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    tt[e] = new ut(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var Mc = /[\-:]([a-z])/g;

function Uc(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Mc, Uc);
    tt[t] = new ut(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Mc, Uc);
    tt[t] = new ut(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(Mc, Uc);
    tt[t] = new ut(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    tt[e] = new ut(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
tt.xlinkHref = new ut("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    tt[e] = new ut(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function Fc(e, t, n, r) {
    var o = tt.hasOwnProperty(t) ? tt[t] : null;
    (o !== null ? o.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (A0(t, n, o, r) && (n = null), r || o === null ? R0(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : o.mustUseProperty ? e[o.propertyName] = n === null ? o.type === 3 ? !1 : "" : n : (t = o.attributeName, r = o.attributeNamespace, n === null ? e.removeAttribute(t) : (o = o.type, n = o === 3 || o === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var gn = hp.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    ts = Symbol.for("react.element"),
    br = Symbol.for("react.portal"),
    Ir = Symbol.for("react.fragment"),
    Vc = Symbol.for("react.strict_mode"),
    xu = Symbol.for("react.profiler"),
    gp = Symbol.for("react.provider"),
    yp = Symbol.for("react.context"),
    $c = Symbol.for("react.forward_ref"),
    Nu = Symbol.for("react.suspense"),
    Ru = Symbol.for("react.suspense_list"),
    Hc = Symbol.for("react.memo"),
    jn = Symbol.for("react.lazy"),
    _p = Symbol.for("react.offscreen"),
    rf = Symbol.iterator;

function xo(e) {
    return e === null || typeof e != "object" ? null : (e = rf && e[rf] || e["@@iterator"], typeof e == "function" ? e : null)
}
var Me = Object.assign,
    Oi;

function Fo(e) {
    if (Oi === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        Oi = t && t[1] || ""
    }
    return `
` + Oi + e
}
var bi = !1;

function Ii(e, t) {
    if (!e || bi) return "";
    bi = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (c) {
                    var r = c
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (c) {
                    r = c
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (c) {
                r = c
            }
            e()
        }
    } catch (c) {
        if (c && r && typeof c.stack == "string") {
            for (var o = c.stack.split(`
`), l = r.stack.split(`
`), s = o.length - 1, i = l.length - 1; 1 <= s && 0 <= i && o[s] !== l[i];) i--;
            for (; 1 <= s && 0 <= i; s--, i--)
                if (o[s] !== l[i]) {
                    if (s !== 1 || i !== 1)
                        do
                            if (s--, i--, 0 > i || o[s] !== l[i]) {
                                var u = `
` + o[s].replace(" at new ", " at ");
                                return e.displayName && u.includes("<anonymous>") && (u = u.replace("<anonymous>", e.displayName)), u
                            }
                    while (1 <= s && 0 <= i);
                    break
                }
        }
    } finally {
        bi = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Fo(e) : ""
}

function T0(e) {
    switch (e.tag) {
        case 5:
            return Fo(e.type);
        case 16:
            return Fo("Lazy");
        case 13:
            return Fo("Suspense");
        case 19:
            return Fo("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = Ii(e.type, !1), e;
        case 11:
            return e = Ii(e.type.render, !1), e;
        case 1:
            return e = Ii(e.type, !0), e;
        default:
            return ""
    }
}

function ku(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case Ir:
            return "Fragment";
        case br:
            return "Portal";
        case xu:
            return "Profiler";
        case Vc:
            return "StrictMode";
        case Nu:
            return "Suspense";
        case Ru:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case yp:
            return (e.displayName || "Context") + ".Consumer";
        case gp:
            return (e._context.displayName || "Context") + ".Provider";
        case $c:
            var t = e.render;
            return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Hc:
            return t = e.displayName || null, t !== null ? t : ku(e.type) || "Memo";
        case jn:
            t = e._payload, e = e._init;
            try {
                return ku(e(t))
            } catch {}
    }
    return null
}

function j0(e) {
    var t = e.type;
    switch (e.tag) {
        case 24:
            return "Cache";
        case 9:
            return (t.displayName || "Context") + ".Consumer";
        case 10:
            return (t._context.displayName || "Context") + ".Provider";
        case 18:
            return "DehydratedFragment";
        case 11:
            return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
        case 7:
            return "Fragment";
        case 5:
            return t;
        case 4:
            return "Portal";
        case 3:
            return "Root";
        case 6:
            return "Text";
        case 16:
            return ku(t);
        case 8:
            return t === Vc ? "StrictMode" : "Mode";
        case 22:
            return "Offscreen";
        case 12:
            return "Profiler";
        case 21:
            return "Scope";
        case 13:
            return "Suspense";
        case 19:
            return "SuspenseList";
        case 25:
            return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
            if (typeof t == "function") return t.displayName || t.name || null;
            if (typeof t == "string") return t
    }
    return null
}

function Gn(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
            return e;
        case "object":
            return e;
        default:
            return ""
    }
}

function Sp(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function C0(e) {
    var t = Sp(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var o = n.get,
            l = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return o.call(this)
            },
            set: function(s) {
                r = "" + s, l.call(this, s)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(s) {
                r = "" + s
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function ns(e) {
    e._valueTracker || (e._valueTracker = C0(e))
}

function wp(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = Sp(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Ws(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function Au(e, t) {
    var n = t.checked;
    return Me({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ? ? e._wrapperState.initialChecked
    })
}

function of (e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = Gn(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function Ep(e, t) {
    t = t.checked, t != null && Fc(e, "checked", t, !1)
}

function Tu(e, t) {
    Ep(e, t);
    var n = Gn(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? ju(e, t.type, n) : t.hasOwnProperty("defaultValue") && ju(e, t.type, Gn(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function lf(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function ju(e, t, n) {
    (t !== "number" || Ws(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Vo = Array.isArray;

function Gr(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
        for (n = 0; n < e.length; n++) o = t.hasOwnProperty("$" + e[n].value), e[n].selected !== o && (e[n].selected = o), o && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + Gn(n), t = null, o = 0; o < e.length; o++) {
            if (e[o].value === n) {
                e[o].selected = !0, r && (e[o].defaultSelected = !0);
                return
            }
            t !== null || e[o].disabled || (t = e[o])
        }
        t !== null && (t.selected = !0)
    }
}

function Cu(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(D(91));
    return Me({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function sf(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(D(92));
            if (Vo(n)) {
                if (1 < n.length) throw Error(D(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: Gn(n)
    }
}

function xp(e, t) {
    var n = Gn(t.value),
        r = Gn(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function af(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function Np(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function Lu(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? Np(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var rs, Rp = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, o) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, o)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
    else {
        for (rs = rs || document.createElement("div"), rs.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = rs.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function rl(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var zo = {
        animationIterationCount: !0,
        aspectRatio: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    L0 = ["Webkit", "ms", "Moz", "O"];
Object.keys(zo).forEach(function(e) {
    L0.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), zo[t] = zo[e]
    })
});

function kp(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || zo.hasOwnProperty(e) && zo[e] ? ("" + t).trim() : t + "px"
}

function Ap(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                o = kp(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, o) : e[n] = o
        }
}
var D0 = Me({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function Du(e, t) {
    if (t) {
        if (D0[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(D(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(D(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(D(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(D(62))
    }
}

function Pu(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}
var Ou = null;

function Bc(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var bu = null,
    qr = null,
    Yr = null;

function uf(e) {
    if (e = Rl(e)) {
        if (typeof bu != "function") throw Error(D(280));
        var t = e.stateNode;
        t && (t = ka(t), bu(e.stateNode, e.type, t))
    }
}

function Tp(e) {
    qr ? Yr ? Yr.push(e) : Yr = [e] : qr = e
}

function jp() {
    if (qr) {
        var e = qr,
            t = Yr;
        if (Yr = qr = null, uf(e), t)
            for (e = 0; e < t.length; e++) uf(t[e])
    }
}

function Cp(e, t) {
    return e(t)
}

function Lp() {}
var Mi = !1;

function Dp(e, t, n) {
    if (Mi) return e(t, n);
    Mi = !0;
    try {
        return Cp(e, t, n)
    } finally {
        Mi = !1, (qr !== null || Yr !== null) && (Lp(), jp())
    }
}

function ol(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = ka(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(D(231, t, typeof n));
    return n
}
var Iu = !1;
if (mn) try {
    var No = {};
    Object.defineProperty(No, "passive", {
        get: function() {
            Iu = !0
        }
    }), window.addEventListener("test", No, No), window.removeEventListener("test", No, No)
} catch {
    Iu = !1
}

function P0(e, t, n, r, o, l, s, i, u) {
    var c = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, c)
    } catch (f) {
        this.onError(f)
    }
}
var Wo = !1,
    Ks = null,
    Gs = !1,
    Mu = null,
    O0 = {
        onError: function(e) {
            Wo = !0, Ks = e
        }
    };

function b0(e, t, n, r, o, l, s, i, u) {
    Wo = !1, Ks = null, P0.apply(O0, arguments)
}

function I0(e, t, n, r, o, l, s, i, u) {
    if (b0.apply(this, arguments), Wo) {
        if (Wo) {
            var c = Ks;
            Wo = !1, Ks = null
        } else throw Error(D(198));
        Gs || (Gs = !0, Mu = c)
    }
}

function Er(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function Pp(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function cf(e) {
    if (Er(e) !== e) throw Error(D(188))
}

function M0(e) {
    var t = e.alternate;
    if (!t) {
        if (t = Er(e), t === null) throw Error(D(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var o = n.return;
        if (o === null) break;
        var l = o.alternate;
        if (l === null) {
            if (r = o.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (o.child === l.child) {
            for (l = o.child; l;) {
                if (l === n) return cf(o), e;
                if (l === r) return cf(o), t;
                l = l.sibling
            }
            throw Error(D(188))
        }
        if (n.return !== r.return) n = o, r = l;
        else {
            for (var s = !1, i = o.child; i;) {
                if (i === n) {
                    s = !0, n = o, r = l;
                    break
                }
                if (i === r) {
                    s = !0, r = o, n = l;
                    break
                }
                i = i.sibling
            }
            if (!s) {
                for (i = l.child; i;) {
                    if (i === n) {
                        s = !0, n = l, r = o;
                        break
                    }
                    if (i === r) {
                        s = !0, r = l, n = o;
                        break
                    }
                    i = i.sibling
                }
                if (!s) throw Error(D(189))
            }
        }
        if (n.alternate !== r) throw Error(D(190))
    }
    if (n.tag !== 3) throw Error(D(188));
    return n.stateNode.current === n ? e : t
}

function Op(e) {
    return e = M0(e), e !== null ? bp(e) : null
}

function bp(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
        var t = bp(e);
        if (t !== null) return t;
        e = e.sibling
    }
    return null
}
var Ip = Et.unstable_scheduleCallback,
    df = Et.unstable_cancelCallback,
    U0 = Et.unstable_shouldYield,
    F0 = Et.unstable_requestPaint,
    He = Et.unstable_now,
    V0 = Et.unstable_getCurrentPriorityLevel,
    zc = Et.unstable_ImmediatePriority,
    Mp = Et.unstable_UserBlockingPriority,
    qs = Et.unstable_NormalPriority,
    $0 = Et.unstable_LowPriority,
    Up = Et.unstable_IdlePriority,
    Ea = null,
    Jt = null;

function H0(e) {
    if (Jt && typeof Jt.onCommitFiberRoot == "function") try {
        Jt.onCommitFiberRoot(Ea, e, void 0, (e.current.flags & 128) === 128)
    } catch {}
}
var Bt = Math.clz32 ? Math.clz32 : W0,
    B0 = Math.log,
    z0 = Math.LN2;

function W0(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (B0(e) / z0 | 0) | 0
}
var os = 64,
    ls = 4194304;

function $o(e) {
    switch (e & -e) {
        case 1:
            return 1;
        case 2:
            return 2;
        case 4:
            return 4;
        case 8:
            return 8;
        case 16:
            return 16;
        case 32:
            return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return e & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return e & 130023424;
        case 134217728:
            return 134217728;
        case 268435456:
            return 268435456;
        case 536870912:
            return 536870912;
        case 1073741824:
            return 1073741824;
        default:
            return e
    }
}

function Ys(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
        o = e.suspendedLanes,
        l = e.pingedLanes,
        s = n & 268435455;
    if (s !== 0) {
        var i = s & ~o;
        i !== 0 ? r = $o(i) : (l &= s, l !== 0 && (r = $o(l)))
    } else s = n & ~o, s !== 0 ? r = $o(s) : l !== 0 && (r = $o(l));
    if (r === 0) return 0;
    if (t !== 0 && t !== r && !(t & o) && (o = r & -r, l = t & -t, o >= l || o === 16 && (l & 4194240) !== 0)) return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - Bt(t), o = 1 << n, r |= e[n], t &= ~o;
    return r
}

function K0(e, t) {
    switch (e) {
        case 1:
        case 2:
        case 4:
            return t + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
            return -1;
        default:
            return -1
    }
}

function G0(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, o = e.expirationTimes, l = e.pendingLanes; 0 < l;) {
        var s = 31 - Bt(l),
            i = 1 << s,
            u = o[s];
        u === -1 ? (!(i & n) || i & r) && (o[s] = K0(i, t)) : u <= t && (e.expiredLanes |= i), l &= ~i
    }
}

function Uu(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function Fp() {
    var e = os;
    return os <<= 1, !(os & 4194240) && (os = 64), e
}

function Ui(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function xl(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Bt(t), e[t] = n
}

function q0(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
        var o = 31 - Bt(n),
            l = 1 << o;
        t[o] = 0, r[o] = -1, e[o] = -1, n &= ~l
    }
}

function Wc(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n;) {
        var r = 31 - Bt(n),
            o = 1 << r;
        o & t | e[r] & t && (e[r] |= t), n &= ~o
    }
}
var we = 0;

function Vp(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var $p, Kc, Hp, Bp, zp, Fu = !1,
    ss = [],
    Fn = null,
    Vn = null,
    $n = null,
    ll = new Map,
    sl = new Map,
    Dn = [],
    Y0 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function ff(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            Fn = null;
            break;
        case "dragenter":
        case "dragleave":
            Vn = null;
            break;
        case "mouseover":
        case "mouseout":
            $n = null;
            break;
        case "pointerover":
        case "pointerout":
            ll.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            sl.delete(t.pointerId)
    }
}

function Ro(e, t, n, r, o, l) {
    return e === null || e.nativeEvent !== l ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: l,
        targetContainers: [o]
    }, t !== null && (t = Rl(t), t !== null && Kc(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, o !== null && t.indexOf(o) === -1 && t.push(o), e)
}

function Q0(e, t, n, r, o) {
    switch (t) {
        case "focusin":
            return Fn = Ro(Fn, e, t, n, r, o), !0;
        case "dragenter":
            return Vn = Ro(Vn, e, t, n, r, o), !0;
        case "mouseover":
            return $n = Ro($n, e, t, n, r, o), !0;
        case "pointerover":
            var l = o.pointerId;
            return ll.set(l, Ro(ll.get(l) || null, e, t, n, r, o)), !0;
        case "gotpointercapture":
            return l = o.pointerId, sl.set(l, Ro(sl.get(l) || null, e, t, n, r, o)), !0
    }
    return !1
}

function Wp(e) {
    var t = ar(e.target);
    if (t !== null) {
        var n = Er(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = Pp(n), t !== null) {
                    e.blockedOn = t, zp(e.priority, function() {
                        Hp(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function Ls(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = Vu(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type, n);
            Ou = r, n.target.dispatchEvent(r), Ou = null
        } else return t = Rl(n), t !== null && Kc(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function mf(e, t, n) {
    Ls(e) && n.delete(t)
}

function X0() {
    Fu = !1, Fn !== null && Ls(Fn) && (Fn = null), Vn !== null && Ls(Vn) && (Vn = null), $n !== null && Ls($n) && ($n = null), ll.forEach(mf), sl.forEach(mf)
}

function ko(e, t) {
    e.blockedOn === t && (e.blockedOn = null, Fu || (Fu = !0, Et.unstable_scheduleCallback(Et.unstable_NormalPriority, X0)))
}

function al(e) {
    function t(o) {
        return ko(o, e)
    }
    if (0 < ss.length) {
        ko(ss[0], e);
        for (var n = 1; n < ss.length; n++) {
            var r = ss[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (Fn !== null && ko(Fn, e), Vn !== null && ko(Vn, e), $n !== null && ko($n, e), ll.forEach(t), sl.forEach(t), n = 0; n < Dn.length; n++) r = Dn[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < Dn.length && (n = Dn[0], n.blockedOn === null);) Wp(n), n.blockedOn === null && Dn.shift()
}
var Qr = gn.ReactCurrentBatchConfig,
    Qs = !0;

function J0(e, t, n, r) {
    var o = we,
        l = Qr.transition;
    Qr.transition = null;
    try {
        we = 1, Gc(e, t, n, r)
    } finally {
        we = o, Qr.transition = l
    }
}

function Z0(e, t, n, r) {
    var o = we,
        l = Qr.transition;
    Qr.transition = null;
    try {
        we = 4, Gc(e, t, n, r)
    } finally {
        we = o, Qr.transition = l
    }
}

function Gc(e, t, n, r) {
    if (Qs) {
        var o = Vu(e, t, n, r);
        if (o === null) qi(e, t, r, Xs, n), ff(e, r);
        else if (Q0(o, e, t, n, r)) r.stopPropagation();
        else if (ff(e, r), t & 4 && -1 < Y0.indexOf(e)) {
            for (; o !== null;) {
                var l = Rl(o);
                if (l !== null && $p(l), l = Vu(e, t, n, r), l === null && qi(e, t, r, Xs, n), l === o) break;
                o = l
            }
            o !== null && r.stopPropagation()
        } else qi(e, t, r, null, n)
    }
}
var Xs = null;

function Vu(e, t, n, r) {
    if (Xs = null, e = Bc(r), e = ar(e), e !== null)
        if (t = Er(e), t === null) e = null;
        else if (n = t.tag, n === 13) {
        if (e = Pp(t), e !== null) return e;
        e = null
    } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null
    } else t !== e && (e = null);
    return Xs = e, null
}

function Kp(e) {
    switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
            return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
            return 4;
        case "message":
            switch (V0()) {
                case zc:
                    return 1;
                case Mp:
                    return 4;
                case qs:
                case $0:
                    return 16;
                case Up:
                    return 536870912;
                default:
                    return 16
            }
        default:
            return 16
    }
}
var On = null,
    qc = null,
    Ds = null;

function Gp() {
    if (Ds) return Ds;
    var e, t = qc,
        n = t.length,
        r, o = "value" in On ? On.value : On.textContent,
        l = o.length;
    for (e = 0; e < n && t[e] === o[e]; e++);
    var s = n - e;
    for (r = 1; r <= s && t[n - r] === o[l - r]; r++);
    return Ds = o.slice(e, 1 < r ? 1 - r : void 0)
}

function Ps(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function as() {
    return !0
}

function pf() {
    return !1
}

function Nt(e) {
    function t(n, r, o, l, s) {
        this._reactName = n, this._targetInst = o, this.type = r, this.nativeEvent = l, this.target = s, this.currentTarget = null;
        for (var i in e) e.hasOwnProperty(i) && (n = e[i], this[i] = n ? n(l) : l[i]);
        return this.isDefaultPrevented = (l.defaultPrevented != null ? l.defaultPrevented : l.returnValue === !1) ? as : pf, this.isPropagationStopped = pf, this
    }
    return Me(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = as)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = as)
        },
        persist: function() {},
        isPersistent: as
    }), t
}
var ho = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    Yc = Nt(ho),
    Nl = Me({}, ho, {
        view: 0,
        detail: 0
    }),
    e_ = Nt(Nl),
    Fi, Vi, Ao, xa = Me({}, Nl, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: Qc,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== Ao && (Ao && e.type === "mousemove" ? (Fi = e.screenX - Ao.screenX, Vi = e.screenY - Ao.screenY) : Vi = Fi = 0, Ao = e), Fi)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : Vi
        }
    }),
    hf = Nt(xa),
    t_ = Me({}, xa, {
        dataTransfer: 0
    }),
    n_ = Nt(t_),
    r_ = Me({}, Nl, {
        relatedTarget: 0
    }),
    $i = Nt(r_),
    o_ = Me({}, ho, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    l_ = Nt(o_),
    s_ = Me({}, ho, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    a_ = Nt(s_),
    i_ = Me({}, ho, {
        data: 0
    }),
    vf = Nt(i_),
    u_ = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    c_ = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    d_ = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function f_(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = d_[e]) ? !!t[e] : !1
}

function Qc() {
    return f_
}
var m_ = Me({}, Nl, {
        key: function(e) {
            if (e.key) {
                var t = u_[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = Ps(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? c_[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: Qc,
        charCode: function(e) {
            return e.type === "keypress" ? Ps(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? Ps(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    p_ = Nt(m_),
    h_ = Me({}, xa, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    gf = Nt(h_),
    v_ = Me({}, Nl, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: Qc
    }),
    g_ = Nt(v_),
    y_ = Me({}, ho, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    __ = Nt(y_),
    S_ = Me({}, xa, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    w_ = Nt(S_),
    E_ = [9, 13, 27, 32],
    Xc = mn && "CompositionEvent" in window,
    Ko = null;
mn && "documentMode" in document && (Ko = document.documentMode);
var x_ = mn && "TextEvent" in window && !Ko,
    qp = mn && (!Xc || Ko && 8 < Ko && 11 >= Ko),
    yf = " ",
    _f = !1;

function Yp(e, t) {
    switch (e) {
        case "keyup":
            return E_.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function Qp(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var Mr = !1;

function N_(e, t) {
    switch (e) {
        case "compositionend":
            return Qp(t);
        case "keypress":
            return t.which !== 32 ? null : (_f = !0, yf);
        case "textInput":
            return e = t.data, e === yf && _f ? null : e;
        default:
            return null
    }
}

function R_(e, t) {
    if (Mr) return e === "compositionend" || !Xc && Yp(e, t) ? (e = Gp(), Ds = qc = On = null, Mr = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return qp && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var k_ = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function Sf(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!k_[e.type] : t === "textarea"
}

function Xp(e, t, n, r) {
    Tp(r), t = Js(t, "onChange"), 0 < t.length && (n = new Yc("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var Go = null,
    il = null;

function A_(e) {
    ih(e, 0)
}

function Na(e) {
    var t = Vr(e);
    if (wp(t)) return e
}

function T_(e, t) {
    if (e === "change") return t
}
var Jp = !1;
if (mn) {
    var Hi;
    if (mn) {
        var Bi = "oninput" in document;
        if (!Bi) {
            var wf = document.createElement("div");
            wf.setAttribute("oninput", "return;"), Bi = typeof wf.oninput == "function"
        }
        Hi = Bi
    } else Hi = !1;
    Jp = Hi && (!document.documentMode || 9 < document.documentMode)
}

function Ef() {
    Go && (Go.detachEvent("onpropertychange", Zp), il = Go = null)
}

function Zp(e) {
    if (e.propertyName === "value" && Na(il)) {
        var t = [];
        Xp(t, il, e, Bc(e)), Dp(A_, t)
    }
}

function j_(e, t, n) {
    e === "focusin" ? (Ef(), Go = t, il = n, Go.attachEvent("onpropertychange", Zp)) : e === "focusout" && Ef()
}

function C_(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return Na(il)
}

function L_(e, t) {
    if (e === "click") return Na(t)
}

function D_(e, t) {
    if (e === "input" || e === "change") return Na(t)
}

function P_(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var Wt = typeof Object.is == "function" ? Object.is : P_;

function ul(e, t) {
    if (Wt(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
        var o = n[r];
        if (!Eu.call(t, o) || !Wt(e[o], t[o])) return !1
    }
    return !0
}

function xf(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function Nf(e, t) {
    var n = xf(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = xf(n)
    }
}

function eh(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? eh(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function th() {
    for (var e = window, t = Ws(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Ws(e.document)
    }
    return t
}

function Jc(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}

function O_(e) {
    var t = th(),
        n = e.focusedElem,
        r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && eh(n.ownerDocument.documentElement, n)) {
        if (r !== null && Jc(n)) {
            if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                e = e.getSelection();
                var o = n.textContent.length,
                    l = Math.min(r.start, o);
                r = r.end === void 0 ? l : Math.min(r.end, o), !e.extend && l > r && (o = r, r = l, l = o), o = Nf(n, l);
                var s = Nf(n, r);
                o && s && (e.rangeCount !== 1 || e.anchorNode !== o.node || e.anchorOffset !== o.offset || e.focusNode !== s.node || e.focusOffset !== s.offset) && (t = t.createRange(), t.setStart(o.node, o.offset), e.removeAllRanges(), l > r ? (e.addRange(t), e.extend(s.node, s.offset)) : (t.setEnd(s.node, s.offset), e.addRange(t)))
            }
        }
        for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
            element: e,
            left: e.scrollLeft,
            top: e.scrollTop
        });
        for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
    }
}
var b_ = mn && "documentMode" in document && 11 >= document.documentMode,
    Ur = null,
    $u = null,
    qo = null,
    Hu = !1;

function Rf(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Hu || Ur == null || Ur !== Ws(r) || (r = Ur, "selectionStart" in r && Jc(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), qo && ul(qo, r) || (qo = r, r = Js($u, "onSelect"), 0 < r.length && (t = new Yc("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = Ur)))
}

function is(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var Fr = {
        animationend: is("Animation", "AnimationEnd"),
        animationiteration: is("Animation", "AnimationIteration"),
        animationstart: is("Animation", "AnimationStart"),
        transitionend: is("Transition", "TransitionEnd")
    },
    zi = {},
    nh = {};
mn && (nh = document.createElement("div").style, "AnimationEvent" in window || (delete Fr.animationend.animation, delete Fr.animationiteration.animation, delete Fr.animationstart.animation), "TransitionEvent" in window || delete Fr.transitionend.transition);

function Ra(e) {
    if (zi[e]) return zi[e];
    if (!Fr[e]) return e;
    var t = Fr[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in nh) return zi[e] = t[n];
    return e
}
var rh = Ra("animationend"),
    oh = Ra("animationiteration"),
    lh = Ra("animationstart"),
    sh = Ra("transitionend"),
    ah = new Map,
    kf = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function Yn(e, t) {
    ah.set(e, t), wr(t, [e])
}
for (var Wi = 0; Wi < kf.length; Wi++) {
    var Ki = kf[Wi],
        I_ = Ki.toLowerCase(),
        M_ = Ki[0].toUpperCase() + Ki.slice(1);
    Yn(I_, "on" + M_)
}
Yn(rh, "onAnimationEnd");
Yn(oh, "onAnimationIteration");
Yn(lh, "onAnimationStart");
Yn("dblclick", "onDoubleClick");
Yn("focusin", "onFocus");
Yn("focusout", "onBlur");
Yn(sh, "onTransitionEnd");
eo("onMouseEnter", ["mouseout", "mouseover"]);
eo("onMouseLeave", ["mouseout", "mouseover"]);
eo("onPointerEnter", ["pointerout", "pointerover"]);
eo("onPointerLeave", ["pointerout", "pointerover"]);
wr("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
wr("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
wr("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
wr("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
wr("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
wr("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Ho = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    U_ = new Set("cancel close invalid load scroll toggle".split(" ").concat(Ho));

function Af(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, I0(r, t, void 0, e), e.currentTarget = null
}

function ih(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            o = r.event;
        r = r.listeners;
        e: {
            var l = void 0;
            if (t)
                for (var s = r.length - 1; 0 <= s; s--) {
                    var i = r[s],
                        u = i.instance,
                        c = i.currentTarget;
                    if (i = i.listener, u !== l && o.isPropagationStopped()) break e;
                    Af(o, i, c), l = u
                } else
                    for (s = 0; s < r.length; s++) {
                        if (i = r[s], u = i.instance, c = i.currentTarget, i = i.listener, u !== l && o.isPropagationStopped()) break e;
                        Af(o, i, c), l = u
                    }
        }
    }
    if (Gs) throw e = Mu, Gs = !1, Mu = null, e
}

function Ae(e, t) {
    var n = t[Gu];
    n === void 0 && (n = t[Gu] = new Set);
    var r = e + "__bubble";
    n.has(r) || (uh(t, e, 2, !1), n.add(r))
}

function Gi(e, t, n) {
    var r = 0;
    t && (r |= 4), uh(n, e, r, t)
}
var us = "_reactListening" + Math.random().toString(36).slice(2);

function cl(e) {
    if (!e[us]) {
        e[us] = !0, vp.forEach(function(n) {
            n !== "selectionchange" && (U_.has(n) || Gi(n, !1, e), Gi(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[us] || (t[us] = !0, Gi("selectionchange", !1, t))
    }
}

function uh(e, t, n, r) {
    switch (Kp(t)) {
        case 1:
            var o = J0;
            break;
        case 4:
            o = Z0;
            break;
        default:
            o = Gc
    }
    n = o.bind(null, t, n, e), o = void 0, !Iu || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (o = !0), r ? o !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: o
    }) : e.addEventListener(t, n, !0) : o !== void 0 ? e.addEventListener(t, n, {
        passive: o
    }) : e.addEventListener(t, n, !1)
}

function qi(e, t, n, r, o) {
    var l = r;
    if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
        if (r === null) return;
        var s = r.tag;
        if (s === 3 || s === 4) {
            var i = r.stateNode.containerInfo;
            if (i === o || i.nodeType === 8 && i.parentNode === o) break;
            if (s === 4)
                for (s = r.return; s !== null;) {
                    var u = s.tag;
                    if ((u === 3 || u === 4) && (u = s.stateNode.containerInfo, u === o || u.nodeType === 8 && u.parentNode === o)) return;
                    s = s.return
                }
            for (; i !== null;) {
                if (s = ar(i), s === null) return;
                if (u = s.tag, u === 5 || u === 6) {
                    r = l = s;
                    continue e
                }
                i = i.parentNode
            }
        }
        r = r.return
    }
    Dp(function() {
        var c = l,
            f = Bc(n),
            d = [];
        e: {
            var g = ah.get(e);
            if (g !== void 0) {
                var S = Yc,
                    v = e;
                switch (e) {
                    case "keypress":
                        if (Ps(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        S = p_;
                        break;
                    case "focusin":
                        v = "focus", S = $i;
                        break;
                    case "focusout":
                        v = "blur", S = $i;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        S = $i;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        S = hf;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        S = n_;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        S = g_;
                        break;
                    case rh:
                    case oh:
                    case lh:
                        S = l_;
                        break;
                    case sh:
                        S = __;
                        break;
                    case "scroll":
                        S = e_;
                        break;
                    case "wheel":
                        S = w_;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        S = a_;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        S = gf
                }
                var _ = (t & 4) !== 0,
                    R = !_ && e === "scroll",
                    p = _ ? g !== null ? g + "Capture" : null : g;
                _ = [];
                for (var m = c, h; m !== null;) {
                    h = m;
                    var x = h.stateNode;
                    if (h.tag === 5 && x !== null && (h = x, p !== null && (x = ol(m, p), x != null && _.push(dl(m, x, h)))), R) break;
                    m = m.return
                }
                0 < _.length && (g = new S(g, v, null, n, f), d.push({
                    event: g,
                    listeners: _
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (g = e === "mouseover" || e === "pointerover", S = e === "mouseout" || e === "pointerout", g && n !== Ou && (v = n.relatedTarget || n.fromElement) && (ar(v) || v[pn])) break e;
                if ((S || g) && (g = f.window === f ? f : (g = f.ownerDocument) ? g.defaultView || g.parentWindow : window, S ? (v = n.relatedTarget || n.toElement, S = c, v = v ? ar(v) : null, v !== null && (R = Er(v), v !== R || v.tag !== 5 && v.tag !== 6) && (v = null)) : (S = null, v = c), S !== v)) {
                    if (_ = hf, x = "onMouseLeave", p = "onMouseEnter", m = "mouse", (e === "pointerout" || e === "pointerover") && (_ = gf, x = "onPointerLeave", p = "onPointerEnter", m = "pointer"), R = S == null ? g : Vr(S), h = v == null ? g : Vr(v), g = new _(x, m + "leave", S, n, f), g.target = R, g.relatedTarget = h, x = null, ar(f) === c && (_ = new _(p, m + "enter", v, n, f), _.target = h, _.relatedTarget = R, x = _), R = x, S && v) t: {
                        for (_ = S, p = v, m = 0, h = _; h; h = Dr(h)) m++;
                        for (h = 0, x = p; x; x = Dr(x)) h++;
                        for (; 0 < m - h;) _ = Dr(_),
                        m--;
                        for (; 0 < h - m;) p = Dr(p),
                        h--;
                        for (; m--;) {
                            if (_ === p || p !== null && _ === p.alternate) break t;
                            _ = Dr(_), p = Dr(p)
                        }
                        _ = null
                    }
                    else _ = null;
                    S !== null && Tf(d, g, S, _, !1), v !== null && R !== null && Tf(d, R, v, _, !0)
                }
            }
            e: {
                if (g = c ? Vr(c) : window, S = g.nodeName && g.nodeName.toLowerCase(), S === "select" || S === "input" && g.type === "file") var k = T_;
                else if (Sf(g))
                    if (Jp) k = D_;
                    else {
                        k = C_;
                        var C = j_
                    }
                else(S = g.nodeName) && S.toLowerCase() === "input" && (g.type === "checkbox" || g.type === "radio") && (k = L_);
                if (k && (k = k(e, c))) {
                    Xp(d, k, n, f);
                    break e
                }
                C && C(e, g, c),
                e === "focusout" && (C = g._wrapperState) && C.controlled && g.type === "number" && ju(g, "number", g.value)
            }
            switch (C = c ? Vr(c) : window, e) {
                case "focusin":
                    (Sf(C) || C.contentEditable === "true") && (Ur = C, $u = c, qo = null);
                    break;
                case "focusout":
                    qo = $u = Ur = null;
                    break;
                case "mousedown":
                    Hu = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    Hu = !1, Rf(d, n, f);
                    break;
                case "selectionchange":
                    if (b_) break;
                case "keydown":
                case "keyup":
                    Rf(d, n, f)
            }
            var L;
            if (Xc) e: {
                switch (e) {
                    case "compositionstart":
                        var M = "onCompositionStart";
                        break e;
                    case "compositionend":
                        M = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        M = "onCompositionUpdate";
                        break e
                }
                M = void 0
            }
            else Mr ? Yp(e, n) && (M = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (M = "onCompositionStart");M && (qp && n.locale !== "ko" && (Mr || M !== "onCompositionStart" ? M === "onCompositionEnd" && Mr && (L = Gp()) : (On = f, qc = "value" in On ? On.value : On.textContent, Mr = !0)), C = Js(c, M), 0 < C.length && (M = new vf(M, e, null, n, f), d.push({
                event: M,
                listeners: C
            }), L ? M.data = L : (L = Qp(n), L !== null && (M.data = L)))),
            (L = x_ ? N_(e, n) : R_(e, n)) && (c = Js(c, "onBeforeInput"), 0 < c.length && (f = new vf("onBeforeInput", "beforeinput", null, n, f), d.push({
                event: f,
                listeners: c
            }), f.data = L))
        }
        ih(d, t)
    })
}

function dl(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function Js(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var o = e,
            l = o.stateNode;
        o.tag === 5 && l !== null && (o = l, l = ol(e, n), l != null && r.unshift(dl(e, l, o)), l = ol(e, t), l != null && r.push(dl(e, l, o))), e = e.return
    }
    return r
}

function Dr(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function Tf(e, t, n, r, o) {
    for (var l = t._reactName, s = []; n !== null && n !== r;) {
        var i = n,
            u = i.alternate,
            c = i.stateNode;
        if (u !== null && u === r) break;
        i.tag === 5 && c !== null && (i = c, o ? (u = ol(n, l), u != null && s.unshift(dl(n, u, i))) : o || (u = ol(n, l), u != null && s.push(dl(n, u, i)))), n = n.return
    }
    s.length !== 0 && e.push({
        event: t,
        listeners: s
    })
}
var F_ = /\r\n?/g,
    V_ = /\u0000|\uFFFD/g;

function jf(e) {
    return (typeof e == "string" ? e : "" + e).replace(F_, `
`).replace(V_, "")
}

function cs(e, t, n) {
    if (t = jf(t), jf(e) !== t && n) throw Error(D(425))
}

function Zs() {}
var Bu = null,
    zu = null;

function Wu(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var Ku = typeof setTimeout == "function" ? setTimeout : void 0,
    $_ = typeof clearTimeout == "function" ? clearTimeout : void 0,
    Cf = typeof Promise == "function" ? Promise : void 0,
    H_ = typeof queueMicrotask == "function" ? queueMicrotask : typeof Cf < "u" ? function(e) {
        return Cf.resolve(null).then(e).catch(B_)
    } : Ku;

function B_(e) {
    setTimeout(function() {
        throw e
    })
}

function Yi(e, t) {
    var n = t,
        r = 0;
    do {
        var o = n.nextSibling;
        if (e.removeChild(n), o && o.nodeType === 8)
            if (n = o.data, n === "/$") {
                if (r === 0) {
                    e.removeChild(o), al(t);
                    return
                }
                r--
            } else n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = o
    } while (n);
    al(t)
}

function Hn(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
            if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
            if (t === "/$") return null
        }
    }
    return e
}

function Lf(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var vo = Math.random().toString(36).slice(2),
    Qt = "__reactFiber$" + vo,
    fl = "__reactProps$" + vo,
    pn = "__reactContainer$" + vo,
    Gu = "__reactEvents$" + vo,
    z_ = "__reactListeners$" + vo,
    W_ = "__reactHandles$" + vo;

function ar(e) {
    var t = e[Qt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[pn] || n[Qt]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = Lf(e); e !== null;) {
                    if (n = e[Qt]) return n;
                    e = Lf(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function Rl(e) {
    return e = e[Qt] || e[pn], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function Vr(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(D(33))
}

function ka(e) {
    return e[fl] || null
}
var qu = [],
    $r = -1;

function Qn(e) {
    return {
        current: e
    }
}

function je(e) {
    0 > $r || (e.current = qu[$r], qu[$r] = null, $r--)
}

function ke(e, t) {
    $r++, qu[$r] = e.current, e.current = t
}
var qn = {},
    lt = Qn(qn),
    mt = Qn(!1),
    pr = qn;

function to(e, t) {
    var n = e.type.contextTypes;
    if (!n) return qn;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var o = {},
        l;
    for (l in n) o[l] = t[l];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = o), o
}

function pt(e) {
    return e = e.childContextTypes, e != null
}

function ea() {
    je(mt), je(lt)
}

function Df(e, t, n) {
    if (lt.current !== qn) throw Error(D(168));
    ke(lt, t), ke(mt, n)
}

function ch(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var o in r)
        if (!(o in t)) throw Error(D(108, j0(e) || "Unknown", o));
    return Me({}, n, r)
}

function ta(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || qn, pr = lt.current, ke(lt, e), ke(mt, mt.current), !0
}

function Pf(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(D(169));
    n ? (e = ch(e, t, pr), r.__reactInternalMemoizedMergedChildContext = e, je(mt), je(lt), ke(lt, e)) : je(mt), ke(mt, n)
}
var un = null,
    Aa = !1,
    Qi = !1;

function dh(e) {
    un === null ? un = [e] : un.push(e)
}

function K_(e) {
    Aa = !0, dh(e)
}

function Xn() {
    if (!Qi && un !== null) {
        Qi = !0;
        var e = 0,
            t = we;
        try {
            var n = un;
            for (we = 1; e < n.length; e++) {
                var r = n[e];
                do r = r(!0); while (r !== null)
            }
            un = null, Aa = !1
        } catch (o) {
            throw un !== null && (un = un.slice(e + 1)), Ip(zc, Xn), o
        } finally {
            we = t, Qi = !1
        }
    }
    return null
}
var Hr = [],
    Br = 0,
    na = null,
    ra = 0,
    At = [],
    Tt = 0,
    hr = null,
    cn = 1,
    dn = "";

function rr(e, t) {
    Hr[Br++] = ra, Hr[Br++] = na, na = e, ra = t
}

function fh(e, t, n) {
    At[Tt++] = cn, At[Tt++] = dn, At[Tt++] = hr, hr = e;
    var r = cn;
    e = dn;
    var o = 32 - Bt(r) - 1;
    r &= ~(1 << o), n += 1;
    var l = 32 - Bt(t) + o;
    if (30 < l) {
        var s = o - o % 5;
        l = (r & (1 << s) - 1).toString(32), r >>= s, o -= s, cn = 1 << 32 - Bt(t) + o | n << o | r, dn = l + e
    } else cn = 1 << l | n << o | r, dn = e
}

function Zc(e) {
    e.return !== null && (rr(e, 1), fh(e, 1, 0))
}

function ed(e) {
    for (; e === na;) na = Hr[--Br], Hr[Br] = null, ra = Hr[--Br], Hr[Br] = null;
    for (; e === hr;) hr = At[--Tt], At[Tt] = null, dn = At[--Tt], At[Tt] = null, cn = At[--Tt], At[Tt] = null
}
var wt = null,
    St = null,
    De = !1,
    Ht = null;

function mh(e, t) {
    var n = Ct(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function Of(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, wt = e, St = Hn(t.firstChild), !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, wt = e, St = null, !0) : !1;
        case 13:
            return t = t.nodeType !== 8 ? null : t, t !== null ? (n = hr !== null ? {
                id: cn,
                overflow: dn
            } : null, e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824
            }, n = Ct(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, wt = e, St = null, !0) : !1;
        default:
            return !1
    }
}

function Yu(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}

function Qu(e) {
    if (De) {
        var t = St;
        if (t) {
            var n = t;
            if (!Of(e, t)) {
                if (Yu(e)) throw Error(D(418));
                t = Hn(n.nextSibling);
                var r = wt;
                t && Of(e, t) ? mh(r, n) : (e.flags = e.flags & -4097 | 2, De = !1, wt = e)
            }
        } else {
            if (Yu(e)) throw Error(D(418));
            e.flags = e.flags & -4097 | 2, De = !1, wt = e
        }
    }
}

function bf(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    wt = e
}

function ds(e) {
    if (e !== wt) return !1;
    if (!De) return bf(e), De = !0, !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !Wu(e.type, e.memoizedProps)), t && (t = St)) {
        if (Yu(e)) throw ph(), Error(D(418));
        for (; t;) mh(e, t), t = Hn(t.nextSibling)
    }
    if (bf(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(D(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            St = Hn(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            St = null
        }
    } else St = wt ? Hn(e.stateNode.nextSibling) : null;
    return !0
}

function ph() {
    for (var e = St; e;) e = Hn(e.nextSibling)
}

function no() {
    St = wt = null, De = !1
}

function td(e) {
    Ht === null ? Ht = [e] : Ht.push(e)
}
var G_ = gn.ReactCurrentBatchConfig;

function Vt(e, t) {
    if (e && e.defaultProps) {
        t = Me({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}
var oa = Qn(null),
    la = null,
    zr = null,
    nd = null;

function rd() {
    nd = zr = la = null
}

function od(e) {
    var t = oa.current;
    je(oa), e._currentValue = t
}

function Xu(e, t, n) {
    for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
        e = e.return
    }
}

function Xr(e, t) {
    la = e, nd = zr = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (ft = !0), e.firstContext = null)
}

function Ot(e) {
    var t = e._currentValue;
    if (nd !== e)
        if (e = {
                context: e,
                memoizedValue: t,
                next: null
            }, zr === null) {
            if (la === null) throw Error(D(308));
            zr = e, la.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else zr = zr.next = e;
    return t
}
var ir = null;

function ld(e) {
    ir === null ? ir = [e] : ir.push(e)
}

function hh(e, t, n, r) {
    var o = t.interleaved;
    return o === null ? (n.next = n, ld(t)) : (n.next = o.next, o.next = n), t.interleaved = n, hn(e, r)
}

function hn(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var Cn = !1;

function sd(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}

function vh(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function fn(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function Bn(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (r = r.shared, ve & 2) {
        var o = r.pending;
        return o === null ? t.next = t : (t.next = o.next, o.next = t), r.pending = t, hn(e, n)
    }
    return o = r.interleaved, o === null ? (t.next = t, ld(r)) : (t.next = o.next, o.next = t), r.interleaved = t, hn(e, n)
}

function Os(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, Wc(e, n)
    }
}

function If(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var o = null,
            l = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var s = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                l === null ? o = l = s : l = l.next = s, n = n.next
            } while (n !== null);
            l === null ? o = l = t : l = l.next = t
        } else o = l = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: o,
            lastBaseUpdate: l,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function sa(e, t, n, r) {
    var o = e.updateQueue;
    Cn = !1;
    var l = o.firstBaseUpdate,
        s = o.lastBaseUpdate,
        i = o.shared.pending;
    if (i !== null) {
        o.shared.pending = null;
        var u = i,
            c = u.next;
        u.next = null, s === null ? l = c : s.next = c, s = u;
        var f = e.alternate;
        f !== null && (f = f.updateQueue, i = f.lastBaseUpdate, i !== s && (i === null ? f.firstBaseUpdate = c : i.next = c, f.lastBaseUpdate = u))
    }
    if (l !== null) {
        var d = o.baseState;
        s = 0, f = c = u = null, i = l;
        do {
            var g = i.lane,
                S = i.eventTime;
            if ((r & g) === g) {
                f !== null && (f = f.next = {
                    eventTime: S,
                    lane: 0,
                    tag: i.tag,
                    payload: i.payload,
                    callback: i.callback,
                    next: null
                });
                e: {
                    var v = e,
                        _ = i;
                    switch (g = t, S = n, _.tag) {
                        case 1:
                            if (v = _.payload, typeof v == "function") {
                                d = v.call(S, d, g);
                                break e
                            }
                            d = v;
                            break e;
                        case 3:
                            v.flags = v.flags & -65537 | 128;
                        case 0:
                            if (v = _.payload, g = typeof v == "function" ? v.call(S, d, g) : v, g == null) break e;
                            d = Me({}, d, g);
                            break e;
                        case 2:
                            Cn = !0
                    }
                }
                i.callback !== null && i.lane !== 0 && (e.flags |= 64, g = o.effects, g === null ? o.effects = [i] : g.push(i))
            } else S = {
                eventTime: S,
                lane: g,
                tag: i.tag,
                payload: i.payload,
                callback: i.callback,
                next: null
            }, f === null ? (c = f = S, u = d) : f = f.next = S, s |= g;
            if (i = i.next, i === null) {
                if (i = o.shared.pending, i === null) break;
                g = i, i = g.next, g.next = null, o.lastBaseUpdate = g, o.shared.pending = null
            }
        } while (!0);
        if (f === null && (u = d), o.baseState = u, o.firstBaseUpdate = c, o.lastBaseUpdate = f, t = o.shared.interleaved, t !== null) {
            o = t;
            do s |= o.lane, o = o.next; while (o !== t)
        } else l === null && (o.shared.lanes = 0);
        gr |= s, e.lanes = s, e.memoizedState = d
    }
}

function Mf(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                o = r.callback;
            if (o !== null) {
                if (r.callback = null, r = n, typeof o != "function") throw Error(D(191, o));
                o.call(r)
            }
        }
}
var gh = new hp.Component().refs;

function Ju(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : Me({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var Ta = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? Er(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = at(),
            o = Wn(e),
            l = fn(r, o);
        l.payload = t, n != null && (l.callback = n), t = Bn(e, l, o), t !== null && (zt(t, e, o, r), Os(t, e, o))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = at(),
            o = Wn(e),
            l = fn(r, o);
        l.tag = 1, l.payload = t, n != null && (l.callback = n), t = Bn(e, l, o), t !== null && (zt(t, e, o, r), Os(t, e, o))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = at(),
            r = Wn(e),
            o = fn(n, r);
        o.tag = 2, t != null && (o.callback = t), t = Bn(e, o, r), t !== null && (zt(t, e, r, n), Os(t, e, r))
    }
};

function Uf(e, t, n, r, o, l, s) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, l, s) : t.prototype && t.prototype.isPureReactComponent ? !ul(n, r) || !ul(o, l) : !0
}

function yh(e, t, n) {
    var r = !1,
        o = qn,
        l = t.contextType;
    return typeof l == "object" && l !== null ? l = Ot(l) : (o = pt(t) ? pr : lt.current, r = t.contextTypes, l = (r = r != null) ? to(e, o) : qn), t = new t(n, l), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = Ta, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = o, e.__reactInternalMemoizedMaskedChildContext = l), t
}

function Ff(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ta.enqueueReplaceState(t, t.state, null)
}

function Zu(e, t, n, r) {
    var o = e.stateNode;
    o.props = n, o.state = e.memoizedState, o.refs = gh, sd(e);
    var l = t.contextType;
    typeof l == "object" && l !== null ? o.context = Ot(l) : (l = pt(t) ? pr : lt.current, o.context = to(e, l)), o.state = e.memoizedState, l = t.getDerivedStateFromProps, typeof l == "function" && (Ju(e, t, l, n), o.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof o.getSnapshotBeforeUpdate == "function" || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (t = o.state, typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount(), t !== o.state && Ta.enqueueReplaceState(o, o.state, null), sa(e, n, o, r), o.state = e.memoizedState), typeof o.componentDidMount == "function" && (e.flags |= 4194308)
}

function To(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(D(309));
                var r = n.stateNode
            }
            if (!r) throw Error(D(147, e));
            var o = r,
                l = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === l ? t.ref : (t = function(s) {
                var i = o.refs;
                i === gh && (i = o.refs = {}), s === null ? delete i[l] : i[l] = s
            }, t._stringRef = l, t)
        }
        if (typeof e != "string") throw Error(D(284));
        if (!n._owner) throw Error(D(290, e))
    }
    return e
}

function fs(e, t) {
    throw e = Object.prototype.toString.call(t), Error(D(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}

function Vf(e) {
    var t = e._init;
    return t(e._payload)
}

function _h(e) {
    function t(p, m) {
        if (e) {
            var h = p.deletions;
            h === null ? (p.deletions = [m], p.flags |= 16) : h.push(m)
        }
    }

    function n(p, m) {
        if (!e) return null;
        for (; m !== null;) t(p, m), m = m.sibling;
        return null
    }

    function r(p, m) {
        for (p = new Map; m !== null;) m.key !== null ? p.set(m.key, m) : p.set(m.index, m), m = m.sibling;
        return p
    }

    function o(p, m) {
        return p = Kn(p, m), p.index = 0, p.sibling = null, p
    }

    function l(p, m, h) {
        return p.index = h, e ? (h = p.alternate, h !== null ? (h = h.index, h < m ? (p.flags |= 2, m) : h) : (p.flags |= 2, m)) : (p.flags |= 1048576, m)
    }

    function s(p) {
        return e && p.alternate === null && (p.flags |= 2), p
    }

    function i(p, m, h, x) {
        return m === null || m.tag !== 6 ? (m = ru(h, p.mode, x), m.return = p, m) : (m = o(m, h), m.return = p, m)
    }

    function u(p, m, h, x) {
        var k = h.type;
        return k === Ir ? f(p, m, h.props.children, x, h.key) : m !== null && (m.elementType === k || typeof k == "object" && k !== null && k.$$typeof === jn && Vf(k) === m.type) ? (x = o(m, h.props), x.ref = To(p, m, h), x.return = p, x) : (x = Vs(h.type, h.key, h.props, null, p.mode, x), x.ref = To(p, m, h), x.return = p, x)
    }

    function c(p, m, h, x) {
        return m === null || m.tag !== 4 || m.stateNode.containerInfo !== h.containerInfo || m.stateNode.implementation !== h.implementation ? (m = ou(h, p.mode, x), m.return = p, m) : (m = o(m, h.children || []), m.return = p, m)
    }

    function f(p, m, h, x, k) {
        return m === null || m.tag !== 7 ? (m = dr(h, p.mode, x, k), m.return = p, m) : (m = o(m, h), m.return = p, m)
    }

    function d(p, m, h) {
        if (typeof m == "string" && m !== "" || typeof m == "number") return m = ru("" + m, p.mode, h), m.return = p, m;
        if (typeof m == "object" && m !== null) {
            switch (m.$$typeof) {
                case ts:
                    return h = Vs(m.type, m.key, m.props, null, p.mode, h), h.ref = To(p, null, m), h.return = p, h;
                case br:
                    return m = ou(m, p.mode, h), m.return = p, m;
                case jn:
                    var x = m._init;
                    return d(p, x(m._payload), h)
            }
            if (Vo(m) || xo(m)) return m = dr(m, p.mode, h, null), m.return = p, m;
            fs(p, m)
        }
        return null
    }

    function g(p, m, h, x) {
        var k = m !== null ? m.key : null;
        if (typeof h == "string" && h !== "" || typeof h == "number") return k !== null ? null : i(p, m, "" + h, x);
        if (typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case ts:
                    return h.key === k ? u(p, m, h, x) : null;
                case br:
                    return h.key === k ? c(p, m, h, x) : null;
                case jn:
                    return k = h._init, g(p, m, k(h._payload), x)
            }
            if (Vo(h) || xo(h)) return k !== null ? null : f(p, m, h, x, null);
            fs(p, h)
        }
        return null
    }

    function S(p, m, h, x, k) {
        if (typeof x == "string" && x !== "" || typeof x == "number") return p = p.get(h) || null, i(m, p, "" + x, k);
        if (typeof x == "object" && x !== null) {
            switch (x.$$typeof) {
                case ts:
                    return p = p.get(x.key === null ? h : x.key) || null, u(m, p, x, k);
                case br:
                    return p = p.get(x.key === null ? h : x.key) || null, c(m, p, x, k);
                case jn:
                    var C = x._init;
                    return S(p, m, h, C(x._payload), k)
            }
            if (Vo(x) || xo(x)) return p = p.get(h) || null, f(m, p, x, k, null);
            fs(m, x)
        }
        return null
    }

    function v(p, m, h, x) {
        for (var k = null, C = null, L = m, M = m = 0, oe = null; L !== null && M < h.length; M++) {
            L.index > M ? (oe = L, L = null) : oe = L.sibling;
            var H = g(p, L, h[M], x);
            if (H === null) {
                L === null && (L = oe);
                break
            }
            e && L && H.alternate === null && t(p, L), m = l(H, m, M), C === null ? k = H : C.sibling = H, C = H, L = oe
        }
        if (M === h.length) return n(p, L), De && rr(p, M), k;
        if (L === null) {
            for (; M < h.length; M++) L = d(p, h[M], x), L !== null && (m = l(L, m, M), C === null ? k = L : C.sibling = L, C = L);
            return De && rr(p, M), k
        }
        for (L = r(p, L); M < h.length; M++) oe = S(L, p, M, h[M], x), oe !== null && (e && oe.alternate !== null && L.delete(oe.key === null ? M : oe.key), m = l(oe, m, M), C === null ? k = oe : C.sibling = oe, C = oe);
        return e && L.forEach(function(ge) {
            return t(p, ge)
        }), De && rr(p, M), k
    }

    function _(p, m, h, x) {
        var k = xo(h);
        if (typeof k != "function") throw Error(D(150));
        if (h = k.call(h), h == null) throw Error(D(151));
        for (var C = k = null, L = m, M = m = 0, oe = null, H = h.next(); L !== null && !H.done; M++, H = h.next()) {
            L.index > M ? (oe = L, L = null) : oe = L.sibling;
            var ge = g(p, L, H.value, x);
            if (ge === null) {
                L === null && (L = oe);
                break
            }
            e && L && ge.alternate === null && t(p, L), m = l(ge, m, M), C === null ? k = ge : C.sibling = ge, C = ge, L = oe
        }
        if (H.done) return n(p, L), De && rr(p, M), k;
        if (L === null) {
            for (; !H.done; M++, H = h.next()) H = d(p, H.value, x), H !== null && (m = l(H, m, M), C === null ? k = H : C.sibling = H, C = H);
            return De && rr(p, M), k
        }
        for (L = r(p, L); !H.done; M++, H = h.next()) H = S(L, p, M, H.value, x), H !== null && (e && H.alternate !== null && L.delete(H.key === null ? M : H.key), m = l(H, m, M), C === null ? k = H : C.sibling = H, C = H);
        return e && L.forEach(function(Ue) {
            return t(p, Ue)
        }), De && rr(p, M), k
    }

    function R(p, m, h, x) {
        if (typeof h == "object" && h !== null && h.type === Ir && h.key === null && (h = h.props.children), typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case ts:
                    e: {
                        for (var k = h.key, C = m; C !== null;) {
                            if (C.key === k) {
                                if (k = h.type, k === Ir) {
                                    if (C.tag === 7) {
                                        n(p, C.sibling), m = o(C, h.props.children), m.return = p, p = m;
                                        break e
                                    }
                                } else if (C.elementType === k || typeof k == "object" && k !== null && k.$$typeof === jn && Vf(k) === C.type) {
                                    n(p, C.sibling), m = o(C, h.props), m.ref = To(p, C, h), m.return = p, p = m;
                                    break e
                                }
                                n(p, C);
                                break
                            } else t(p, C);
                            C = C.sibling
                        }
                        h.type === Ir ? (m = dr(h.props.children, p.mode, x, h.key), m.return = p, p = m) : (x = Vs(h.type, h.key, h.props, null, p.mode, x), x.ref = To(p, m, h), x.return = p, p = x)
                    }
                    return s(p);
                case br:
                    e: {
                        for (C = h.key; m !== null;) {
                            if (m.key === C)
                                if (m.tag === 4 && m.stateNode.containerInfo === h.containerInfo && m.stateNode.implementation === h.implementation) {
                                    n(p, m.sibling), m = o(m, h.children || []), m.return = p, p = m;
                                    break e
                                } else {
                                    n(p, m);
                                    break
                                }
                            else t(p, m);
                            m = m.sibling
                        }
                        m = ou(h, p.mode, x),
                        m.return = p,
                        p = m
                    }
                    return s(p);
                case jn:
                    return C = h._init, R(p, m, C(h._payload), x)
            }
            if (Vo(h)) return v(p, m, h, x);
            if (xo(h)) return _(p, m, h, x);
            fs(p, h)
        }
        return typeof h == "string" && h !== "" || typeof h == "number" ? (h = "" + h, m !== null && m.tag === 6 ? (n(p, m.sibling), m = o(m, h), m.return = p, p = m) : (n(p, m), m = ru(h, p.mode, x), m.return = p, p = m), s(p)) : n(p, m)
    }
    return R
}
var ro = _h(!0),
    Sh = _h(!1),
    kl = {},
    Zt = Qn(kl),
    ml = Qn(kl),
    pl = Qn(kl);

function ur(e) {
    if (e === kl) throw Error(D(174));
    return e
}

function ad(e, t) {
    switch (ke(pl, t), ke(ml, e), ke(Zt, kl), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : Lu(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = Lu(t, e)
    }
    je(Zt), ke(Zt, t)
}

function oo() {
    je(Zt), je(ml), je(pl)
}

function wh(e) {
    ur(pl.current);
    var t = ur(Zt.current),
        n = Lu(t, e.type);
    t !== n && (ke(ml, e), ke(Zt, n))
}

function id(e) {
    ml.current === e && (je(Zt), je(ml))
}
var be = Qn(0);

function aa(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var Xi = [];

function ud() {
    for (var e = 0; e < Xi.length; e++) Xi[e]._workInProgressVersionPrimary = null;
    Xi.length = 0
}
var bs = gn.ReactCurrentDispatcher,
    Ji = gn.ReactCurrentBatchConfig,
    vr = 0,
    Ie = null,
    Ge = null,
    Ye = null,
    ia = !1,
    Yo = !1,
    hl = 0,
    q_ = 0;

function nt() {
    throw Error(D(321))
}

function cd(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!Wt(e[n], t[n])) return !1;
    return !0
}

function dd(e, t, n, r, o, l) {
    if (vr = l, Ie = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, bs.current = e === null || e.memoizedState === null ? J_ : Z_, e = n(r, o), Yo) {
        l = 0;
        do {
            if (Yo = !1, hl = 0, 25 <= l) throw Error(D(301));
            l += 1, Ye = Ge = null, t.updateQueue = null, bs.current = eS, e = n(r, o)
        } while (Yo)
    }
    if (bs.current = ua, t = Ge !== null && Ge.next !== null, vr = 0, Ye = Ge = Ie = null, ia = !1, t) throw Error(D(300));
    return e
}

function fd() {
    var e = hl !== 0;
    return hl = 0, e
}

function Yt() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return Ye === null ? Ie.memoizedState = Ye = e : Ye = Ye.next = e, Ye
}

function bt() {
    if (Ge === null) {
        var e = Ie.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = Ge.next;
    var t = Ye === null ? Ie.memoizedState : Ye.next;
    if (t !== null) Ye = t, Ge = e;
    else {
        if (e === null) throw Error(D(310));
        Ge = e, e = {
            memoizedState: Ge.memoizedState,
            baseState: Ge.baseState,
            baseQueue: Ge.baseQueue,
            queue: Ge.queue,
            next: null
        }, Ye === null ? Ie.memoizedState = Ye = e : Ye = Ye.next = e
    }
    return Ye
}

function vl(e, t) {
    return typeof t == "function" ? t(e) : t
}

function Zi(e) {
    var t = bt(),
        n = t.queue;
    if (n === null) throw Error(D(311));
    n.lastRenderedReducer = e;
    var r = Ge,
        o = r.baseQueue,
        l = n.pending;
    if (l !== null) {
        if (o !== null) {
            var s = o.next;
            o.next = l.next, l.next = s
        }
        r.baseQueue = o = l, n.pending = null
    }
    if (o !== null) {
        l = o.next, r = r.baseState;
        var i = s = null,
            u = null,
            c = l;
        do {
            var f = c.lane;
            if ((vr & f) === f) u !== null && (u = u.next = {
                lane: 0,
                action: c.action,
                hasEagerState: c.hasEagerState,
                eagerState: c.eagerState,
                next: null
            }), r = c.hasEagerState ? c.eagerState : e(r, c.action);
            else {
                var d = {
                    lane: f,
                    action: c.action,
                    hasEagerState: c.hasEagerState,
                    eagerState: c.eagerState,
                    next: null
                };
                u === null ? (i = u = d, s = r) : u = u.next = d, Ie.lanes |= f, gr |= f
            }
            c = c.next
        } while (c !== null && c !== l);
        u === null ? s = r : u.next = i, Wt(r, t.memoizedState) || (ft = !0), t.memoizedState = r, t.baseState = s, t.baseQueue = u, n.lastRenderedState = r
    }
    if (e = n.interleaved, e !== null) {
        o = e;
        do l = o.lane, Ie.lanes |= l, gr |= l, o = o.next; while (o !== e)
    } else o === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}

function eu(e) {
    var t = bt(),
        n = t.queue;
    if (n === null) throw Error(D(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        o = n.pending,
        l = t.memoizedState;
    if (o !== null) {
        n.pending = null;
        var s = o = o.next;
        do l = e(l, s.action), s = s.next; while (s !== o);
        Wt(l, t.memoizedState) || (ft = !0), t.memoizedState = l, t.baseQueue === null && (t.baseState = l), n.lastRenderedState = l
    }
    return [l, r]
}

function Eh() {}

function xh(e, t) {
    var n = Ie,
        r = bt(),
        o = t(),
        l = !Wt(r.memoizedState, o);
    if (l && (r.memoizedState = o, ft = !0), r = r.queue, md(kh.bind(null, n, r, e), [e]), r.getSnapshot !== t || l || Ye !== null && Ye.memoizedState.tag & 1) {
        if (n.flags |= 2048, gl(9, Rh.bind(null, n, r, o, t), void 0, null), Qe === null) throw Error(D(349));
        vr & 30 || Nh(n, t, o)
    }
    return o
}

function Nh(e, t, n) {
    e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
    }, t = Ie.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, Ie.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
}

function Rh(e, t, n, r) {
    t.value = n, t.getSnapshot = r, Ah(t) && Th(e)
}

function kh(e, t, n) {
    return n(function() {
        Ah(t) && Th(e)
    })
}

function Ah(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !Wt(e, n)
    } catch {
        return !0
    }
}

function Th(e) {
    var t = hn(e, 1);
    t !== null && zt(t, e, 1, -1)
}

function $f(e) {
    var t = Yt();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: vl,
        lastRenderedState: e
    }, t.queue = e, e = e.dispatch = X_.bind(null, Ie, e), [t.memoizedState, e]
}

function gl(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = Ie.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, Ie.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function jh() {
    return bt().memoizedState
}

function Is(e, t, n, r) {
    var o = Yt();
    Ie.flags |= e, o.memoizedState = gl(1 | t, n, void 0, r === void 0 ? null : r)
}

function ja(e, t, n, r) {
    var o = bt();
    r = r === void 0 ? null : r;
    var l = void 0;
    if (Ge !== null) {
        var s = Ge.memoizedState;
        if (l = s.destroy, r !== null && cd(r, s.deps)) {
            o.memoizedState = gl(t, n, l, r);
            return
        }
    }
    Ie.flags |= e, o.memoizedState = gl(1 | t, n, l, r)
}

function Hf(e, t) {
    return Is(8390656, 8, e, t)
}

function md(e, t) {
    return ja(2048, 8, e, t)
}

function Ch(e, t) {
    return ja(4, 2, e, t)
}

function Lh(e, t) {
    return ja(4, 4, e, t)
}

function Dh(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function Ph(e, t, n) {
    return n = n != null ? n.concat([e]) : null, ja(4, 4, Dh.bind(null, t, e), n)
}

function pd() {}

function Oh(e, t) {
    var n = bt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && cd(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function bh(e, t) {
    var n = bt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && cd(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function Ih(e, t, n) {
    return vr & 21 ? (Wt(n, t) || (n = Fp(), Ie.lanes |= n, gr |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, ft = !0), e.memoizedState = n)
}

function Y_(e, t) {
    var n = we;
    we = n !== 0 && 4 > n ? n : 4, e(!0);
    var r = Ji.transition;
    Ji.transition = {};
    try {
        e(!1), t()
    } finally {
        we = n, Ji.transition = r
    }
}

function Mh() {
    return bt().memoizedState
}

function Q_(e, t, n) {
    var r = Wn(e);
    if (n = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, Uh(e)) Fh(t, n);
    else if (n = hh(e, t, n, r), n !== null) {
        var o = at();
        zt(n, e, r, o), Vh(n, t, r)
    }
}

function X_(e, t, n) {
    var r = Wn(e),
        o = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
    if (Uh(e)) Fh(t, o);
    else {
        var l = e.alternate;
        if (e.lanes === 0 && (l === null || l.lanes === 0) && (l = t.lastRenderedReducer, l !== null)) try {
            var s = t.lastRenderedState,
                i = l(s, n);
            if (o.hasEagerState = !0, o.eagerState = i, Wt(i, s)) {
                var u = t.interleaved;
                u === null ? (o.next = o, ld(t)) : (o.next = u.next, u.next = o), t.interleaved = o;
                return
            }
        } catch {} finally {}
        n = hh(e, t, o, r), n !== null && (o = at(), zt(n, e, r, o), Vh(n, t, r))
    }
}

function Uh(e) {
    var t = e.alternate;
    return e === Ie || t !== null && t === Ie
}

function Fh(e, t) {
    Yo = ia = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function Vh(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, Wc(e, n)
    }
}
var ua = {
        readContext: Ot,
        useCallback: nt,
        useContext: nt,
        useEffect: nt,
        useImperativeHandle: nt,
        useInsertionEffect: nt,
        useLayoutEffect: nt,
        useMemo: nt,
        useReducer: nt,
        useRef: nt,
        useState: nt,
        useDebugValue: nt,
        useDeferredValue: nt,
        useTransition: nt,
        useMutableSource: nt,
        useSyncExternalStore: nt,
        useId: nt,
        unstable_isNewReconciler: !1
    },
    J_ = {
        readContext: Ot,
        useCallback: function(e, t) {
            return Yt().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: Ot,
        useEffect: Hf,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, Is(4194308, 4, Dh.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return Is(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
            return Is(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = Yt();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = Yt();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                pending: null,
                interleaved: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, r.queue = e, e = e.dispatch = Q_.bind(null, Ie, e), [r.memoizedState, e]
        },
        useRef: function(e) {
            var t = Yt();
            return e = {
                current: e
            }, t.memoizedState = e
        },
        useState: $f,
        useDebugValue: pd,
        useDeferredValue: function(e) {
            return Yt().memoizedState = e
        },
        useTransition: function() {
            var e = $f(!1),
                t = e[0];
            return e = Y_.bind(null, e[1]), Yt().memoizedState = e, [t, e]
        },
        useMutableSource: function() {},
        useSyncExternalStore: function(e, t, n) {
            var r = Ie,
                o = Yt();
            if (De) {
                if (n === void 0) throw Error(D(407));
                n = n()
            } else {
                if (n = t(), Qe === null) throw Error(D(349));
                vr & 30 || Nh(r, t, n)
            }
            o.memoizedState = n;
            var l = {
                value: n,
                getSnapshot: t
            };
            return o.queue = l, Hf(kh.bind(null, r, l, e), [e]), r.flags |= 2048, gl(9, Rh.bind(null, r, l, n, t), void 0, null), n
        },
        useId: function() {
            var e = Yt(),
                t = Qe.identifierPrefix;
            if (De) {
                var n = dn,
                    r = cn;
                n = (r & ~(1 << 32 - Bt(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = hl++, 0 < n && (t += "H" + n.toString(32)), t += ":"
            } else n = q_++, t = ":" + t + "r" + n.toString(32) + ":";
            return e.memoizedState = t
        },
        unstable_isNewReconciler: !1
    },
    Z_ = {
        readContext: Ot,
        useCallback: Oh,
        useContext: Ot,
        useEffect: md,
        useImperativeHandle: Ph,
        useInsertionEffect: Ch,
        useLayoutEffect: Lh,
        useMemo: bh,
        useReducer: Zi,
        useRef: jh,
        useState: function() {
            return Zi(vl)
        },
        useDebugValue: pd,
        useDeferredValue: function(e) {
            var t = bt();
            return Ih(t, Ge.memoizedState, e)
        },
        useTransition: function() {
            var e = Zi(vl)[0],
                t = bt().memoizedState;
            return [e, t]
        },
        useMutableSource: Eh,
        useSyncExternalStore: xh,
        useId: Mh,
        unstable_isNewReconciler: !1
    },
    eS = {
        readContext: Ot,
        useCallback: Oh,
        useContext: Ot,
        useEffect: md,
        useImperativeHandle: Ph,
        useInsertionEffect: Ch,
        useLayoutEffect: Lh,
        useMemo: bh,
        useReducer: eu,
        useRef: jh,
        useState: function() {
            return eu(vl)
        },
        useDebugValue: pd,
        useDeferredValue: function(e) {
            var t = bt();
            return Ge === null ? t.memoizedState = e : Ih(t, Ge.memoizedState, e)
        },
        useTransition: function() {
            var e = eu(vl)[0],
                t = bt().memoizedState;
            return [e, t]
        },
        useMutableSource: Eh,
        useSyncExternalStore: xh,
        useId: Mh,
        unstable_isNewReconciler: !1
    };

function lo(e, t) {
    try {
        var n = "",
            r = t;
        do n += T0(r), r = r.return; while (r);
        var o = n
    } catch (l) {
        o = `
Error generating stack: ` + l.message + `
` + l.stack
    }
    return {
        value: e,
        source: t,
        stack: o,
        digest: null
    }
}

function tu(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ? ? null,
        digest: t ? ? null
    }
}

function ec(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var tS = typeof WeakMap == "function" ? WeakMap : Map;

function $h(e, t, n) {
    n = fn(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        da || (da = !0, cc = r), ec(e, t)
    }, n
}

function Hh(e, t, n) {
    n = fn(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var o = t.value;
        n.payload = function() {
            return r(o)
        }, n.callback = function() {
            ec(e, t)
        }
    }
    var l = e.stateNode;
    return l !== null && typeof l.componentDidCatch == "function" && (n.callback = function() {
        ec(e, t), typeof r != "function" && (zn === null ? zn = new Set([this]) : zn.add(this));
        var s = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: s !== null ? s : ""
        })
    }), n
}

function Bf(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new tS;
        var o = new Set;
        r.set(t, o)
    } else o = r.get(t), o === void 0 && (o = new Set, r.set(t, o));
    o.has(n) || (o.add(n), e = hS.bind(null, e, t, n), t.then(e, e))
}

function zf(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
        e = e.return
    } while (e !== null);
    return null
}

function Wf(e, t, n, r, o) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = o, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = fn(-1, 1), t.tag = 2, Bn(n, t, 1))), n.lanes |= 1), e)
}
var nS = gn.ReactCurrentOwner,
    ft = !1;

function st(e, t, n, r) {
    t.child = e === null ? Sh(t, null, n, r) : ro(t, e.child, n, r)
}

function Kf(e, t, n, r, o) {
    n = n.render;
    var l = t.ref;
    return Xr(t, o), r = dd(e, t, n, r, l, o), n = fd(), e !== null && !ft ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, vn(e, t, o)) : (De && n && Zc(t), t.flags |= 1, st(e, t, r, o), t.child)
}

function Gf(e, t, n, r, o) {
    if (e === null) {
        var l = n.type;
        return typeof l == "function" && !Ed(l) && l.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = l, Bh(e, t, l, r, o)) : (e = Vs(n.type, null, r, t, t.mode, o), e.ref = t.ref, e.return = t, t.child = e)
    }
    if (l = e.child, !(e.lanes & o)) {
        var s = l.memoizedProps;
        if (n = n.compare, n = n !== null ? n : ul, n(s, r) && e.ref === t.ref) return vn(e, t, o)
    }
    return t.flags |= 1, e = Kn(l, r), e.ref = t.ref, e.return = t, t.child = e
}

function Bh(e, t, n, r, o) {
    if (e !== null) {
        var l = e.memoizedProps;
        if (ul(l, r) && e.ref === t.ref)
            if (ft = !1, t.pendingProps = r = l, (e.lanes & o) !== 0) e.flags & 131072 && (ft = !0);
            else return t.lanes = e.lanes, vn(e, t, o)
    }
    return tc(e, t, n, r, o)
}

function zh(e, t, n) {
    var r = t.pendingProps,
        o = r.children,
        l = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1)) t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
        }, ke(Kr, _t), _t |= n;
        else {
            if (!(n & 1073741824)) return e = l !== null ? l.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                baseLanes: e,
                cachePool: null,
                transitions: null
            }, t.updateQueue = null, ke(Kr, _t), _t |= e, null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, r = l !== null ? l.baseLanes : n, ke(Kr, _t), _t |= r
        }
    else l !== null ? (r = l.baseLanes | n, t.memoizedState = null) : r = n, ke(Kr, _t), _t |= r;
    return st(e, t, o, n), t.child
}

function Wh(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function tc(e, t, n, r, o) {
    var l = pt(n) ? pr : lt.current;
    return l = to(t, l), Xr(t, o), n = dd(e, t, n, r, l, o), r = fd(), e !== null && !ft ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, vn(e, t, o)) : (De && r && Zc(t), t.flags |= 1, st(e, t, n, o), t.child)
}

function qf(e, t, n, r, o) {
    if (pt(n)) {
        var l = !0;
        ta(t)
    } else l = !1;
    if (Xr(t, o), t.stateNode === null) Ms(e, t), yh(t, n, r), Zu(t, n, r, o), r = !0;
    else if (e === null) {
        var s = t.stateNode,
            i = t.memoizedProps;
        s.props = i;
        var u = s.context,
            c = n.contextType;
        typeof c == "object" && c !== null ? c = Ot(c) : (c = pt(n) ? pr : lt.current, c = to(t, c));
        var f = n.getDerivedStateFromProps,
            d = typeof f == "function" || typeof s.getSnapshotBeforeUpdate == "function";
        d || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (i !== r || u !== c) && Ff(t, s, r, c), Cn = !1;
        var g = t.memoizedState;
        s.state = g, sa(t, r, s, o), u = t.memoizedState, i !== r || g !== u || mt.current || Cn ? (typeof f == "function" && (Ju(t, n, f, r), u = t.memoizedState), (i = Cn || Uf(t, n, i, r, g, u, c)) ? (d || typeof s.UNSAFE_componentWillMount != "function" && typeof s.componentWillMount != "function" || (typeof s.componentWillMount == "function" && s.componentWillMount(), typeof s.UNSAFE_componentWillMount == "function" && s.UNSAFE_componentWillMount()), typeof s.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = u), s.props = r, s.state = u, s.context = c, r = i) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
    } else {
        s = t.stateNode, vh(e, t), i = t.memoizedProps, c = t.type === t.elementType ? i : Vt(t.type, i), s.props = c, d = t.pendingProps, g = s.context, u = n.contextType, typeof u == "object" && u !== null ? u = Ot(u) : (u = pt(n) ? pr : lt.current, u = to(t, u));
        var S = n.getDerivedStateFromProps;
        (f = typeof S == "function" || typeof s.getSnapshotBeforeUpdate == "function") || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (i !== d || g !== u) && Ff(t, s, r, u), Cn = !1, g = t.memoizedState, s.state = g, sa(t, r, s, o);
        var v = t.memoizedState;
        i !== d || g !== v || mt.current || Cn ? (typeof S == "function" && (Ju(t, n, S, r), v = t.memoizedState), (c = Cn || Uf(t, n, c, r, g, v, u) || !1) ? (f || typeof s.UNSAFE_componentWillUpdate != "function" && typeof s.componentWillUpdate != "function" || (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(r, v, u), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(r, v, u)), typeof s.componentDidUpdate == "function" && (t.flags |= 4), typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof s.componentDidUpdate != "function" || i === e.memoizedProps && g === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || i === e.memoizedProps && g === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = v), s.props = r, s.state = v, s.context = u, r = c) : (typeof s.componentDidUpdate != "function" || i === e.memoizedProps && g === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || i === e.memoizedProps && g === e.memoizedState || (t.flags |= 1024), r = !1)
    }
    return nc(e, t, n, r, l, o)
}

function nc(e, t, n, r, o, l) {
    Wh(e, t);
    var s = (t.flags & 128) !== 0;
    if (!r && !s) return o && Pf(t, n, !1), vn(e, t, l);
    r = t.stateNode, nS.current = t;
    var i = s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && s ? (t.child = ro(t, e.child, null, l), t.child = ro(t, null, i, l)) : st(e, t, i, l), t.memoizedState = r.state, o && Pf(t, n, !0), t.child
}

function Kh(e) {
    var t = e.stateNode;
    t.pendingContext ? Df(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Df(e, t.context, !1), ad(e, t.containerInfo)
}

function Yf(e, t, n, r, o) {
    return no(), td(o), t.flags |= 256, st(e, t, n, r), t.child
}
var rc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};

function oc(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}

function Gh(e, t, n) {
    var r = t.pendingProps,
        o = be.current,
        l = !1,
        s = (t.flags & 128) !== 0,
        i;
    if ((i = s) || (i = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0), i ? (l = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (o |= 1), ke(be, o & 1), e === null) return Qu(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (s = r.children, e = r.fallback, l ? (r = t.mode, l = t.child, s = {
        mode: "hidden",
        children: s
    }, !(r & 1) && l !== null ? (l.childLanes = 0, l.pendingProps = s) : l = Da(s, r, 0, null), e = dr(e, r, n, null), l.return = t, e.return = t, l.sibling = e, t.child = l, t.child.memoizedState = oc(n), t.memoizedState = rc, e) : hd(t, s));
    if (o = e.memoizedState, o !== null && (i = o.dehydrated, i !== null)) return rS(e, t, s, r, i, o, n);
    if (l) {
        l = r.fallback, s = t.mode, o = e.child, i = o.sibling;
        var u = {
            mode: "hidden",
            children: r.children
        };
        return !(s & 1) && t.child !== o ? (r = t.child, r.childLanes = 0, r.pendingProps = u, t.deletions = null) : (r = Kn(o, u), r.subtreeFlags = o.subtreeFlags & 14680064), i !== null ? l = Kn(i, l) : (l = dr(l, s, n, null), l.flags |= 2), l.return = t, r.return = t, r.sibling = l, t.child = r, r = l, l = t.child, s = e.child.memoizedState, s = s === null ? oc(n) : {
            baseLanes: s.baseLanes | n,
            cachePool: null,
            transitions: s.transitions
        }, l.memoizedState = s, l.childLanes = e.childLanes & ~n, t.memoizedState = rc, r
    }
    return l = e.child, e = l.sibling, r = Kn(l, {
        mode: "visible",
        children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function hd(e, t) {
    return t = Da({
        mode: "visible",
        children: t
    }, e.mode, 0, null), t.return = e, e.child = t
}

function ms(e, t, n, r) {
    return r !== null && td(r), ro(t, e.child, null, n), e = hd(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
}

function rS(e, t, n, r, o, l, s) {
    if (n) return t.flags & 256 ? (t.flags &= -257, r = tu(Error(D(422))), ms(e, t, s, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (l = r.fallback, o = t.mode, r = Da({
        mode: "visible",
        children: r.children
    }, o, 0, null), l = dr(l, o, s, null), l.flags |= 2, r.return = t, l.return = t, r.sibling = l, t.child = r, t.mode & 1 && ro(t, e.child, null, s), t.child.memoizedState = oc(s), t.memoizedState = rc, l);
    if (!(t.mode & 1)) return ms(e, t, s, null);
    if (o.data === "$!") {
        if (r = o.nextSibling && o.nextSibling.dataset, r) var i = r.dgst;
        return r = i, l = Error(D(419)), r = tu(l, r, void 0), ms(e, t, s, r)
    }
    if (i = (s & e.childLanes) !== 0, ft || i) {
        if (r = Qe, r !== null) {
            switch (s & -s) {
                case 4:
                    o = 2;
                    break;
                case 16:
                    o = 8;
                    break;
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                case 67108864:
                    o = 32;
                    break;
                case 536870912:
                    o = 268435456;
                    break;
                default:
                    o = 0
            }
            o = o & (r.suspendedLanes | s) ? 0 : o, o !== 0 && o !== l.retryLane && (l.retryLane = o, hn(e, o), zt(r, e, o, -1))
        }
        return wd(), r = tu(Error(D(421))), ms(e, t, s, r)
    }
    return o.data === "$?" ? (t.flags |= 128, t.child = e.child, t = vS.bind(null, e), o._reactRetry = t, null) : (e = l.treeContext, St = Hn(o.nextSibling), wt = t, De = !0, Ht = null, e !== null && (At[Tt++] = cn, At[Tt++] = dn, At[Tt++] = hr, cn = e.id, dn = e.overflow, hr = t), t = hd(t, r.children), t.flags |= 4096, t)
}

function Qf(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), Xu(e.return, t, n)
}

function nu(e, t, n, r, o) {
    var l = e.memoizedState;
    l === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: o
    } : (l.isBackwards = t, l.rendering = null, l.renderingStartTime = 0, l.last = r, l.tail = n, l.tailMode = o)
}

function qh(e, t, n) {
    var r = t.pendingProps,
        o = r.revealOrder,
        l = r.tail;
    if (st(e, t, r.children, n), r = be.current, r & 2) r = r & 1 | 2, t.flags |= 128;
    else {
        if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && Qf(e, n, t);
            else if (e.tag === 19) Qf(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (ke(be, r), !(t.mode & 1)) t.memoizedState = null;
    else switch (o) {
        case "forwards":
            for (n = t.child, o = null; n !== null;) e = n.alternate, e !== null && aa(e) === null && (o = n), n = n.sibling;
            n = o, n === null ? (o = t.child, t.child = null) : (o = n.sibling, n.sibling = null), nu(t, !1, o, n, l);
            break;
        case "backwards":
            for (n = null, o = t.child, t.child = null; o !== null;) {
                if (e = o.alternate, e !== null && aa(e) === null) {
                    t.child = o;
                    break
                }
                e = o.sibling, o.sibling = n, n = o, o = e
            }
            nu(t, !0, n, null, l);
            break;
        case "together":
            nu(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function Ms(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
}

function vn(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), gr |= t.lanes, !(n & t.childLanes)) return null;
    if (e !== null && t.child !== e.child) throw Error(D(153));
    if (t.child !== null) {
        for (e = t.child, n = Kn(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = Kn(e, e.pendingProps), n.return = t;
        n.sibling = null
    }
    return t.child
}

function oS(e, t, n) {
    switch (t.tag) {
        case 3:
            Kh(t), no();
            break;
        case 5:
            wh(t);
            break;
        case 1:
            pt(t.type) && ta(t);
            break;
        case 4:
            ad(t, t.stateNode.containerInfo);
            break;
        case 10:
            var r = t.type._context,
                o = t.memoizedProps.value;
            ke(oa, r._currentValue), r._currentValue = o;
            break;
        case 13:
            if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (ke(be, be.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? Gh(e, t, n) : (ke(be, be.current & 1), e = vn(e, t, n), e !== null ? e.sibling : null);
            ke(be, be.current & 1);
            break;
        case 19:
            if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                if (r) return qh(e, t, n);
                t.flags |= 128
            }
            if (o = t.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), ke(be, be.current), r) break;
            return null;
        case 22:
        case 23:
            return t.lanes = 0, zh(e, t, n)
    }
    return vn(e, t, n)
}
var Yh, lc, Qh, Xh;
Yh = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
lc = function() {};
Qh = function(e, t, n, r) {
    var o = e.memoizedProps;
    if (o !== r) {
        e = t.stateNode, ur(Zt.current);
        var l = null;
        switch (n) {
            case "input":
                o = Au(e, o), r = Au(e, r), l = [];
                break;
            case "select":
                o = Me({}, o, {
                    value: void 0
                }), r = Me({}, r, {
                    value: void 0
                }), l = [];
                break;
            case "textarea":
                o = Cu(e, o), r = Cu(e, r), l = [];
                break;
            default:
                typeof o.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Zs)
        }
        Du(n, r);
        var s;
        n = null;
        for (c in o)
            if (!r.hasOwnProperty(c) && o.hasOwnProperty(c) && o[c] != null)
                if (c === "style") {
                    var i = o[c];
                    for (s in i) i.hasOwnProperty(s) && (n || (n = {}), n[s] = "")
                } else c !== "dangerouslySetInnerHTML" && c !== "children" && c !== "suppressContentEditableWarning" && c !== "suppressHydrationWarning" && c !== "autoFocus" && (nl.hasOwnProperty(c) ? l || (l = []) : (l = l || []).push(c, null));
        for (c in r) {
            var u = r[c];
            if (i = o != null ? o[c] : void 0, r.hasOwnProperty(c) && u !== i && (u != null || i != null))
                if (c === "style")
                    if (i) {
                        for (s in i) !i.hasOwnProperty(s) || u && u.hasOwnProperty(s) || (n || (n = {}), n[s] = "");
                        for (s in u) u.hasOwnProperty(s) && i[s] !== u[s] && (n || (n = {}), n[s] = u[s])
                    } else n || (l || (l = []), l.push(c, n)), n = u;
            else c === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, i = i ? i.__html : void 0, u != null && i !== u && (l = l || []).push(c, u)) : c === "children" ? typeof u != "string" && typeof u != "number" || (l = l || []).push(c, "" + u) : c !== "suppressContentEditableWarning" && c !== "suppressHydrationWarning" && (nl.hasOwnProperty(c) ? (u != null && c === "onScroll" && Ae("scroll", e), l || i === u || (l = [])) : (l = l || []).push(c, u))
        }
        n && (l = l || []).push("style", n);
        var c = l;
        (t.updateQueue = c) && (t.flags |= 4)
    }
};
Xh = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function jo(e, t) {
    if (!De) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function rt(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
    if (t)
        for (var o = e.child; o !== null;) n |= o.lanes | o.childLanes, r |= o.subtreeFlags & 14680064, r |= o.flags & 14680064, o.return = e, o = o.sibling;
    else
        for (o = e.child; o !== null;) n |= o.lanes | o.childLanes, r |= o.subtreeFlags, r |= o.flags, o.return = e, o = o.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t
}

function lS(e, t, n) {
    var r = t.pendingProps;
    switch (ed(t), t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return rt(t), null;
        case 1:
            return pt(t.type) && ea(), rt(t), null;
        case 3:
            return r = t.stateNode, oo(), je(mt), je(lt), ud(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (ds(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Ht !== null && (mc(Ht), Ht = null))), lc(e, t), rt(t), null;
        case 5:
            id(t);
            var o = ur(pl.current);
            if (n = t.type, e !== null && t.stateNode != null) Qh(e, t, n, r, o), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(D(166));
                    return rt(t), null
                }
                if (e = ur(Zt.current), ds(t)) {
                    r = t.stateNode, n = t.type;
                    var l = t.memoizedProps;
                    switch (r[Qt] = t, r[fl] = l, e = (t.mode & 1) !== 0, n) {
                        case "dialog":
                            Ae("cancel", r), Ae("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            Ae("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (o = 0; o < Ho.length; o++) Ae(Ho[o], r);
                            break;
                        case "source":
                            Ae("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            Ae("error", r), Ae("load", r);
                            break;
                        case "details":
                            Ae("toggle", r);
                            break;
                        case "input":
                            of (r, l), Ae("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!l.multiple
                            }, Ae("invalid", r);
                            break;
                        case "textarea":
                            sf(r, l), Ae("invalid", r)
                    }
                    Du(n, l), o = null;
                    for (var s in l)
                        if (l.hasOwnProperty(s)) {
                            var i = l[s];
                            s === "children" ? typeof i == "string" ? r.textContent !== i && (l.suppressHydrationWarning !== !0 && cs(r.textContent, i, e), o = ["children", i]) : typeof i == "number" && r.textContent !== "" + i && (l.suppressHydrationWarning !== !0 && cs(r.textContent, i, e), o = ["children", "" + i]) : nl.hasOwnProperty(s) && i != null && s === "onScroll" && Ae("scroll", r)
                        }
                    switch (n) {
                        case "input":
                            ns(r), lf(r, l, !0);
                            break;
                        case "textarea":
                            ns(r), af(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof l.onClick == "function" && (r.onclick = Zs)
                    }
                    r = o, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    s = o.nodeType === 9 ? o : o.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = Np(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = s.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = s.createElement(n, {
                        is: r.is
                    }) : (e = s.createElement(n), n === "select" && (s = e, r.multiple ? s.multiple = !0 : r.size && (s.size = r.size))) : e = s.createElementNS(e, n), e[Qt] = t, e[fl] = r, Yh(e, t, !1, !1), t.stateNode = e;
                    e: {
                        switch (s = Pu(n, r), n) {
                            case "dialog":
                                Ae("cancel", e), Ae("close", e), o = r;
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                Ae("load", e), o = r;
                                break;
                            case "video":
                            case "audio":
                                for (o = 0; o < Ho.length; o++) Ae(Ho[o], e);
                                o = r;
                                break;
                            case "source":
                                Ae("error", e), o = r;
                                break;
                            case "img":
                            case "image":
                            case "link":
                                Ae("error", e), Ae("load", e), o = r;
                                break;
                            case "details":
                                Ae("toggle", e), o = r;
                                break;
                            case "input":
                                of (e, r), o = Au(e, r), Ae("invalid", e);
                                break;
                            case "option":
                                o = r;
                                break;
                            case "select":
                                e._wrapperState = {
                                    wasMultiple: !!r.multiple
                                }, o = Me({}, r, {
                                    value: void 0
                                }), Ae("invalid", e);
                                break;
                            case "textarea":
                                sf(e, r), o = Cu(e, r), Ae("invalid", e);
                                break;
                            default:
                                o = r
                        }
                        Du(n, o),
                        i = o;
                        for (l in i)
                            if (i.hasOwnProperty(l)) {
                                var u = i[l];
                                l === "style" ? Ap(e, u) : l === "dangerouslySetInnerHTML" ? (u = u ? u.__html : void 0, u != null && Rp(e, u)) : l === "children" ? typeof u == "string" ? (n !== "textarea" || u !== "") && rl(e, u) : typeof u == "number" && rl(e, "" + u) : l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && l !== "autoFocus" && (nl.hasOwnProperty(l) ? u != null && l === "onScroll" && Ae("scroll", e) : u != null && Fc(e, l, u, s))
                            }
                        switch (n) {
                            case "input":
                                ns(e), lf(e, r, !1);
                                break;
                            case "textarea":
                                ns(e), af(e);
                                break;
                            case "option":
                                r.value != null && e.setAttribute("value", "" + Gn(r.value));
                                break;
                            case "select":
                                e.multiple = !!r.multiple, l = r.value, l != null ? Gr(e, !!r.multiple, l, !1) : r.defaultValue != null && Gr(e, !!r.multiple, r.defaultValue, !0);
                                break;
                            default:
                                typeof o.onClick == "function" && (e.onclick = Zs)
                        }
                        switch (n) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                r = !!r.autoFocus;
                                break e;
                            case "img":
                                r = !0;
                                break e;
                            default:
                                r = !1
                        }
                    }
                    r && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
            }
            return rt(t), null;
        case 6:
            if (e && t.stateNode != null) Xh(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(D(166));
                if (n = ur(pl.current), ur(Zt.current), ds(t)) {
                    if (r = t.stateNode, n = t.memoizedProps, r[Qt] = t, (l = r.nodeValue !== n) && (e = wt, e !== null)) switch (e.tag) {
                        case 3:
                            cs(r.nodeValue, n, (e.mode & 1) !== 0);
                            break;
                        case 5:
                            e.memoizedProps.suppressHydrationWarning !== !0 && cs(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                    l && (t.flags |= 4)
                } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Qt] = t, t.stateNode = r
            }
            return rt(t), null;
        case 13:
            if (je(be), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                if (De && St !== null && t.mode & 1 && !(t.flags & 128)) ph(), no(), t.flags |= 98560, l = !1;
                else if (l = ds(t), r !== null && r.dehydrated !== null) {
                    if (e === null) {
                        if (!l) throw Error(D(318));
                        if (l = t.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(D(317));
                        l[Qt] = t
                    } else no(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    rt(t), l = !1
                } else Ht !== null && (mc(Ht), Ht = null), l = !0;
                if (!l) return t.flags & 65536 ? t : null
            }
            return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || be.current & 1 ? qe === 0 && (qe = 3) : wd())), t.updateQueue !== null && (t.flags |= 4), rt(t), null);
        case 4:
            return oo(), lc(e, t), e === null && cl(t.stateNode.containerInfo), rt(t), null;
        case 10:
            return od(t.type._context), rt(t), null;
        case 17:
            return pt(t.type) && ea(), rt(t), null;
        case 19:
            if (je(be), l = t.memoizedState, l === null) return rt(t), null;
            if (r = (t.flags & 128) !== 0, s = l.rendering, s === null)
                if (r) jo(l, !1);
                else {
                    if (qe !== 0 || e !== null && e.flags & 128)
                        for (e = t.child; e !== null;) {
                            if (s = aa(e), s !== null) {
                                for (t.flags |= 128, jo(l, !1), r = s.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) l = n, e = r, l.flags &= 14680066, s = l.alternate, s === null ? (l.childLanes = 0, l.lanes = e, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = s.childLanes, l.lanes = s.lanes, l.child = s.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = s.memoizedProps, l.memoizedState = s.memoizedState, l.updateQueue = s.updateQueue, l.type = s.type, e = s.dependencies, l.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return ke(be, be.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    l.tail !== null && He() > so && (t.flags |= 128, r = !0, jo(l, !1), t.lanes = 4194304)
                }
            else {
                if (!r)
                    if (e = aa(s), e !== null) {
                        if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), jo(l, !0), l.tail === null && l.tailMode === "hidden" && !s.alternate && !De) return rt(t), null
                    } else 2 * He() - l.renderingStartTime > so && n !== 1073741824 && (t.flags |= 128, r = !0, jo(l, !1), t.lanes = 4194304);
                l.isBackwards ? (s.sibling = t.child, t.child = s) : (n = l.last, n !== null ? n.sibling = s : t.child = s, l.last = s)
            }
            return l.tail !== null ? (t = l.tail, l.rendering = t, l.tail = t.sibling, l.renderingStartTime = He(), t.sibling = null, n = be.current, ke(be, r ? n & 1 | 2 : n & 1), t) : (rt(t), null);
        case 22:
        case 23:
            return Sd(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? _t & 1073741824 && (rt(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : rt(t), null;
        case 24:
            return null;
        case 25:
            return null
    }
    throw Error(D(156, t.tag))
}

function sS(e, t) {
    switch (ed(t), t.tag) {
        case 1:
            return pt(t.type) && ea(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
            return oo(), je(mt), je(lt), ud(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 5:
            return id(t), null;
        case 13:
            if (je(be), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                if (t.alternate === null) throw Error(D(340));
                no()
            }
            return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
            return je(be), null;
        case 4:
            return oo(), null;
        case 10:
            return od(t.type._context), null;
        case 22:
        case 23:
            return Sd(), null;
        case 24:
            return null;
        default:
            return null
    }
}
var ps = !1,
    ot = !1,
    aS = typeof WeakSet == "function" ? WeakSet : Set,
    z = null;

function Wr(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function") try {
            n(null)
        } catch (r) {
            Fe(e, t, r)
        } else n.current = null
}

function sc(e, t, n) {
    try {
        n()
    } catch (r) {
        Fe(e, t, r)
    }
}
var Xf = !1;

function iS(e, t) {
    if (Bu = Qs, e = th(), Jc(e)) {
        if ("selectionStart" in e) var n = {
            start: e.selectionStart,
            end: e.selectionEnd
        };
        else e: {
            n = (n = e.ownerDocument) && n.defaultView || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
                n = r.anchorNode;
                var o = r.anchorOffset,
                    l = r.focusNode;
                r = r.focusOffset;
                try {
                    n.nodeType, l.nodeType
                } catch {
                    n = null;
                    break e
                }
                var s = 0,
                    i = -1,
                    u = -1,
                    c = 0,
                    f = 0,
                    d = e,
                    g = null;
                t: for (;;) {
                    for (var S; d !== n || o !== 0 && d.nodeType !== 3 || (i = s + o), d !== l || r !== 0 && d.nodeType !== 3 || (u = s + r), d.nodeType === 3 && (s += d.nodeValue.length), (S = d.firstChild) !== null;) g = d, d = S;
                    for (;;) {
                        if (d === e) break t;
                        if (g === n && ++c === o && (i = s), g === l && ++f === r && (u = s), (S = d.nextSibling) !== null) break;
                        d = g, g = d.parentNode
                    }
                    d = S
                }
                n = i === -1 || u === -1 ? null : {
                    start: i,
                    end: u
                }
            } else n = null
        }
        n = n || {
            start: 0,
            end: 0
        }
    } else n = null;
    for (zu = {
            focusedElem: e,
            selectionRange: n
        }, Qs = !1, z = t; z !== null;)
        if (t = z, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, z = e;
        else
            for (; z !== null;) {
                t = z;
                try {
                    var v = t.alternate;
                    if (t.flags & 1024) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (v !== null) {
                                var _ = v.memoizedProps,
                                    R = v.memoizedState,
                                    p = t.stateNode,
                                    m = p.getSnapshotBeforeUpdate(t.elementType === t.type ? _ : Vt(t.type, _), R);
                                p.__reactInternalSnapshotBeforeUpdate = m
                            }
                            break;
                        case 3:
                            var h = t.stateNode.containerInfo;
                            h.nodeType === 1 ? h.textContent = "" : h.nodeType === 9 && h.documentElement && h.removeChild(h.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(D(163))
                    }
                } catch (x) {
                    Fe(t, t.return, x)
                }
                if (e = t.sibling, e !== null) {
                    e.return = t.return, z = e;
                    break
                }
                z = t.return
            }
    return v = Xf, Xf = !1, v
}

function Qo(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
        var o = r = r.next;
        do {
            if ((o.tag & e) === e) {
                var l = o.destroy;
                o.destroy = void 0, l !== void 0 && sc(t, n, l)
            }
            o = o.next
        } while (o !== r)
    }
}

function Ca(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}

function ac(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
            case 5:
                e = n;
                break;
            default:
                e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}

function Jh(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, Jh(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Qt], delete t[fl], delete t[Gu], delete t[z_], delete t[W_])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function Zh(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function Jf(e) {
    e: for (;;) {
        for (; e.sibling === null;) {
            if (e.return === null || Zh(e.return)) return null;
            e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
            if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
            e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
    }
}

function ic(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Zs));
    else if (r !== 4 && (e = e.child, e !== null))
        for (ic(e, t, n), e = e.sibling; e !== null;) ic(e, t, n), e = e.sibling
}

function uc(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (uc(e, t, n), e = e.sibling; e !== null;) uc(e, t, n), e = e.sibling
}
var Ze = null,
    $t = !1;

function An(e, t, n) {
    for (n = n.child; n !== null;) ev(e, t, n), n = n.sibling
}

function ev(e, t, n) {
    if (Jt && typeof Jt.onCommitFiberUnmount == "function") try {
        Jt.onCommitFiberUnmount(Ea, n)
    } catch {}
    switch (n.tag) {
        case 5:
            ot || Wr(n, t);
        case 6:
            var r = Ze,
                o = $t;
            Ze = null, An(e, t, n), Ze = r, $t = o, Ze !== null && ($t ? (e = Ze, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : Ze.removeChild(n.stateNode));
            break;
        case 18:
            Ze !== null && ($t ? (e = Ze, n = n.stateNode, e.nodeType === 8 ? Yi(e.parentNode, n) : e.nodeType === 1 && Yi(e, n), al(e)) : Yi(Ze, n.stateNode));
            break;
        case 4:
            r = Ze, o = $t, Ze = n.stateNode.containerInfo, $t = !0, An(e, t, n), Ze = r, $t = o;
            break;
        case 0:
        case 11:
        case 14:
        case 15:
            if (!ot && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                o = r = r.next;
                do {
                    var l = o,
                        s = l.destroy;
                    l = l.tag, s !== void 0 && (l & 2 || l & 4) && sc(n, t, s), o = o.next
                } while (o !== r)
            }
            An(e, t, n);
            break;
        case 1:
            if (!ot && (Wr(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
            } catch (i) {
                Fe(n, t, i)
            }
            An(e, t, n);
            break;
        case 21:
            An(e, t, n);
            break;
        case 22:
            n.mode & 1 ? (ot = (r = ot) || n.memoizedState !== null, An(e, t, n), ot = r) : An(e, t, n);
            break;
        default:
            An(e, t, n)
    }
}

function Zf(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new aS), t.forEach(function(r) {
            var o = gS.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(o, o))
        })
    }
}

function Ut(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var o = n[r];
            try {
                var l = e,
                    s = t,
                    i = s;
                e: for (; i !== null;) {
                    switch (i.tag) {
                        case 5:
                            Ze = i.stateNode, $t = !1;
                            break e;
                        case 3:
                            Ze = i.stateNode.containerInfo, $t = !0;
                            break e;
                        case 4:
                            Ze = i.stateNode.containerInfo, $t = !0;
                            break e
                    }
                    i = i.return
                }
                if (Ze === null) throw Error(D(160));
                ev(l, s, o), Ze = null, $t = !1;
                var u = o.alternate;
                u !== null && (u.return = null), o.return = null
            } catch (c) {
                Fe(o, t, c)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null;) tv(t, e), t = t.sibling
}

function tv(e, t) {
    var n = e.alternate,
        r = e.flags;
    switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
            if (Ut(t, e), Gt(e), r & 4) {
                try {
                    Qo(3, e, e.return), Ca(3, e)
                } catch (_) {
                    Fe(e, e.return, _)
                }
                try {
                    Qo(5, e, e.return)
                } catch (_) {
                    Fe(e, e.return, _)
                }
            }
            break;
        case 1:
            Ut(t, e), Gt(e), r & 512 && n !== null && Wr(n, n.return);
            break;
        case 5:
            if (Ut(t, e), Gt(e), r & 512 && n !== null && Wr(n, n.return), e.flags & 32) {
                var o = e.stateNode;
                try {
                    rl(o, "")
                } catch (_) {
                    Fe(e, e.return, _)
                }
            }
            if (r & 4 && (o = e.stateNode, o != null)) {
                var l = e.memoizedProps,
                    s = n !== null ? n.memoizedProps : l,
                    i = e.type,
                    u = e.updateQueue;
                if (e.updateQueue = null, u !== null) try {
                    i === "input" && l.type === "radio" && l.name != null && Ep(o, l), Pu(i, s);
                    var c = Pu(i, l);
                    for (s = 0; s < u.length; s += 2) {
                        var f = u[s],
                            d = u[s + 1];
                        f === "style" ? Ap(o, d) : f === "dangerouslySetInnerHTML" ? Rp(o, d) : f === "children" ? rl(o, d) : Fc(o, f, d, c)
                    }
                    switch (i) {
                        case "input":
                            Tu(o, l);
                            break;
                        case "textarea":
                            xp(o, l);
                            break;
                        case "select":
                            var g = o._wrapperState.wasMultiple;
                            o._wrapperState.wasMultiple = !!l.multiple;
                            var S = l.value;
                            S != null ? Gr(o, !!l.multiple, S, !1) : g !== !!l.multiple && (l.defaultValue != null ? Gr(o, !!l.multiple, l.defaultValue, !0) : Gr(o, !!l.multiple, l.multiple ? [] : "", !1))
                    }
                    o[fl] = l
                } catch (_) {
                    Fe(e, e.return, _)
                }
            }
            break;
        case 6:
            if (Ut(t, e), Gt(e), r & 4) {
                if (e.stateNode === null) throw Error(D(162));
                o = e.stateNode, l = e.memoizedProps;
                try {
                    o.nodeValue = l
                } catch (_) {
                    Fe(e, e.return, _)
                }
            }
            break;
        case 3:
            if (Ut(t, e), Gt(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                al(t.containerInfo)
            } catch (_) {
                Fe(e, e.return, _)
            }
            break;
        case 4:
            Ut(t, e), Gt(e);
            break;
        case 13:
            Ut(t, e), Gt(e), o = e.child, o.flags & 8192 && (l = o.memoizedState !== null, o.stateNode.isHidden = l, !l || o.alternate !== null && o.alternate.memoizedState !== null || (yd = He())), r & 4 && Zf(e);
            break;
        case 22:
            if (f = n !== null && n.memoizedState !== null, e.mode & 1 ? (ot = (c = ot) || f, Ut(t, e), ot = c) : Ut(t, e), Gt(e), r & 8192) {
                if (c = e.memoizedState !== null, (e.stateNode.isHidden = c) && !f && e.mode & 1)
                    for (z = e, f = e.child; f !== null;) {
                        for (d = z = f; z !== null;) {
                            switch (g = z, S = g.child, g.tag) {
                                case 0:
                                case 11:
                                case 14:
                                case 15:
                                    Qo(4, g, g.return);
                                    break;
                                case 1:
                                    Wr(g, g.return);
                                    var v = g.stateNode;
                                    if (typeof v.componentWillUnmount == "function") {
                                        r = g, n = g.return;
                                        try {
                                            t = r, v.props = t.memoizedProps, v.state = t.memoizedState, v.componentWillUnmount()
                                        } catch (_) {
                                            Fe(r, n, _)
                                        }
                                    }
                                    break;
                                case 5:
                                    Wr(g, g.return);
                                    break;
                                case 22:
                                    if (g.memoizedState !== null) {
                                        tm(d);
                                        continue
                                    }
                            }
                            S !== null ? (S.return = g, z = S) : tm(d)
                        }
                        f = f.sibling
                    }
                e: for (f = null, d = e;;) {
                    if (d.tag === 5) {
                        if (f === null) {
                            f = d;
                            try {
                                o = d.stateNode, c ? (l = o.style, typeof l.setProperty == "function" ? l.setProperty("display", "none", "important") : l.display = "none") : (i = d.stateNode, u = d.memoizedProps.style, s = u != null && u.hasOwnProperty("display") ? u.display : null, i.style.display = kp("display", s))
                            } catch (_) {
                                Fe(e, e.return, _)
                            }
                        }
                    } else if (d.tag === 6) {
                        if (f === null) try {
                            d.stateNode.nodeValue = c ? "" : d.memoizedProps
                        } catch (_) {
                            Fe(e, e.return, _)
                        }
                    } else if ((d.tag !== 22 && d.tag !== 23 || d.memoizedState === null || d === e) && d.child !== null) {
                        d.child.return = d, d = d.child;
                        continue
                    }
                    if (d === e) break e;
                    for (; d.sibling === null;) {
                        if (d.return === null || d.return === e) break e;
                        f === d && (f = null), d = d.return
                    }
                    f === d && (f = null), d.sibling.return = d.return, d = d.sibling
                }
            }
            break;
        case 19:
            Ut(t, e), Gt(e), r & 4 && Zf(e);
            break;
        case 21:
            break;
        default:
            Ut(t, e), Gt(e)
    }
}

function Gt(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null;) {
                    if (Zh(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(D(160))
            }
            switch (r.tag) {
                case 5:
                    var o = r.stateNode;
                    r.flags & 32 && (rl(o, ""), r.flags &= -33);
                    var l = Jf(e);
                    uc(e, l, o);
                    break;
                case 3:
                case 4:
                    var s = r.stateNode.containerInfo,
                        i = Jf(e);
                    ic(e, i, s);
                    break;
                default:
                    throw Error(D(161))
            }
        }
        catch (u) {
            Fe(e, e.return, u)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}

function uS(e, t, n) {
    z = e, nv(e)
}

function nv(e, t, n) {
    for (var r = (e.mode & 1) !== 0; z !== null;) {
        var o = z,
            l = o.child;
        if (o.tag === 22 && r) {
            var s = o.memoizedState !== null || ps;
            if (!s) {
                var i = o.alternate,
                    u = i !== null && i.memoizedState !== null || ot;
                i = ps;
                var c = ot;
                if (ps = s, (ot = u) && !c)
                    for (z = o; z !== null;) s = z, u = s.child, s.tag === 22 && s.memoizedState !== null ? nm(o) : u !== null ? (u.return = s, z = u) : nm(o);
                for (; l !== null;) z = l, nv(l), l = l.sibling;
                z = o, ps = i, ot = c
            }
            em(e)
        } else o.subtreeFlags & 8772 && l !== null ? (l.return = o, z = l) : em(e)
    }
}

function em(e) {
    for (; z !== null;) {
        var t = z;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772) switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        ot || Ca(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !ot)
                            if (n === null) r.componentDidMount();
                            else {
                                var o = t.elementType === t.type ? n.memoizedProps : Vt(t.type, n.memoizedProps);
                                r.componentDidUpdate(o, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var l = t.updateQueue;
                        l !== null && Mf(t, l, r);
                        break;
                    case 3:
                        var s = t.updateQueue;
                        if (s !== null) {
                            if (n = null, t.child !== null) switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                            }
                            Mf(t, s, n)
                        }
                        break;
                    case 5:
                        var i = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = i;
                            var u = t.memoizedProps;
                            switch (t.type) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    u.autoFocus && n.focus();
                                    break;
                                case "img":
                                    u.src && (n.src = u.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var c = t.alternate;
                            if (c !== null) {
                                var f = c.memoizedState;
                                if (f !== null) {
                                    var d = f.dehydrated;
                                    d !== null && al(d)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(D(163))
                }
                ot || t.flags & 512 && ac(t)
            } catch (g) {
                Fe(t, t.return, g)
            }
        }
        if (t === e) {
            z = null;
            break
        }
        if (n = t.sibling, n !== null) {
            n.return = t.return, z = n;
            break
        }
        z = t.return
    }
}

function tm(e) {
    for (; z !== null;) {
        var t = z;
        if (t === e) {
            z = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return, z = n;
            break
        }
        z = t.return
    }
}

function nm(e) {
    for (; z !== null;) {
        var t = z;
        try {
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    var n = t.return;
                    try {
                        Ca(4, t)
                    } catch (u) {
                        Fe(t, n, u)
                    }
                    break;
                case 1:
                    var r = t.stateNode;
                    if (typeof r.componentDidMount == "function") {
                        var o = t.return;
                        try {
                            r.componentDidMount()
                        } catch (u) {
                            Fe(t, o, u)
                        }
                    }
                    var l = t.return;
                    try {
                        ac(t)
                    } catch (u) {
                        Fe(t, l, u)
                    }
                    break;
                case 5:
                    var s = t.return;
                    try {
                        ac(t)
                    } catch (u) {
                        Fe(t, s, u)
                    }
            }
        } catch (u) {
            Fe(t, t.return, u)
        }
        if (t === e) {
            z = null;
            break
        }
        var i = t.sibling;
        if (i !== null) {
            i.return = t.return, z = i;
            break
        }
        z = t.return
    }
}
var cS = Math.ceil,
    ca = gn.ReactCurrentDispatcher,
    vd = gn.ReactCurrentOwner,
    Lt = gn.ReactCurrentBatchConfig,
    ve = 0,
    Qe = null,
    Be = null,
    et = 0,
    _t = 0,
    Kr = Qn(0),
    qe = 0,
    yl = null,
    gr = 0,
    La = 0,
    gd = 0,
    Xo = null,
    dt = null,
    yd = 0,
    so = 1 / 0,
    an = null,
    da = !1,
    cc = null,
    zn = null,
    hs = !1,
    bn = null,
    fa = 0,
    Jo = 0,
    dc = null,
    Us = -1,
    Fs = 0;

function at() {
    return ve & 6 ? He() : Us !== -1 ? Us : Us = He()
}

function Wn(e) {
    return e.mode & 1 ? ve & 2 && et !== 0 ? et & -et : G_.transition !== null ? (Fs === 0 && (Fs = Fp()), Fs) : (e = we, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Kp(e.type)), e) : 1
}

function zt(e, t, n, r) {
    if (50 < Jo) throw Jo = 0, dc = null, Error(D(185));
    xl(e, n, r), (!(ve & 2) || e !== Qe) && (e === Qe && (!(ve & 2) && (La |= n), qe === 4 && Pn(e, et)), ht(e, r), n === 1 && ve === 0 && !(t.mode & 1) && (so = He() + 500, Aa && Xn()))
}

function ht(e, t) {
    var n = e.callbackNode;
    G0(e, t);
    var r = Ys(e, e === Qe ? et : 0);
    if (r === 0) n !== null && df(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
        if (n != null && df(n), t === 1) e.tag === 0 ? K_(rm.bind(null, e)) : dh(rm.bind(null, e)), H_(function() {
            !(ve & 6) && Xn()
        }), n = null;
        else {
            switch (Vp(r)) {
                case 1:
                    n = zc;
                    break;
                case 4:
                    n = Mp;
                    break;
                case 16:
                    n = qs;
                    break;
                case 536870912:
                    n = Up;
                    break;
                default:
                    n = qs
            }
            n = cv(n, rv.bind(null, e))
        }
        e.callbackPriority = t, e.callbackNode = n
    }
}

function rv(e, t) {
    if (Us = -1, Fs = 0, ve & 6) throw Error(D(327));
    var n = e.callbackNode;
    if (Jr() && e.callbackNode !== n) return null;
    var r = Ys(e, e === Qe ? et : 0);
    if (r === 0) return null;
    if (r & 30 || r & e.expiredLanes || t) t = ma(e, r);
    else {
        t = r;
        var o = ve;
        ve |= 2;
        var l = lv();
        (Qe !== e || et !== t) && (an = null, so = He() + 500, cr(e, t));
        do try {
            mS();
            break
        } catch (i) {
            ov(e, i)
        }
        while (!0);
        rd(), ca.current = l, ve = o, Be !== null ? t = 0 : (Qe = null, et = 0, t = qe)
    }
    if (t !== 0) {
        if (t === 2 && (o = Uu(e), o !== 0 && (r = o, t = fc(e, o))), t === 1) throw n = yl, cr(e, 0), Pn(e, r), ht(e, He()), n;
        if (t === 6) Pn(e, r);
        else {
            if (o = e.current.alternate, !(r & 30) && !dS(o) && (t = ma(e, r), t === 2 && (l = Uu(e), l !== 0 && (r = l, t = fc(e, l))), t === 1)) throw n = yl, cr(e, 0), Pn(e, r), ht(e, He()), n;
            switch (e.finishedWork = o, e.finishedLanes = r, t) {
                case 0:
                case 1:
                    throw Error(D(345));
                case 2:
                    or(e, dt, an);
                    break;
                case 3:
                    if (Pn(e, r), (r & 130023424) === r && (t = yd + 500 - He(), 10 < t)) {
                        if (Ys(e, 0) !== 0) break;
                        if (o = e.suspendedLanes, (o & r) !== r) {
                            at(), e.pingedLanes |= e.suspendedLanes & o;
                            break
                        }
                        e.timeoutHandle = Ku(or.bind(null, e, dt, an), t);
                        break
                    }
                    or(e, dt, an);
                    break;
                case 4:
                    if (Pn(e, r), (r & 4194240) === r) break;
                    for (t = e.eventTimes, o = -1; 0 < r;) {
                        var s = 31 - Bt(r);
                        l = 1 << s, s = t[s], s > o && (o = s), r &= ~l
                    }
                    if (r = o, r = He() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * cS(r / 1960)) - r, 10 < r) {
                        e.timeoutHandle = Ku(or.bind(null, e, dt, an), r);
                        break
                    }
                    or(e, dt, an);
                    break;
                case 5:
                    or(e, dt, an);
                    break;
                default:
                    throw Error(D(329))
            }
        }
    }
    return ht(e, He()), e.callbackNode === n ? rv.bind(null, e) : null
}

function fc(e, t) {
    var n = Xo;
    return e.current.memoizedState.isDehydrated && (cr(e, t).flags |= 256), e = ma(e, t), e !== 2 && (t = dt, dt = n, t !== null && mc(t)), e
}

function mc(e) {
    dt === null ? dt = e : dt.push.apply(dt, e)
}

function dS(e) {
    for (var t = e;;) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores, n !== null))
                for (var r = 0; r < n.length; r++) {
                    var o = n[r],
                        l = o.getSnapshot;
                    o = o.value;
                    try {
                        if (!Wt(l(), o)) return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return !0;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return !0
}

function Pn(e, t) {
    for (t &= ~gd, t &= ~La, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - Bt(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function rm(e) {
    if (ve & 6) throw Error(D(327));
    Jr();
    var t = Ys(e, 0);
    if (!(t & 1)) return ht(e, He()), null;
    var n = ma(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = Uu(e);
        r !== 0 && (t = r, n = fc(e, r))
    }
    if (n === 1) throw n = yl, cr(e, 0), Pn(e, t), ht(e, He()), n;
    if (n === 6) throw Error(D(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, or(e, dt, an), ht(e, He()), null
}

function _d(e, t) {
    var n = ve;
    ve |= 1;
    try {
        return e(t)
    } finally {
        ve = n, ve === 0 && (so = He() + 500, Aa && Xn())
    }
}

function yr(e) {
    bn !== null && bn.tag === 0 && !(ve & 6) && Jr();
    var t = ve;
    ve |= 1;
    var n = Lt.transition,
        r = we;
    try {
        if (Lt.transition = null, we = 1, e) return e()
    } finally {
        we = r, Lt.transition = n, ve = t, !(ve & 6) && Xn()
    }
}

function Sd() {
    _t = Kr.current, je(Kr)
}

function cr(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, $_(n)), Be !== null)
        for (n = Be.return; n !== null;) {
            var r = n;
            switch (ed(r), r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && ea();
                    break;
                case 3:
                    oo(), je(mt), je(lt), ud();
                    break;
                case 5:
                    id(r);
                    break;
                case 4:
                    oo();
                    break;
                case 13:
                    je(be);
                    break;
                case 19:
                    je(be);
                    break;
                case 10:
                    od(r.type._context);
                    break;
                case 22:
                case 23:
                    Sd()
            }
            n = n.return
        }
    if (Qe = e, Be = e = Kn(e.current, null), et = _t = t, qe = 0, yl = null, gd = La = gr = 0, dt = Xo = null, ir !== null) {
        for (t = 0; t < ir.length; t++)
            if (n = ir[t], r = n.interleaved, r !== null) {
                n.interleaved = null;
                var o = r.next,
                    l = n.pending;
                if (l !== null) {
                    var s = l.next;
                    l.next = o, r.next = s
                }
                n.pending = r
            }
        ir = null
    }
    return e
}

function ov(e, t) {
    do {
        var n = Be;
        try {
            if (rd(), bs.current = ua, ia) {
                for (var r = Ie.memoizedState; r !== null;) {
                    var o = r.queue;
                    o !== null && (o.pending = null), r = r.next
                }
                ia = !1
            }
            if (vr = 0, Ye = Ge = Ie = null, Yo = !1, hl = 0, vd.current = null, n === null || n.return === null) {
                qe = 1, yl = t, Be = null;
                break
            }
            e: {
                var l = e,
                    s = n.return,
                    i = n,
                    u = t;
                if (t = et, i.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
                    var c = u,
                        f = i,
                        d = f.tag;
                    if (!(f.mode & 1) && (d === 0 || d === 11 || d === 15)) {
                        var g = f.alternate;
                        g ? (f.updateQueue = g.updateQueue, f.memoizedState = g.memoizedState, f.lanes = g.lanes) : (f.updateQueue = null, f.memoizedState = null)
                    }
                    var S = zf(s);
                    if (S !== null) {
                        S.flags &= -257, Wf(S, s, i, l, t), S.mode & 1 && Bf(l, c, t), t = S, u = c;
                        var v = t.updateQueue;
                        if (v === null) {
                            var _ = new Set;
                            _.add(u), t.updateQueue = _
                        } else v.add(u);
                        break e
                    } else {
                        if (!(t & 1)) {
                            Bf(l, c, t), wd();
                            break e
                        }
                        u = Error(D(426))
                    }
                } else if (De && i.mode & 1) {
                    var R = zf(s);
                    if (R !== null) {
                        !(R.flags & 65536) && (R.flags |= 256), Wf(R, s, i, l, t), td(lo(u, i));
                        break e
                    }
                }
                l = u = lo(u, i),
                qe !== 4 && (qe = 2),
                Xo === null ? Xo = [l] : Xo.push(l),
                l = s;do {
                    switch (l.tag) {
                        case 3:
                            l.flags |= 65536, t &= -t, l.lanes |= t;
                            var p = $h(l, u, t);
                            If(l, p);
                            break e;
                        case 1:
                            i = u;
                            var m = l.type,
                                h = l.stateNode;
                            if (!(l.flags & 128) && (typeof m.getDerivedStateFromError == "function" || h !== null && typeof h.componentDidCatch == "function" && (zn === null || !zn.has(h)))) {
                                l.flags |= 65536, t &= -t, l.lanes |= t;
                                var x = Hh(l, i, t);
                                If(l, x);
                                break e
                            }
                    }
                    l = l.return
                } while (l !== null)
            }
            av(n)
        } catch (k) {
            t = k, Be === n && n !== null && (Be = n = n.return);
            continue
        }
        break
    } while (!0)
}

function lv() {
    var e = ca.current;
    return ca.current = ua, e === null ? ua : e
}

function wd() {
    (qe === 0 || qe === 3 || qe === 2) && (qe = 4), Qe === null || !(gr & 268435455) && !(La & 268435455) || Pn(Qe, et)
}

function ma(e, t) {
    var n = ve;
    ve |= 2;
    var r = lv();
    (Qe !== e || et !== t) && (an = null, cr(e, t));
    do try {
        fS();
        break
    } catch (o) {
        ov(e, o)
    }
    while (!0);
    if (rd(), ve = n, ca.current = r, Be !== null) throw Error(D(261));
    return Qe = null, et = 0, qe
}

function fS() {
    for (; Be !== null;) sv(Be)
}

function mS() {
    for (; Be !== null && !U0();) sv(Be)
}

function sv(e) {
    var t = uv(e.alternate, e, _t);
    e.memoizedProps = e.pendingProps, t === null ? av(e) : Be = t, vd.current = null
}

function av(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, t.flags & 32768) {
            if (n = sS(n, t), n !== null) {
                n.flags &= 32767, Be = n;
                return
            }
            if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
            else {
                qe = 6, Be = null;
                return
            }
        } else if (n = lS(n, t, _t), n !== null) {
            Be = n;
            return
        }
        if (t = t.sibling, t !== null) {
            Be = t;
            return
        }
        Be = t = e
    } while (t !== null);
    qe === 0 && (qe = 5)
}

function or(e, t, n) {
    var r = we,
        o = Lt.transition;
    try {
        Lt.transition = null, we = 1, pS(e, t, n, r)
    } finally {
        Lt.transition = o, we = r
    }
    return null
}

function pS(e, t, n, r) {
    do Jr(); while (bn !== null);
    if (ve & 6) throw Error(D(327));
    n = e.finishedWork;
    var o = e.finishedLanes;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(D(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var l = n.lanes | n.childLanes;
    if (q0(e, l), e === Qe && (Be = Qe = null, et = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || hs || (hs = !0, cv(qs, function() {
            return Jr(), null
        })), l = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || l) {
        l = Lt.transition, Lt.transition = null;
        var s = we;
        we = 1;
        var i = ve;
        ve |= 4, vd.current = null, iS(e, n), tv(n, e), O_(zu), Qs = !!Bu, zu = Bu = null, e.current = n, uS(n), F0(), ve = i, we = s, Lt.transition = l
    } else e.current = n;
    if (hs && (hs = !1, bn = e, fa = o), l = e.pendingLanes, l === 0 && (zn = null), H0(n.stateNode), ht(e, He()), t !== null)
        for (r = e.onRecoverableError, n = 0; n < t.length; n++) o = t[n], r(o.value, {
            componentStack: o.stack,
            digest: o.digest
        });
    if (da) throw da = !1, e = cc, cc = null, e;
    return fa & 1 && e.tag !== 0 && Jr(), l = e.pendingLanes, l & 1 ? e === dc ? Jo++ : (Jo = 0, dc = e) : Jo = 0, Xn(), null
}

function Jr() {
    if (bn !== null) {
        var e = Vp(fa),
            t = Lt.transition,
            n = we;
        try {
            if (Lt.transition = null, we = 16 > e ? 16 : e, bn === null) var r = !1;
            else {
                if (e = bn, bn = null, fa = 0, ve & 6) throw Error(D(331));
                var o = ve;
                for (ve |= 4, z = e.current; z !== null;) {
                    var l = z,
                        s = l.child;
                    if (z.flags & 16) {
                        var i = l.deletions;
                        if (i !== null) {
                            for (var u = 0; u < i.length; u++) {
                                var c = i[u];
                                for (z = c; z !== null;) {
                                    var f = z;
                                    switch (f.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            Qo(8, f, l)
                                    }
                                    var d = f.child;
                                    if (d !== null) d.return = f, z = d;
                                    else
                                        for (; z !== null;) {
                                            f = z;
                                            var g = f.sibling,
                                                S = f.return;
                                            if (Jh(f), f === c) {
                                                z = null;
                                                break
                                            }
                                            if (g !== null) {
                                                g.return = S, z = g;
                                                break
                                            }
                                            z = S
                                        }
                                }
                            }
                            var v = l.alternate;
                            if (v !== null) {
                                var _ = v.child;
                                if (_ !== null) {
                                    v.child = null;
                                    do {
                                        var R = _.sibling;
                                        _.sibling = null, _ = R
                                    } while (_ !== null)
                                }
                            }
                            z = l
                        }
                    }
                    if (l.subtreeFlags & 2064 && s !== null) s.return = l, z = s;
                    else e: for (; z !== null;) {
                        if (l = z, l.flags & 2048) switch (l.tag) {
                            case 0:
                            case 11:
                            case 15:
                                Qo(9, l, l.return)
                        }
                        var p = l.sibling;
                        if (p !== null) {
                            p.return = l.return, z = p;
                            break e
                        }
                        z = l.return
                    }
                }
                var m = e.current;
                for (z = m; z !== null;) {
                    s = z;
                    var h = s.child;
                    if (s.subtreeFlags & 2064 && h !== null) h.return = s, z = h;
                    else e: for (s = m; z !== null;) {
                        if (i = z, i.flags & 2048) try {
                            switch (i.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    Ca(9, i)
                            }
                        } catch (k) {
                            Fe(i, i.return, k)
                        }
                        if (i === s) {
                            z = null;
                            break e
                        }
                        var x = i.sibling;
                        if (x !== null) {
                            x.return = i.return, z = x;
                            break e
                        }
                        z = i.return
                    }
                }
                if (ve = o, Xn(), Jt && typeof Jt.onPostCommitFiberRoot == "function") try {
                    Jt.onPostCommitFiberRoot(Ea, e)
                } catch {}
                r = !0
            }
            return r
        } finally {
            we = n, Lt.transition = t
        }
    }
    return !1
}

function om(e, t, n) {
    t = lo(n, t), t = $h(e, t, 1), e = Bn(e, t, 1), t = at(), e !== null && (xl(e, 1, t), ht(e, t))
}

function Fe(e, t, n) {
    if (e.tag === 3) om(e, e, n);
    else
        for (; t !== null;) {
            if (t.tag === 3) {
                om(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (zn === null || !zn.has(r))) {
                    e = lo(n, e), e = Hh(t, e, 1), t = Bn(t, e, 1), e = at(), t !== null && (xl(t, 1, e), ht(t, e));
                    break
                }
            }
            t = t.return
        }
}

function hS(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = at(), e.pingedLanes |= e.suspendedLanes & n, Qe === e && (et & n) === n && (qe === 4 || qe === 3 && (et & 130023424) === et && 500 > He() - yd ? cr(e, 0) : gd |= n), ht(e, t)
}

function iv(e, t) {
    t === 0 && (e.mode & 1 ? (t = ls, ls <<= 1, !(ls & 130023424) && (ls = 4194304)) : t = 1);
    var n = at();
    e = hn(e, t), e !== null && (xl(e, t, n), ht(e, n))
}

function vS(e) {
    var t = e.memoizedState,
        n = 0;
    t !== null && (n = t.retryLane), iv(e, n)
}

function gS(e, t) {
    var n = 0;
    switch (e.tag) {
        case 13:
            var r = e.stateNode,
                o = e.memoizedState;
            o !== null && (n = o.retryLane);
            break;
        case 19:
            r = e.stateNode;
            break;
        default:
            throw Error(D(314))
    }
    r !== null && r.delete(t), iv(e, n)
}
var uv;
uv = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || mt.current) ft = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128)) return ft = !1, oS(e, t, n);
            ft = !!(e.flags & 131072)
        }
    else ft = !1, De && t.flags & 1048576 && fh(t, ra, t.index);
    switch (t.lanes = 0, t.tag) {
        case 2:
            var r = t.type;
            Ms(e, t), e = t.pendingProps;
            var o = to(t, lt.current);
            Xr(t, n), o = dd(null, t, r, e, o, n);
            var l = fd();
            return t.flags |= 1, typeof o == "object" && o !== null && typeof o.render == "function" && o.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, pt(r) ? (l = !0, ta(t)) : l = !1, t.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, sd(t), o.updater = Ta, t.stateNode = o, o._reactInternals = t, Zu(t, r, e, n), t = nc(null, t, r, !0, l, n)) : (t.tag = 0, De && l && Zc(t), st(null, t, o, n), t = t.child), t;
        case 16:
            r = t.elementType;
            e: {
                switch (Ms(e, t), e = t.pendingProps, o = r._init, r = o(r._payload), t.type = r, o = t.tag = _S(r), e = Vt(r, e), o) {
                    case 0:
                        t = tc(null, t, r, e, n);
                        break e;
                    case 1:
                        t = qf(null, t, r, e, n);
                        break e;
                    case 11:
                        t = Kf(null, t, r, e, n);
                        break e;
                    case 14:
                        t = Gf(null, t, r, Vt(r.type, e), n);
                        break e
                }
                throw Error(D(306, r, ""))
            }
            return t;
        case 0:
            return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Vt(r, o), tc(e, t, r, o, n);
        case 1:
            return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Vt(r, o), qf(e, t, r, o, n);
        case 3:
            e: {
                if (Kh(t), e === null) throw Error(D(387));r = t.pendingProps,
                l = t.memoizedState,
                o = l.element,
                vh(e, t),
                sa(t, r, null, n);
                var s = t.memoizedState;
                if (r = s.element, l.isDehydrated)
                    if (l = {
                            element: r,
                            isDehydrated: !1,
                            cache: s.cache,
                            pendingSuspenseBoundaries: s.pendingSuspenseBoundaries,
                            transitions: s.transitions
                        }, t.updateQueue.baseState = l, t.memoizedState = l, t.flags & 256) {
                        o = lo(Error(D(423)), t), t = Yf(e, t, r, n, o);
                        break e
                    } else if (r !== o) {
                    o = lo(Error(D(424)), t), t = Yf(e, t, r, n, o);
                    break e
                } else
                    for (St = Hn(t.stateNode.containerInfo.firstChild), wt = t, De = !0, Ht = null, n = Sh(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                else {
                    if (no(), r === o) {
                        t = vn(e, t, n);
                        break e
                    }
                    st(e, t, r, n)
                }
                t = t.child
            }
            return t;
        case 5:
            return wh(t), e === null && Qu(t), r = t.type, o = t.pendingProps, l = e !== null ? e.memoizedProps : null, s = o.children, Wu(r, o) ? s = null : l !== null && Wu(r, l) && (t.flags |= 32), Wh(e, t), st(e, t, s, n), t.child;
        case 6:
            return e === null && Qu(t), null;
        case 13:
            return Gh(e, t, n);
        case 4:
            return ad(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = ro(t, null, r, n) : st(e, t, r, n), t.child;
        case 11:
            return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Vt(r, o), Kf(e, t, r, o, n);
        case 7:
            return st(e, t, t.pendingProps, n), t.child;
        case 8:
            return st(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return st(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                if (r = t.type._context, o = t.pendingProps, l = t.memoizedProps, s = o.value, ke(oa, r._currentValue), r._currentValue = s, l !== null)
                    if (Wt(l.value, s)) {
                        if (l.children === o.children && !mt.current) {
                            t = vn(e, t, n);
                            break e
                        }
                    } else
                        for (l = t.child, l !== null && (l.return = t); l !== null;) {
                            var i = l.dependencies;
                            if (i !== null) {
                                s = l.child;
                                for (var u = i.firstContext; u !== null;) {
                                    if (u.context === r) {
                                        if (l.tag === 1) {
                                            u = fn(-1, n & -n), u.tag = 2;
                                            var c = l.updateQueue;
                                            if (c !== null) {
                                                c = c.shared;
                                                var f = c.pending;
                                                f === null ? u.next = u : (u.next = f.next, f.next = u), c.pending = u
                                            }
                                        }
                                        l.lanes |= n, u = l.alternate, u !== null && (u.lanes |= n), Xu(l.return, n, t), i.lanes |= n;
                                        break
                                    }
                                    u = u.next
                                }
                            } else if (l.tag === 10) s = l.type === t.type ? null : l.child;
                            else if (l.tag === 18) {
                                if (s = l.return, s === null) throw Error(D(341));
                                s.lanes |= n, i = s.alternate, i !== null && (i.lanes |= n), Xu(s, n, t), s = l.sibling
                            } else s = l.child;
                            if (s !== null) s.return = l;
                            else
                                for (s = l; s !== null;) {
                                    if (s === t) {
                                        s = null;
                                        break
                                    }
                                    if (l = s.sibling, l !== null) {
                                        l.return = s.return, s = l;
                                        break
                                    }
                                    s = s.return
                                }
                            l = s
                        }
                st(e, t, o.children, n),
                t = t.child
            }
            return t;
        case 9:
            return o = t.type, r = t.pendingProps.children, Xr(t, n), o = Ot(o), r = r(o), t.flags |= 1, st(e, t, r, n), t.child;
        case 14:
            return r = t.type, o = Vt(r, t.pendingProps), o = Vt(r.type, o), Gf(e, t, r, o, n);
        case 15:
            return Bh(e, t, t.type, t.pendingProps, n);
        case 17:
            return r = t.type, o = t.pendingProps, o = t.elementType === r ? o : Vt(r, o), Ms(e, t), t.tag = 1, pt(r) ? (e = !0, ta(t)) : e = !1, Xr(t, n), yh(t, r, o), Zu(t, r, o, n), nc(null, t, r, !0, e, n);
        case 19:
            return qh(e, t, n);
        case 22:
            return zh(e, t, n)
    }
    throw Error(D(156, t.tag))
};

function cv(e, t) {
    return Ip(e, t)
}

function yS(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function Ct(e, t, n, r) {
    return new yS(e, t, n, r)
}

function Ed(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function _S(e) {
    if (typeof e == "function") return Ed(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === $c) return 11;
        if (e === Hc) return 14
    }
    return 2
}

function Kn(e, t) {
    var n = e.alternate;
    return n === null ? (n = Ct(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function Vs(e, t, n, r, o, l) {
    var s = 2;
    if (r = e, typeof e == "function") Ed(e) && (s = 1);
    else if (typeof e == "string") s = 5;
    else e: switch (e) {
        case Ir:
            return dr(n.children, o, l, t);
        case Vc:
            s = 8, o |= 8;
            break;
        case xu:
            return e = Ct(12, n, t, o | 2), e.elementType = xu, e.lanes = l, e;
        case Nu:
            return e = Ct(13, n, t, o), e.elementType = Nu, e.lanes = l, e;
        case Ru:
            return e = Ct(19, n, t, o), e.elementType = Ru, e.lanes = l, e;
        case _p:
            return Da(n, o, l, t);
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case gp:
                    s = 10;
                    break e;
                case yp:
                    s = 9;
                    break e;
                case $c:
                    s = 11;
                    break e;
                case Hc:
                    s = 14;
                    break e;
                case jn:
                    s = 16, r = null;
                    break e
            }
            throw Error(D(130, e == null ? e : typeof e, ""))
    }
    return t = Ct(s, n, t, o), t.elementType = e, t.type = r, t.lanes = l, t
}

function dr(e, t, n, r) {
    return e = Ct(7, e, r, t), e.lanes = n, e
}

function Da(e, t, n, r) {
    return e = Ct(22, e, r, t), e.elementType = _p, e.lanes = n, e.stateNode = {
        isHidden: !1
    }, e
}

function ru(e, t, n) {
    return e = Ct(6, e, null, t), e.lanes = n, e
}

function ou(e, t, n) {
    return t = Ct(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function SS(e, t, n, r, o) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Ui(0), this.expirationTimes = Ui(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Ui(0), this.identifierPrefix = r, this.onRecoverableError = o, this.mutableSourceEagerHydrationData = null
}

function xd(e, t, n, r, o, l, s, i, u) {
    return e = new SS(e, t, n, i, u), t === 1 ? (t = 1, l === !0 && (t |= 8)) : t = 0, l = Ct(3, null, null, t), e.current = l, l.stateNode = e, l.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    }, sd(l), e
}

function wS(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: br,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function dv(e) {
    if (!e) return qn;
    e = e._reactInternals;
    e: {
        if (Er(e) !== e || e.tag !== 1) throw Error(D(170));
        var t = e;do {
            switch (t.tag) {
                case 3:
                    t = t.stateNode.context;
                    break e;
                case 1:
                    if (pt(t.type)) {
                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                        break e
                    }
            }
            t = t.return
        } while (t !== null);
        throw Error(D(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (pt(n)) return ch(e, n, t)
    }
    return t
}

function fv(e, t, n, r, o, l, s, i, u) {
    return e = xd(n, r, !0, e, o, l, s, i, u), e.context = dv(null), n = e.current, r = at(), o = Wn(n), l = fn(r, o), l.callback = t ? ? null, Bn(n, l, o), e.current.lanes = o, xl(e, o, r), ht(e, r), e
}

function Pa(e, t, n, r) {
    var o = t.current,
        l = at(),
        s = Wn(o);
    return n = dv(n), t.context === null ? t.context = n : t.pendingContext = n, t = fn(l, s), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = Bn(o, t, s), e !== null && (zt(e, o, s, l), Os(e, o, s)), s
}

function pa(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function lm(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function Nd(e, t) {
    lm(e, t), (e = e.alternate) && lm(e, t)
}

function ES() {
    return null
}
var mv = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
};

function Rd(e) {
    this._internalRoot = e
}
Oa.prototype.render = Rd.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(D(409));
    Pa(e, t, null, null)
};
Oa.prototype.unmount = Rd.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        yr(function() {
            Pa(null, e, null, null)
        }), t[pn] = null
    }
};

function Oa(e) {
    this._internalRoot = e
}
Oa.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = Bp();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < Dn.length && t !== 0 && t < Dn[n].priority; n++);
        Dn.splice(n, 0, e), n === 0 && Wp(e)
    }
};

function kd(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}

function ba(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function sm() {}

function xS(e, t, n, r, o) {
    if (o) {
        if (typeof r == "function") {
            var l = r;
            r = function() {
                var c = pa(s);
                l.call(c)
            }
        }
        var s = fv(t, r, e, 0, null, !1, !1, "", sm);
        return e._reactRootContainer = s, e[pn] = s.current, cl(e.nodeType === 8 ? e.parentNode : e), yr(), s
    }
    for (; o = e.lastChild;) e.removeChild(o);
    if (typeof r == "function") {
        var i = r;
        r = function() {
            var c = pa(u);
            i.call(c)
        }
    }
    var u = xd(e, 0, !1, null, null, !1, !1, "", sm);
    return e._reactRootContainer = u, e[pn] = u.current, cl(e.nodeType === 8 ? e.parentNode : e), yr(function() {
        Pa(t, u, n, r)
    }), u
}

function Ia(e, t, n, r, o) {
    var l = n._reactRootContainer;
    if (l) {
        var s = l;
        if (typeof o == "function") {
            var i = o;
            o = function() {
                var u = pa(s);
                i.call(u)
            }
        }
        Pa(t, s, e, o)
    } else s = xS(n, t, e, o, r);
    return pa(s)
}
$p = function(e) {
    switch (e.tag) {
        case 3:
            var t = e.stateNode;
            if (t.current.memoizedState.isDehydrated) {
                var n = $o(t.pendingLanes);
                n !== 0 && (Wc(t, n | 1), ht(t, He()), !(ve & 6) && (so = He() + 500, Xn()))
            }
            break;
        case 13:
            yr(function() {
                var r = hn(e, 1);
                if (r !== null) {
                    var o = at();
                    zt(r, e, 1, o)
                }
            }), Nd(e, 1)
    }
};
Kc = function(e) {
    if (e.tag === 13) {
        var t = hn(e, 134217728);
        if (t !== null) {
            var n = at();
            zt(t, e, 134217728, n)
        }
        Nd(e, 134217728)
    }
};
Hp = function(e) {
    if (e.tag === 13) {
        var t = Wn(e),
            n = hn(e, t);
        if (n !== null) {
            var r = at();
            zt(n, e, t, r)
        }
        Nd(e, t)
    }
};
Bp = function() {
    return we
};
zp = function(e, t) {
    var n = we;
    try {
        return we = e, t()
    } finally {
        we = n
    }
};
bu = function(e, t, n) {
    switch (t) {
        case "input":
            if (Tu(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var o = ka(r);
                        if (!o) throw Error(D(90));
                        wp(r), Tu(r, o)
                    }
                }
            }
            break;
        case "textarea":
            xp(e, n);
            break;
        case "select":
            t = n.value, t != null && Gr(e, !!n.multiple, t, !1)
    }
};
Cp = _d;
Lp = yr;
var NS = {
        usingClientEntryPoint: !1,
        Events: [Rl, Vr, ka, Tp, jp, _d]
    },
    Co = {
        findFiberByHostInstance: ar,
        bundleType: 0,
        version: "18.2.0",
        rendererPackageName: "react-dom"
    },
    RS = {
        bundleType: Co.bundleType,
        version: Co.version,
        rendererPackageName: Co.rendererPackageName,
        rendererConfig: Co.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setErrorHandler: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: gn.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = Op(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: Co.findFiberByHostInstance || ES,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null,
        reconcilerVersion: "18.2.0-next-9e3b772b8-20220608"
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var vs = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!vs.isDisabled && vs.supportsFiber) try {
        Ea = vs.inject(RS), Jt = vs
    } catch {}
}
xt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = NS;
xt.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!kd(t)) throw Error(D(200));
    return wS(e, t, null, n)
};
xt.createRoot = function(e, t) {
    if (!kd(e)) throw Error(D(299));
    var n = !1,
        r = "",
        o = mv;
    return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (o = t.onRecoverableError)), t = xd(e, 1, !1, null, null, n, !1, r, o), e[pn] = t.current, cl(e.nodeType === 8 ? e.parentNode : e), new Rd(t)
};
xt.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(D(188)) : (e = Object.keys(e).join(","), Error(D(268, e)));
    return e = Op(t), e = e === null ? null : e.stateNode, e
};
xt.flushSync = function(e) {
    return yr(e)
};
xt.hydrate = function(e, t, n) {
    if (!ba(t)) throw Error(D(200));
    return Ia(null, e, t, !0, n)
};
xt.hydrateRoot = function(e, t, n) {
    if (!kd(e)) throw Error(D(405));
    var r = n != null && n.hydratedSources || null,
        o = !1,
        l = "",
        s = mv;
    if (n != null && (n.unstable_strictMode === !0 && (o = !0), n.identifierPrefix !== void 0 && (l = n.identifierPrefix), n.onRecoverableError !== void 0 && (s = n.onRecoverableError)), t = fv(t, null, e, 1, n ? ? null, o, !1, l, s), e[pn] = t.current, cl(e), r)
        for (e = 0; e < r.length; e++) n = r[e], o = n._getVersion, o = o(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, o] : t.mutableSourceEagerHydrationData.push(n, o);
    return new Oa(t)
};
xt.render = function(e, t, n) {
    if (!ba(t)) throw Error(D(200));
    return Ia(null, e, t, !1, n)
};
xt.unmountComponentAtNode = function(e) {
    if (!ba(e)) throw Error(D(40));
    return e._reactRootContainer ? (yr(function() {
        Ia(null, null, e, !1, function() {
            e._reactRootContainer = null, e[pn] = null
        })
    }), !0) : !1
};
xt.unstable_batchedUpdates = _d;
xt.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!ba(n)) throw Error(D(200));
    if (e == null || e._reactInternals === void 0) throw Error(D(38));
    return Ia(e, t, n, !1, r)
};
xt.version = "18.2.0-next-9e3b772b8-20220608";

function pv() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(pv)
    } catch (e) {
        console.error(e)
    }
}
pv(), fp.exports = xt;
var hv = fp.exports;
const kS = tp(hv);
var am = hv;
wu.createRoot = am.createRoot, wu.hydrateRoot = am.hydrateRoot;
var vv = {};

function AS(e) {
    const t = new Error(e);
    if (t.stack === void 0) try {
        throw t
    } catch {}
    return t
}
var TS = AS,
    ie = TS;

function jS(e) {
    return !!e && typeof e.then == "function"
}
var Te = jS;

function CS(e, t) {
    if (e != null) return e;
    throw ie(t ? ? "Got unexpected null or undefined")
}
var Pe = CS;

function se(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
class Ma {
    getValue() {
        throw ie("BaseLoadable")
    }
    toPromise() {
        throw ie("BaseLoadable")
    }
    valueMaybe() {
        throw ie("BaseLoadable")
    }
    valueOrThrow() {
        throw ie(`Loadable expected value, but in "${this.state}" state`)
    }
    promiseMaybe() {
        throw ie("BaseLoadable")
    }
    promiseOrThrow() {
        throw ie(`Loadable expected promise, but in "${this.state}" state`)
    }
    errorMaybe() {
        throw ie("BaseLoadable")
    }
    errorOrThrow() {
        throw ie(`Loadable expected error, but in "${this.state}" state`)
    }
    is(t) {
        return t.state === this.state && t.contents === this.contents
    }
    map(t) {
        throw ie("BaseLoadable")
    }
}
class LS extends Ma {
    constructor(t) {
        super(), se(this, "state", "hasValue"), se(this, "contents", void 0), this.contents = t
    }
    getValue() {
        return this.contents
    }
    toPromise() {
        return Promise.resolve(this.contents)
    }
    valueMaybe() {
        return this.contents
    }
    valueOrThrow() {
        return this.contents
    }
    promiseMaybe() {}
    errorMaybe() {}
    map(t) {
        try {
            const n = t(this.contents);
            return Te(n) ? _r(n) : ao(n) ? n : Al(n)
        } catch (n) {
            return Te(n) ? _r(n.next(() => this.map(t))) : Ua(n)
        }
    }
}
class DS extends Ma {
    constructor(t) {
        super(), se(this, "state", "hasError"), se(this, "contents", void 0), this.contents = t
    }
    getValue() {
        throw this.contents
    }
    toPromise() {
        return Promise.reject(this.contents)
    }
    valueMaybe() {}
    promiseMaybe() {}
    errorMaybe() {
        return this.contents
    }
    errorOrThrow() {
        return this.contents
    }
    map(t) {
        return this
    }
}
class gv extends Ma {
    constructor(t) {
        super(), se(this, "state", "loading"), se(this, "contents", void 0), this.contents = t
    }
    getValue() {
        throw this.contents
    }
    toPromise() {
        return this.contents
    }
    valueMaybe() {}
    promiseMaybe() {
        return this.contents
    }
    promiseOrThrow() {
        return this.contents
    }
    errorMaybe() {}
    map(t) {
        return _r(this.contents.then(n => {
            const r = t(n);
            if (ao(r)) {
                const o = r;
                switch (o.state) {
                    case "hasValue":
                        return o.contents;
                    case "hasError":
                        throw o.contents;
                    case "loading":
                        return o.contents
                }
            }
            return r
        }).catch(n => {
            if (Te(n)) return n.then(() => this.map(t).contents);
            throw n
        }))
    }
}

function Al(e) {
    return Object.freeze(new LS(e))
}

function Ua(e) {
    return Object.freeze(new DS(e))
}

function _r(e) {
    return Object.freeze(new gv(e))
}

function yv() {
    return Object.freeze(new gv(new Promise(() => {})))
}

function PS(e) {
    return e.every(t => t.state === "hasValue") ? Al(e.map(t => t.contents)) : e.some(t => t.state === "hasError") ? Ua(Pe(e.find(t => t.state === "hasError"), "Invalid loadable passed to loadableAll").contents) : _r(Promise.all(e.map(t => t.contents)))
}

function _v(e) {
    const n = (Array.isArray(e) ? e : Object.getOwnPropertyNames(e).map(o => e[o])).map(o => ao(o) ? o : Te(o) ? _r(o) : Al(o)),
        r = PS(n);
    return Array.isArray(e) ? r : r.map(o => Object.getOwnPropertyNames(e).reduce((l, s, i) => ({ ...l,
        [s]: o[i]
    }), {}))
}

function ao(e) {
    return e instanceof Ma
}
const OS = { of: e => Te(e) ? _r(e) : ao(e) ? e : Al(e),
    error: e => Ua(e),
    loading: () => yv(),
    all: _v,
    isLoadable: ao
};
var xr = {
        loadableWithValue: Al,
        loadableWithError: Ua,
        loadableWithPromise: _r,
        loadableLoading: yv,
        loadableAll: _v,
        isLoadable: ao,
        RecoilLoadable: OS
    },
    bS = xr.loadableWithValue,
    IS = xr.loadableWithError,
    MS = xr.loadableWithPromise,
    US = xr.loadableLoading,
    FS = xr.loadableAll,
    VS = xr.isLoadable,
    $S = xr.RecoilLoadable,
    Tl = Object.freeze({
        __proto__: null,
        loadableWithValue: bS,
        loadableWithError: IS,
        loadableWithPromise: MS,
        loadableLoading: US,
        loadableAll: FS,
        isLoadable: VS,
        RecoilLoadable: $S
    });
const pc = {
    RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED: !0,
    RECOIL_GKS_ENABLED: new Set(["recoil_hamt_2020", "recoil_sync_external_store", "recoil_suppress_rerender_in_callback", "recoil_memory_managament_2020"])
};

function HS(e, t) {
    var n, r;
    const o = (n = vv[e]) === null || n === void 0 || (r = n.toLowerCase()) === null || r === void 0 ? void 0 : r.trim();
    if (o == null || o === "") return;
    if (!["true", "false"].includes(o)) throw ie(`process.env.${e} value must be 'true', 'false', or empty: ${o}`);
    t(o === "true")
}

function BS(e, t) {
    var n;
    const r = (n = vv[e]) === null || n === void 0 ? void 0 : n.trim();
    r == null || r === "" || t(r.split(/\s*,\s*|\s+/))
}

function zS() {
    var e;
    typeof process > "u" || ((e = process) === null || e === void 0 ? void 0 : e.env) != null && (HS("RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED", t => {
        pc.RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED = t
    }), BS("RECOIL_GKS_ENABLED", t => {
        t.forEach(n => {
            pc.RECOIL_GKS_ENABLED.add(n)
        })
    }))
}
zS();
var go = pc;

function Fa(e) {
    return go.RECOIL_GKS_ENABLED.has(e)
}
Fa.setPass = e => {
    go.RECOIL_GKS_ENABLED.add(e)
};
Fa.setFail = e => {
    go.RECOIL_GKS_ENABLED.delete(e)
};
Fa.clear = () => {
    go.RECOIL_GKS_ENABLED.clear()
};
var xe = Fa;

function WS(e, t, {
    error: n
} = {}) {
    return null
}
var KS = WS,
    Ad = KS,
    lu, su, au;
const GS = (lu = Ce.createMutableSource) !== null && lu !== void 0 ? lu : Ce.unstable_createMutableSource,
    Sv = (su = Ce.useMutableSource) !== null && su !== void 0 ? su : Ce.unstable_useMutableSource,
    wv = (au = Ce.useSyncExternalStore) !== null && au !== void 0 ? au : Ce.unstable_useSyncExternalStore;

function qS() {
    var e;
    const {
        ReactCurrentDispatcher: t,
        ReactCurrentOwner: n
    } = Ce.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
    return ((e = t == null ? void 0 : t.current) !== null && e !== void 0 ? e : n.currentDispatcher).useSyncExternalStore != null
}

function YS() {
    return xe("recoil_transition_support") ? {
        mode: "TRANSITION_SUPPORT",
        early: !0,
        concurrent: !0
    } : xe("recoil_sync_external_store") && wv != null ? {
        mode: "SYNC_EXTERNAL_STORE",
        early: !0,
        concurrent: !1
    } : xe("recoil_mutable_source") && Sv != null && typeof window < "u" && !window.$disableRecoilValueMutableSource_TEMP_HACK_DO_NOT_USE ? xe("recoil_suppress_rerender_in_callback") ? {
        mode: "MUTABLE_SOURCE",
        early: !0,
        concurrent: !0
    } : {
        mode: "MUTABLE_SOURCE",
        early: !1,
        concurrent: !1
    } : xe("recoil_suppress_rerender_in_callback") ? {
        mode: "LEGACY",
        early: !0,
        concurrent: !1
    } : {
        mode: "LEGACY",
        early: !1,
        concurrent: !1
    }
}

function QS() {
    return !1
}
var jl = {
    createMutableSource: GS,
    useMutableSource: Sv,
    useSyncExternalStore: wv,
    currentRendererSupportsUseSyncExternalStore: qS,
    reactMode: YS,
    isFastRefreshEnabled: QS
};
class Td {
    constructor(t) {
        se(this, "key", void 0), this.key = t
    }
    toJSON() {
        return {
            key: this.key
        }
    }
}
class Ev extends Td {}
class xv extends Td {}

function XS(e) {
    return e instanceof Ev || e instanceof xv
}
var Va = {
        AbstractRecoilValue: Td,
        RecoilState: Ev,
        RecoilValueReadOnly: xv,
        isRecoilValue: XS
    },
    JS = Va.AbstractRecoilValue,
    ZS = Va.RecoilState,
    e1 = Va.RecoilValueReadOnly,
    t1 = Va.isRecoilValue,
    io = Object.freeze({
        __proto__: null,
        AbstractRecoilValue: JS,
        RecoilState: ZS,
        RecoilValueReadOnly: e1,
        isRecoilValue: t1
    });

function n1(e, t) {
    return function*() {
        let n = 0;
        for (const r of e) yield t(r, n++)
    }()
}
var $a = n1;
class Nv {}
const r1 = new Nv,
    Sr = new Map,
    jd = new Map;

function o1(e) {
    return $a(e, t => Pe(jd.get(t)))
}

function l1(e) {
    if (Sr.has(e)) {
        const t = `Duplicate atom key "${e}". This is a FATAL ERROR in
      production. But it is safe to ignore this warning if it occurred because of
      hot module replacement.`;
        console.warn(t)
    }
}

function s1(e) {
    go.RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED && l1(e.key), Sr.set(e.key, e);
    const t = e.set == null ? new io.RecoilValueReadOnly(e.key) : new io.RecoilState(e.key);
    return jd.set(e.key, t), t
}
class Rv extends Error {}

function a1(e) {
    const t = Sr.get(e);
    if (t == null) throw new Rv(`Missing definition for RecoilValue: "${e}""`);
    return t
}

function i1(e) {
    return Sr.get(e)
}
const ha = new Map;

function u1(e) {
    var t;
    if (!xe("recoil_memory_managament_2020")) return;
    const n = Sr.get(e);
    if (n != null && (t = n.shouldDeleteConfigOnRelease) !== null && t !== void 0 && t.call(n)) {
        var r;
        Sr.delete(e), (r = kv(e)) === null || r === void 0 || r(), ha.delete(e)
    }
}

function c1(e, t) {
    xe("recoil_memory_managament_2020") && (t === void 0 ? ha.delete(e) : ha.set(e, t))
}

function kv(e) {
    return ha.get(e)
}
var gt = {
    nodes: Sr,
    recoilValues: jd,
    registerNode: s1,
    getNode: a1,
    getNodeMaybe: i1,
    deleteNodeConfigIfPossible: u1,
    setConfigDeletionHandler: c1,
    getConfigDeletionHandler: kv,
    recoilValuesForKeys: o1,
    NodeMissingError: Rv,
    DefaultValue: Nv,
    DEFAULT_VALUE: r1
};

function d1(e, t) {
    t()
}
var f1 = {
    enqueueExecution: d1
};

function m1(e, t) {
    return t = {
        exports: {}
    }, e(t, t.exports), t.exports
}
var p1 = m1(function(e) {
    var t = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(N) {
            return typeof N
        } : function(N) {
            return N && typeof Symbol == "function" && N.constructor === Symbol && N !== Symbol.prototype ? "symbol" : typeof N
        },
        n = {},
        r = 5,
        o = Math.pow(2, r),
        l = o - 1,
        s = o / 2,
        i = o / 4,
        u = {},
        c = function(w) {
            return function() {
                return w
            }
        },
        f = n.hash = function(N) {
            var w = typeof N > "u" ? "undefined" : t(N);
            if (w === "number") return N;
            w !== "string" && (N += "");
            for (var j = 0, F = 0, V = N.length; F < V; ++F) {
                var B = N.charCodeAt(F);
                j = (j << 5) - j + B | 0
            }
            return j
        },
        d = function(w) {
            return w -= w >> 1 & 1431655765, w = (w & 858993459) + (w >> 2 & 858993459), w = w + (w >> 4) & 252645135, w += w >> 8, w += w >> 16, w & 127
        },
        g = function(w, j) {
            return j >>> w & l
        },
        S = function(w) {
            return 1 << w
        },
        v = function(w, j) {
            return d(w & j - 1)
        },
        _ = function(w, j, F, V) {
            var B = V;
            if (!w) {
                var J = V.length;
                B = new Array(J);
                for (var X = 0; X < J; ++X) B[X] = V[X]
            }
            return B[j] = F, B
        },
        R = function(w, j, F) {
            var V = F.length - 1,
                B = 0,
                J = 0,
                X = F;
            if (w) B = J = j;
            else
                for (X = new Array(V); B < j;) X[J++] = F[B++];
            for (++B; B <= V;) X[J++] = F[B++];
            return w && (X.length = V), X
        },
        p = function(w, j, F, V) {
            var B = V.length;
            if (w) {
                for (var J = B; J >= j;) V[J--] = V[J];
                return V[j] = F, V
            }
            for (var X = 0, Z = 0, re = new Array(B + 1); X < j;) re[Z++] = V[X++];
            for (re[j] = F; X < B;) re[++Z] = V[X++];
            return re
        },
        m = 1,
        h = 2,
        x = 3,
        k = 4,
        C = {
            __hamt_isEmpty: !0
        },
        L = function(w) {
            return w === C || w && w.__hamt_isEmpty
        },
        M = function(w, j, F, V) {
            return {
                type: m,
                edit: w,
                hash: j,
                key: F,
                value: V,
                _modify: I
            }
        },
        oe = function(w, j, F) {
            return {
                type: h,
                edit: w,
                hash: j,
                children: F,
                _modify: Y
            }
        },
        H = function(w, j, F) {
            return {
                type: x,
                edit: w,
                mask: j,
                children: F,
                _modify: b
            }
        },
        ge = function(w, j, F) {
            return {
                type: k,
                edit: w,
                size: j,
                children: F,
                _modify: q
            }
        },
        Ue = function(w) {
            return w === C || w.type === m || w.type === h
        },
        de = function(w, j, F, V, B) {
            for (var J = [], X = V, Z = 0, re = 0; X; ++re) X & 1 && (J[re] = B[Z++]), X >>>= 1;
            return J[j] = F, ge(w, Z + 1, J)
        },
        Ne = function(w, j, F, V) {
            for (var B = new Array(j - 1), J = 0, X = 0, Z = 0, re = V.length; Z < re; ++Z)
                if (Z !== F) {
                    var _e = V[Z];
                    _e && !L(_e) && (B[J++] = _e, X |= 1 << Z)
                }
            return H(w, X, B)
        },
        Xe = function N(w, j, F, V, B, J) {
            if (F === B) return oe(w, F, [J, V]);
            var X = g(j, F),
                Z = g(j, B);
            return H(w, S(X) | S(Z), X === Z ? [N(w, j + r, F, V, B, J)] : X < Z ? [V, J] : [J, V])
        },
        Re = function(w, j, F, V, B, J, X, Z) {
            for (var re = B.length, _e = 0; _e < re; ++_e) {
                var $e = B[_e];
                if (F(X, $e.key)) {
                    var Le = $e.value,
                        Ke = J(Le);
                    return Ke === Le ? B : Ke === u ? (--Z.value, R(w, _e, B)) : _(w, _e, M(j, V, X, Ke), B)
                }
            }
            var Je = J();
            return Je === u ? B : (++Z.value, _(w, re, M(j, V, X, Je), B))
        },
        Ve = function(w, j) {
            return w === j.edit
        },
        I = function(w, j, F, V, B, J, X) {
            if (j(J, this.key)) {
                var Z = V(this.value);
                return Z === this.value ? this : Z === u ? (--X.value, C) : Ve(w, this) ? (this.value = Z, this) : M(w, B, J, Z)
            }
            var re = V();
            return re === u ? this : (++X.value, Xe(w, F, this.hash, this, B, M(w, B, J, re)))
        },
        Y = function(w, j, F, V, B, J, X) {
            if (B === this.hash) {
                var Z = Ve(w, this),
                    re = Re(Z, w, j, this.hash, this.children, V, J, X);
                return re === this.children ? this : re.length > 1 ? oe(w, this.hash, re) : re[0]
            }
            var _e = V();
            return _e === u ? this : (++X.value, Xe(w, F, this.hash, this, B, M(w, B, J, _e)))
        },
        b = function(w, j, F, V, B, J, X) {
            var Z = this.mask,
                re = this.children,
                _e = g(F, B),
                $e = S(_e),
                Le = v(Z, $e),
                Ke = Z & $e,
                Je = Ke ? re[Le] : C,
                It = Je._modify(w, j, F + r, V, B, J, X);
            if (Je === It) return this;
            var Kt = Ve(w, this),
                kt = Z,
                on = void 0;
            if (Ke && L(It)) {
                if (kt &= ~$e, !kt) return C;
                if (re.length <= 2 && Ue(re[Le ^ 1])) return re[Le ^ 1];
                on = R(Kt, Le, re)
            } else if (!Ke && !L(It)) {
                if (re.length >= s) return de(w, _e, It, Z, re);
                kt |= $e, on = p(Kt, Le, It, re)
            } else on = _(Kt, Le, It, re);
            return Kt ? (this.mask = kt, this.children = on, this) : H(w, kt, on)
        },
        q = function(w, j, F, V, B, J, X) {
            var Z = this.size,
                re = this.children,
                _e = g(F, B),
                $e = re[_e],
                Le = ($e || C)._modify(w, j, F + r, V, B, J, X);
            if ($e === Le) return this;
            var Ke = Ve(w, this),
                Je = void 0;
            if (L($e) && !L(Le)) ++Z, Je = _(Ke, _e, Le, re);
            else if (!L($e) && L(Le)) {
                if (--Z, Z <= i) return Ne(w, Z, _e, re);
                Je = _(Ke, _e, C, re)
            } else Je = _(Ke, _e, Le, re);
            return Ke ? (this.size = Z, this.children = Je, this) : ge(w, Z, Je)
        };
    C._modify = function(N, w, j, F, V, B, J) {
        var X = F();
        return X === u ? C : (++J.value, M(N, V, B, X))
    };

    function E(N, w, j, F, V) {
        this._editable = N, this._edit = w, this._config = j, this._root = F, this._size = V
    }
    E.prototype.setTree = function(N, w) {
        return this._editable ? (this._root = N, this._size = w, this) : N === this._root ? this : new E(this._editable, this._edit, this._config, N, w)
    };
    var P = n.tryGetHash = function(N, w, j, F) {
        for (var V = F._root, B = 0, J = F._config.keyEq;;) switch (V.type) {
            case m:
                return J(j, V.key) ? V.value : N;
            case h:
                {
                    if (w === V.hash)
                        for (var X = V.children, Z = 0, re = X.length; Z < re; ++Z) {
                            var _e = X[Z];
                            if (J(j, _e.key)) return _e.value
                        }
                    return N
                }
            case x:
                {
                    var $e = g(B, w),
                        Le = S($e);
                    if (V.mask & Le) {
                        V = V.children[v(V.mask, Le)], B += r;
                        break
                    }
                    return N
                }
            case k:
                {
                    if (V = V.children[g(B, w)], V) {
                        B += r;
                        break
                    }
                    return N
                }
            default:
                return N
        }
    };
    E.prototype.tryGetHash = function(N, w, j) {
        return P(N, w, j, this)
    };
    var O = n.tryGet = function(N, w, j) {
        return P(N, j._config.hash(w), w, j)
    };
    E.prototype.tryGet = function(N, w) {
        return O(N, w, this)
    };
    var Q = n.getHash = function(N, w, j) {
        return P(void 0, N, w, j)
    };
    E.prototype.getHash = function(N, w) {
        return Q(N, w, this)
    }, n.get = function(N, w) {
        return P(void 0, w._config.hash(N), N, w)
    }, E.prototype.get = function(N, w) {
        return O(w, N, this)
    };
    var $ = n.has = function(N, w, j) {
        return P(u, N, w, j) !== u
    };
    E.prototype.hasHash = function(N, w) {
        return $(N, w, this)
    };
    var ne = n.has = function(N, w) {
        return $(w._config.hash(N), N, w)
    };
    E.prototype.has = function(N) {
        return ne(N, this)
    };
    var te = function(w, j) {
        return w === j
    };
    n.make = function(N) {
        return new E(0, 0, {
            keyEq: N && N.keyEq || te,
            hash: N && N.hash || f
        }, C, 0)
    }, n.empty = n.make();
    var G = n.isEmpty = function(N) {
        return N && !!L(N._root)
    };
    E.prototype.isEmpty = function() {
        return G(this)
    };
    var me = n.modifyHash = function(N, w, j, F) {
        var V = {
                value: F._size
            },
            B = F._root._modify(F._editable ? F._edit : NaN, F._config.keyEq, 0, N, w, j, V);
        return F.setTree(B, V.value)
    };
    E.prototype.modifyHash = function(N, w, j) {
        return me(j, N, w, this)
    };
    var Se = n.modify = function(N, w, j) {
        return me(N, j._config.hash(w), w, j)
    };
    E.prototype.modify = function(N, w) {
        return Se(w, N, this)
    };
    var ce = n.setHash = function(N, w, j, F) {
        return me(c(j), N, w, F)
    };
    E.prototype.setHash = function(N, w, j) {
        return ce(N, w, j, this)
    };
    var he = n.set = function(N, w, j) {
        return ce(j._config.hash(N), N, w, j)
    };
    E.prototype.set = function(N, w) {
        return he(N, w, this)
    };
    var W = c(u),
        ee = n.removeHash = function(N, w, j) {
            return me(W, N, w, j)
        };
    E.prototype.removeHash = E.prototype.deleteHash = function(N, w) {
        return ee(N, w, this)
    };
    var ye = n.remove = function(N, w) {
        return ee(w._config.hash(N), N, w)
    };
    E.prototype.remove = E.prototype.delete = function(N) {
        return ye(N, this)
    };
    var Ee = n.beginMutation = function(N) {
        return new E(N._editable + 1, N._edit + 1, N._config, N._root, N._size)
    };
    E.prototype.beginMutation = function() {
        return Ee(this)
    };
    var yt = n.endMutation = function(N) {
        return N._editable = N._editable && N._editable - 1, N
    };
    E.prototype.endMutation = function() {
        return yt(this)
    };
    var rn = n.mutate = function(N, w) {
        var j = Ee(w);
        return N(j), yt(j)
    };
    E.prototype.mutate = function(N) {
        return rn(N, this)
    };
    var ct = function(w) {
            return w && Rt(w[0], w[1], w[2], w[3], w[4])
        },
        Rt = function(w, j, F, V, B) {
            for (; F < w;) {
                var J = j[F++];
                if (J && !L(J)) return Sn(J, V, [w, j, F, V, B])
            }
            return ct(B)
        },
        Sn = function(w, j, F) {
            switch (w.type) {
                case m:
                    return {
                        value: j(w),
                        rest: F
                    };
                case h:
                case k:
                case x:
                    var V = w.children;
                    return Rt(V.length, V, 0, j, F);
                default:
                    return ct(F)
            }
        },
        Rr = {
            done: !0
        };

    function wn(N) {
        this.v = N
    }
    wn.prototype.next = function() {
        if (!this.v) return Rr;
        var N = this.v;
        return this.v = ct(N.rest), N
    }, wn.prototype[Symbol.iterator] = function() {
        return this
    };
    var En = function(w, j) {
            return new wn(Sn(w._root, j))
        },
        xn = function(w) {
            return [w.key, w.value]
        },
        kr = n.entries = function(N) {
            return En(N, xn)
        };
    E.prototype.entries = E.prototype[Symbol.iterator] = function() {
        return kr(this)
    };
    var Ar = function(w) {
            return w.key
        },
        Tr = n.keys = function(N) {
            return En(N, Ar)
        };
    E.prototype.keys = function() {
        return Tr(this)
    };
    var er = function(w) {
            return w.value
        },
        wo = n.values = E.prototype.values = function(N) {
            return En(N, er)
        };
    E.prototype.values = function() {
        return wo(this)
    };
    var Nn = n.fold = function(N, w, j) {
        var F = j._root;
        if (F.type === m) return N(w, F.value, F.key);
        for (var V = [F.children], B = void 0; B = V.pop();)
            for (var J = 0, X = B.length; J < X;) {
                var Z = B[J++];
                Z && Z.type && (Z.type === m ? w = N(w, Z.value, Z.key) : V.push(Z.children))
            }
        return w
    };
    E.prototype.fold = function(N, w) {
        return Nn(N, w, this)
    };
    var jr = n.forEach = function(N, w) {
        return Nn(function(j, F, V) {
            return N(F, V, w)
        }, null, w)
    };
    E.prototype.forEach = function(N) {
        return jr(N, this)
    };
    var Cr = n.count = function(N) {
        return N._size
    };
    E.prototype.count = function() {
        return Cr(this)
    }, Object.defineProperty(E.prototype, "size", {
        get: E.prototype.count
    }), e.exports ? e.exports = n : (void 0).hamt = n
});
class h1 {
    constructor(t) {
        se(this, "_map", void 0), this._map = new Map(t == null ? void 0 : t.entries())
    }
    keys() {
        return this._map.keys()
    }
    entries() {
        return this._map.entries()
    }
    get(t) {
        return this._map.get(t)
    }
    has(t) {
        return this._map.has(t)
    }
    set(t, n) {
        return this._map.set(t, n), this
    }
    delete(t) {
        return this._map.delete(t), this
    }
    clone() {
        return Ld(this)
    }
    toMap() {
        return new Map(this._map)
    }
}
class Cd {
    constructor(t) {
        if (se(this, "_hamt", p1.empty.beginMutation()), t instanceof Cd) {
            const n = t._hamt.endMutation();
            t._hamt = n.beginMutation(), this._hamt = n.beginMutation()
        } else if (t)
            for (const [n, r] of t.entries()) this._hamt.set(n, r)
    }
    keys() {
        return this._hamt.keys()
    }
    entries() {
        return this._hamt.entries()
    }
    get(t) {
        return this._hamt.get(t)
    }
    has(t) {
        return this._hamt.has(t)
    }
    set(t, n) {
        return this._hamt.set(t, n), this
    }
    delete(t) {
        return this._hamt.delete(t), this
    }
    clone() {
        return Ld(this)
    }
    toMap() {
        return new Map(this._hamt)
    }
}

function Ld(e) {
    return xe("recoil_hamt_2020") ? new Cd(e) : new h1(e)
}
var v1 = {
        persistentMap: Ld
    },
    g1 = v1.persistentMap,
    y1 = Object.freeze({
        __proto__: null,
        persistentMap: g1
    });

function _1(e, ...t) {
    const n = new Set;
    e: for (const r of e) {
        for (const o of t)
            if (o.has(r)) continue e;
        n.add(r)
    }
    return n
}
var Zo = _1;

function S1(e, t) {
    const n = new Map;
    return e.forEach((r, o) => {
        n.set(o, t(r, o))
    }), n
}
var va = S1;

function w1() {
    return {
        nodeDeps: new Map,
        nodeToNodeSubscriptions: new Map
    }
}

function E1(e) {
    return {
        nodeDeps: va(e.nodeDeps, t => new Set(t)),
        nodeToNodeSubscriptions: va(e.nodeToNodeSubscriptions, t => new Set(t))
    }
}

function iu(e, t, n, r) {
    const {
        nodeDeps: o,
        nodeToNodeSubscriptions: l
    } = n, s = o.get(e);
    if (s && r && s !== r.nodeDeps.get(e)) return;
    o.set(e, t);
    const i = s == null ? t : Zo(t, s);
    for (const u of i) l.has(u) || l.set(u, new Set), Pe(l.get(u)).add(e);
    if (s) {
        const u = Zo(s, t);
        for (const c of u) {
            if (!l.has(c)) return;
            const f = Pe(l.get(c));
            f.delete(e), f.size === 0 && l.delete(c)
        }
    }
}

function x1(e, t, n, r) {
    var o, l, s, i;
    const u = n.getState();
    r === u.currentTree.version || r === ((o = u.nextTree) === null || o === void 0 ? void 0 : o.version) || ((l = u.previousTree) === null || l === void 0 || l.version);
    const c = n.getGraph(r);
    if (iu(e, t, c), r === ((s = u.previousTree) === null || s === void 0 ? void 0 : s.version)) {
        const d = n.getGraph(u.currentTree.version);
        iu(e, t, d, c)
    }
    if (r === ((i = u.previousTree) === null || i === void 0 ? void 0 : i.version) || r === u.currentTree.version) {
        var f;
        const d = (f = u.nextTree) === null || f === void 0 ? void 0 : f.version;
        if (d !== void 0) {
            const g = n.getGraph(d);
            iu(e, t, g, c)
        }
    }
}
var Cl = {
    cloneGraph: E1,
    graph: w1,
    saveDepsToStore: x1
};
let N1 = 0;
const R1 = () => N1++;
let k1 = 0;
const A1 = () => k1++;
let T1 = 0;
const j1 = () => T1++;
var Ha = {
    getNextTreeStateVersion: R1,
    getNextStoreID: A1,
    getNextComponentID: j1
};
const {
    persistentMap: im
} = y1, {
    graph: C1
} = Cl, {
    getNextTreeStateVersion: Av
} = Ha;

function Tv() {
    const e = Av();
    return {
        version: e,
        stateID: e,
        transactionMetadata: {},
        dirtyAtoms: new Set,
        atomValues: im(),
        nonvalidatedAtoms: im()
    }
}

function L1() {
    const e = Tv();
    return {
        currentTree: e,
        nextTree: null,
        previousTree: null,
        commitDepth: 0,
        knownAtoms: new Set,
        knownSelectors: new Set,
        transactionSubscriptions: new Map,
        nodeTransactionSubscriptions: new Map,
        nodeToComponentSubscriptions: new Map,
        queuedComponentCallbacks_DEPRECATED: [],
        suspendedComponentResolvers: new Set,
        graphsByVersion: new Map().set(e.version, C1()),
        retention: {
            referenceCounts: new Map,
            nodesRetainedByZone: new Map,
            retainablesToCheckForRelease: new Set
        },
        nodeCleanupFunctions: new Map
    }
}
var jv = {
    makeEmptyTreeState: Tv,
    makeEmptyStoreState: L1,
    getNextTreeStateVersion: Av
};
class Cv {}

function D1() {
    return new Cv
}
var Ba = {
    RetentionZone: Cv,
    retentionZone: D1
};

function P1(e, t) {
    const n = new Set(e);
    return n.add(t), n
}

function O1(e, t) {
    const n = new Set(e);
    return n.delete(t), n
}

function b1(e, t, n) {
    const r = new Map(e);
    return r.set(t, n), r
}

function I1(e, t, n) {
    const r = new Map(e);
    return r.set(t, n(r.get(t))), r
}

function M1(e, t) {
    const n = new Map(e);
    return n.delete(t), n
}

function U1(e, t) {
    const n = new Map(e);
    return t.forEach(r => n.delete(r)), n
}
var Lv = {
    setByAddingToSet: P1,
    setByDeletingFromSet: O1,
    mapBySettingInMap: b1,
    mapByUpdatingInMap: I1,
    mapByDeletingFromMap: M1,
    mapByDeletingMultipleFromMap: U1
};

function* F1(e, t) {
    let n = 0;
    for (const r of e) t(r, n++) && (yield r)
}
var Dd = F1;

function V1(e, t) {
    return new Proxy(e, {
        get: (r, o) => (!(o in r) && o in t && (r[o] = t[o]()), r[o]),
        ownKeys: r => Object.keys(r)
    })
}
var Dv = V1;
const {
    getNode: Ll,
    getNodeMaybe: $1,
    recoilValuesForKeys: um
} = gt, {
    RetentionZone: cm
} = Ba, {
    setByAddingToSet: H1
} = Lv, B1 = Object.freeze(new Set);
class z1 extends Error {}

function W1(e, t, n) {
    if (!xe("recoil_memory_managament_2020")) return () => {};
    const {
        nodesRetainedByZone: r
    } = e.getState().retention;

    function o(l) {
        let s = r.get(l);
        s || r.set(l, s = new Set), s.add(t)
    }
    if (n instanceof cm) o(n);
    else if (Array.isArray(n))
        for (const l of n) o(l);
    return () => {
        if (!xe("recoil_memory_managament_2020")) return;
        const {
            retention: l
        } = e.getState();

        function s(i) {
            const u = l.nodesRetainedByZone.get(i);
            u == null || u.delete(t), u && u.size === 0 && l.nodesRetainedByZone.delete(i)
        }
        if (n instanceof cm) s(n);
        else if (Array.isArray(n))
            for (const i of n) s(i)
    }
}

function Pd(e, t, n, r) {
    const o = e.getState();
    if (o.nodeCleanupFunctions.has(n)) return;
    const l = Ll(n),
        s = W1(e, n, l.retainedBy),
        i = l.init(e, t, r);
    o.nodeCleanupFunctions.set(n, () => {
        i(), s()
    })
}

function K1(e, t, n) {
    Pd(e, e.getState().currentTree, t, n)
}

function G1(e, t) {
    var n;
    const r = e.getState();
    (n = r.nodeCleanupFunctions.get(t)) === null || n === void 0 || n(), r.nodeCleanupFunctions.delete(t)
}

function q1(e, t, n) {
    return Pd(e, t, n, "get"), Ll(n).get(e, t)
}

function Pv(e, t, n) {
    return Ll(n).peek(e, t)
}

function Y1(e, t, n) {
    var r;
    const o = $1(t);
    return o == null || (r = o.invalidate) === null || r === void 0 || r.call(o, e), { ...e,
        atomValues: e.atomValues.clone().delete(t),
        nonvalidatedAtoms: e.nonvalidatedAtoms.clone().set(t, n),
        dirtyAtoms: H1(e.dirtyAtoms, t)
    }
}

function Q1(e, t, n, r) {
    const o = Ll(n);
    if (o.set == null) throw new z1(`Attempt to set read-only RecoilValue: ${n}`);
    const l = o.set;
    return Pd(e, t, n, "set"), l(e, t, r)
}

function X1(e, t, n) {
    const r = e.getState(),
        o = e.getGraph(t.version),
        l = Ll(n).nodeType;
    return Dv({
        type: l
    }, {
        loadable: () => Pv(e, t, n),
        isActive: () => r.knownAtoms.has(n) || r.knownSelectors.has(n),
        isSet: () => l === "selector" ? !1 : t.atomValues.has(n),
        isModified: () => t.dirtyAtoms.has(n),
        deps: () => {
            var s;
            return um((s = o.nodeDeps.get(n)) !== null && s !== void 0 ? s : [])
        },
        subscribers: () => {
            var s, i;
            return {
                nodes: um(Dd(Ov(e, t, new Set([n])), u => u !== n)),
                components: $a((s = (i = r.nodeToComponentSubscriptions.get(n)) === null || i === void 0 ? void 0 : i.values()) !== null && s !== void 0 ? s : [], ([u]) => ({
                    name: u
                }))
            }
        }
    })
}

function Ov(e, t, n) {
    const r = new Set,
        o = Array.from(n),
        l = e.getGraph(t.version);
    for (let i = o.pop(); i; i = o.pop()) {
        var s;
        r.add(i);
        const u = (s = l.nodeToNodeSubscriptions.get(i)) !== null && s !== void 0 ? s : B1;
        for (const c of u) r.has(c) || o.push(c)
    }
    return r
}
var Jn = {
    getNodeLoadable: q1,
    peekNodeLoadable: Pv,
    setNodeValue: Q1,
    initializeNode: K1,
    cleanUpNode: G1,
    setUnvalidatedAtomValue_DEPRECATED: Y1,
    peekNodeInfo: X1,
    getDownstreamNodes: Ov
};
let bv = null;

function J1(e) {
    bv = e
}

function Z1() {
    var e;
    (e = bv) === null || e === void 0 || e()
}
var Iv = {
    setInvalidateMemoizedSnapshot: J1,
    invalidateMemoizedSnapshot: Z1
};
const {
    getDownstreamNodes: ew,
    getNodeLoadable: Mv,
    setNodeValue: tw
} = Jn, {
    getNextComponentID: nw
} = Ha, {
    getNode: rw,
    getNodeMaybe: Uv
} = gt, {
    DefaultValue: Od
} = gt, {
    reactMode: ow
} = jl, {
    AbstractRecoilValue: lw,
    RecoilState: sw,
    RecoilValueReadOnly: aw,
    isRecoilValue: iw
} = io, {
    invalidateMemoizedSnapshot: uw
} = Iv;

function cw(e, {
    key: t
}, n = e.getState().currentTree) {
    var r, o;
    const l = e.getState();
    n.version === l.currentTree.version || n.version === ((r = l.nextTree) === null || r === void 0 ? void 0 : r.version) || (n.version, (o = l.previousTree) === null || o === void 0 || o.version);
    const s = Mv(e, n, t);
    return s.state === "loading" && s.contents.catch(() => {}), s
}

function dw(e, t) {
    const n = e.clone();
    return t.forEach((r, o) => {
        r.state === "hasValue" && r.contents instanceof Od ? n.delete(o) : n.set(o, r)
    }), n
}

function fw(e, t, {
    key: n
}, r) {
    if (typeof r == "function") {
        const o = Mv(e, t, n);
        if (o.state === "loading") {
            const l = `Tried to set atom or selector "${n}" using an updater function while the current state is pending, this is not currently supported.`;
            throw ie(l)
        } else if (o.state === "hasError") throw o.contents;
        return r(o.contents)
    } else return r
}

function mw(e, t, n) {
    if (n.type === "set") {
        const {
            recoilValue: o,
            valueOrUpdater: l
        } = n, s = fw(e, t, o, l), i = tw(e, t, o.key, s);
        for (const [u, c] of i.entries()) hc(t, u, c)
    } else if (n.type === "setLoadable") {
        const {
            recoilValue: {
                key: o
            },
            loadable: l
        } = n;
        hc(t, o, l)
    } else if (n.type === "markModified") {
        const {
            recoilValue: {
                key: o
            }
        } = n;
        t.dirtyAtoms.add(o)
    } else if (n.type === "setUnvalidated") {
        var r;
        const {
            recoilValue: {
                key: o
            },
            unvalidatedValue: l
        } = n, s = Uv(o);
        s == null || (r = s.invalidate) === null || r === void 0 || r.call(s, t), t.atomValues.delete(o), t.nonvalidatedAtoms.set(o, l), t.dirtyAtoms.add(o)
    } else Ad(`Unknown action ${n.type}`)
}

function hc(e, t, n) {
    n.state === "hasValue" && n.contents instanceof Od ? e.atomValues.delete(t) : e.atomValues.set(t, n), e.dirtyAtoms.add(t), e.nonvalidatedAtoms.delete(t)
}

function Fv(e, t) {
    e.replaceState(n => {
        const r = Vv(n);
        for (const o of t) mw(e, r, o);
        return $v(e, r), uw(), r
    })
}

function za(e, t) {
    if (el.length) {
        const n = el[el.length - 1];
        let r = n.get(e);
        r || n.set(e, r = []), r.push(t)
    } else Fv(e, [t])
}
const el = [];

function pw() {
    const e = new Map;
    return el.push(e), () => {
        for (const [t, n] of e) Fv(t, n);
        el.pop()
    }
}

function Vv(e) {
    return { ...e,
        atomValues: e.atomValues.clone(),
        nonvalidatedAtoms: e.nonvalidatedAtoms.clone(),
        dirtyAtoms: new Set(e.dirtyAtoms)
    }
}

function $v(e, t) {
    const n = ew(e, t, t.dirtyAtoms);
    for (const l of n) {
        var r, o;
        (r = Uv(l)) === null || r === void 0 || (o = r.invalidate) === null || o === void 0 || o.call(r, t)
    }
}

function Hv(e, t, n) {
    za(e, {
        type: "set",
        recoilValue: t,
        valueOrUpdater: n
    })
}

function hw(e, t, n) {
    if (n instanceof Od) return Hv(e, t, n);
    za(e, {
        type: "setLoadable",
        recoilValue: t,
        loadable: n
    })
}

function vw(e, t) {
    za(e, {
        type: "markModified",
        recoilValue: t
    })
}

function gw(e, t, n) {
    za(e, {
        type: "setUnvalidated",
        recoilValue: t,
        unvalidatedValue: n
    })
}

function yw(e, {
    key: t
}, n, r = null) {
    const o = nw(),
        l = e.getState();
    l.nodeToComponentSubscriptions.has(t) || l.nodeToComponentSubscriptions.set(t, new Map), Pe(l.nodeToComponentSubscriptions.get(t)).set(o, [r ? ? "<not captured>", n]);
    const s = ow();
    if (s.early && (s.mode === "LEGACY" || s.mode === "MUTABLE_SOURCE")) {
        const i = e.getState().nextTree;
        i && i.dirtyAtoms.has(t) && n(i)
    }
    return {
        release: () => {
            const i = e.getState(),
                u = i.nodeToComponentSubscriptions.get(t);
            u === void 0 || !u.has(o) || (u.delete(o), u.size === 0 && i.nodeToComponentSubscriptions.delete(t))
        }
    }
}

function _w(e, t) {
    var n;
    const {
        currentTree: r
    } = e.getState(), o = rw(t.key);
    (n = o.clearCache) === null || n === void 0 || n.call(o, e, r)
}
var en = {
    RecoilValueReadOnly: aw,
    AbstractRecoilValue: lw,
    RecoilState: sw,
    getRecoilValueAsLoadable: cw,
    setRecoilValue: Hv,
    setRecoilValueLoadable: hw,
    markRecoilValueModified: vw,
    setUnvalidatedRecoilValue: gw,
    subscribeToRecoilValue: yw,
    isRecoilValue: iw,
    applyAtomValueWrites: dw,
    batchStart: pw,
    writeLoadableToTreeState: hc,
    invalidateDownstreams: $v,
    copyTreeState: Vv,
    refreshRecoilValue: _w
};

function Sw(e, t, n) {
    const r = e.entries();
    let o = r.next();
    for (; !o.done;) {
        const l = o.value;
        if (t.call(n, l[1], l[0], e)) return !0;
        o = r.next()
    }
    return !1
}
var ww = Sw;
const {
    cleanUpNode: Ew
} = Jn, {
    deleteNodeConfigIfPossible: xw,
    getNode: Bv
} = gt, {
    RetentionZone: zv
} = Ba, Nw = 12e4, Wv = new Set;

function Kv(e, t) {
    const n = e.getState(),
        r = n.currentTree;
    if (n.nextTree) return;
    const o = new Set;
    for (const s of t)
        if (s instanceof zv)
            for (const i of Tw(n, s)) o.add(i);
        else o.add(s);
    const l = Rw(e, o);
    for (const s of l) Aw(e, r, s)
}

function Rw(e, t) {
    const n = e.getState(),
        r = n.currentTree,
        o = e.getGraph(r.version),
        l = new Set,
        s = new Set;
    return i(t), l;

    function i(u) {
        const c = new Set,
            f = kw(e, r, u, l, s);
        for (const v of f) {
            var d;
            if (Bv(v).retainedBy === "recoilRoot") {
                s.add(v);
                continue
            }
            if (((d = n.retention.referenceCounts.get(v)) !== null && d !== void 0 ? d : 0) > 0) {
                s.add(v);
                continue
            }
            if (Gv(v).some(R => n.retention.referenceCounts.get(R))) {
                s.add(v);
                continue
            }
            const _ = o.nodeToNodeSubscriptions.get(v);
            if (_ && ww(_, R => s.has(R))) {
                s.add(v);
                continue
            }
            l.add(v), c.add(v)
        }
        const g = new Set;
        for (const v of c)
            for (const _ of (S = o.nodeDeps.get(v)) !== null && S !== void 0 ? S : Wv) {
                var S;
                l.has(_) || g.add(_)
            }
        g.size && i(g)
    }
}

function kw(e, t, n, r, o) {
    const l = e.getGraph(t.version),
        s = [],
        i = new Set;
    for (; n.size > 0;) u(Pe(n.values().next().value));
    return s;

    function u(c) {
        if (r.has(c) || o.has(c)) {
            n.delete(c);
            return
        }
        if (i.has(c)) return;
        const f = l.nodeToNodeSubscriptions.get(c);
        if (f)
            for (const d of f) u(d);
        i.add(c), n.delete(c), s.push(c)
    }
}

function Aw(e, t, n) {
    if (!xe("recoil_memory_managament_2020")) return;
    Ew(e, n);
    const r = e.getState();
    r.knownAtoms.delete(n), r.knownSelectors.delete(n), r.nodeTransactionSubscriptions.delete(n), r.retention.referenceCounts.delete(n);
    const o = Gv(n);
    for (const u of o) {
        var l;
        (l = r.retention.nodesRetainedByZone.get(u)) === null || l === void 0 || l.delete(n)
    }
    t.atomValues.delete(n), t.dirtyAtoms.delete(n), t.nonvalidatedAtoms.delete(n);
    const s = r.graphsByVersion.get(t.version);
    if (s) {
        const u = s.nodeDeps.get(n);
        if (u !== void 0) {
            s.nodeDeps.delete(n);
            for (const c of u) {
                var i;
                (i = s.nodeToNodeSubscriptions.get(c)) === null || i === void 0 || i.delete(n)
            }
        }
        s.nodeToNodeSubscriptions.delete(n)
    }
    xw(n)
}

function Tw(e, t) {
    var n;
    return (n = e.retention.nodesRetainedByZone.get(t)) !== null && n !== void 0 ? n : Wv
}

function Gv(e) {
    const t = Bv(e).retainedBy;
    return t === void 0 || t === "components" || t === "recoilRoot" ? [] : t instanceof zv ? [t] : t
}

function jw(e, t) {
    const n = e.getState();
    n.nextTree ? n.retention.retainablesToCheckForRelease.add(t) : Kv(e, new Set([t]))
}

function Cw(e, t, n) {
    var r;
    if (!xe("recoil_memory_managament_2020")) return;
    const o = e.getState().retention.referenceCounts,
        l = ((r = o.get(t)) !== null && r !== void 0 ? r : 0) + n;
    l === 0 ? qv(e, t) : o.set(t, l)
}

function qv(e, t) {
    if (!xe("recoil_memory_managament_2020")) return;
    e.getState().retention.referenceCounts.delete(t), jw(e, t)
}

function Lw(e) {
    if (!xe("recoil_memory_managament_2020")) return;
    const t = e.getState();
    Kv(e, t.retention.retainablesToCheckForRelease), t.retention.retainablesToCheckForRelease.clear()
}

function Dw(e) {
    return e === void 0 ? "recoilRoot" : e
}
var Nr = {
    SUSPENSE_TIMEOUT_MS: Nw,
    updateRetainCount: Cw,
    updateRetainCountToZero: qv,
    releaseScheduledRetainablesNow: Lw,
    retainedByOptionWithDefault: Dw
};
const {
    unstable_batchedUpdates: Pw
} = kS;
var Ow = {
    unstable_batchedUpdates: Pw
};
const {
    unstable_batchedUpdates: bw
} = Ow;
var Iw = {
    unstable_batchedUpdates: bw
};
const {
    batchStart: Mw
} = en, {
    unstable_batchedUpdates: Uw
} = Iw;
let bd = Uw || (e => e());
const Fw = e => {
        bd = e
    },
    Vw = () => bd,
    $w = e => {
        bd(() => {
            let t = () => {};
            try {
                t = Mw(), e()
            } finally {
                t()
            }
        })
    };
var Wa = {
    getBatcher: Vw,
    setBatcher: Fw,
    batchUpdates: $w
};

function* Hw(e) {
    for (const t of e)
        for (const n of t) yield n
}
var Yv = Hw;
const Qv = typeof Window > "u" || typeof window > "u",
    Bw = e => !Qv && (e === window || e instanceof Window),
    zw = typeof navigator < "u" && navigator.product === "ReactNative";
var Ka = {
    isSSR: Qv,
    isReactNative: zw,
    isWindow: Bw
};

function Ww(e, t) {
    let n;
    return (...r) => {
        n || (n = {});
        const o = t(...r);
        return Object.hasOwnProperty.call(n, o) || (n[o] = e(...r)), n[o]
    }
}

function Kw(e, t) {
    let n, r;
    return (...o) => {
        const l = t(...o);
        return n === l || (n = l, r = e(...o)), r
    }
}

function Gw(e, t) {
    let n, r;
    return [(...s) => {
        const i = t(...s);
        return n === i || (n = i, r = e(...s)), r
    }, () => {
        n = null
    }]
}
var qw = {
    memoizeWithArgsHash: Ww,
    memoizeOneWithArgsHash: Kw,
    memoizeOneWithArgsHashAndInvalidation: Gw
};
const {
    batchUpdates: vc
} = Wa, {
    initializeNode: Yw,
    peekNodeInfo: Qw
} = Jn, {
    graph: Xw
} = Cl, {
    getNextStoreID: Jw
} = Ha, {
    DEFAULT_VALUE: Zw,
    recoilValues: dm,
    recoilValuesForKeys: fm
} = gt, {
    AbstractRecoilValue: eE,
    getRecoilValueAsLoadable: tE,
    setRecoilValue: mm,
    setUnvalidatedRecoilValue: nE
} = en, {
    updateRetainCount: $s
} = Nr, {
    setInvalidateMemoizedSnapshot: rE
} = Iv, {
    getNextTreeStateVersion: oE,
    makeEmptyStoreState: lE
} = jv, {
    isSSR: sE
} = Ka, {
    memoizeOneWithArgsHashAndInvalidation: aE
} = qw;
class Ga {
    constructor(t, n) {
        se(this, "_store", void 0), se(this, "_refCount", 1), se(this, "getLoadable", r => (this.checkRefCount_INTERNAL(), tE(this._store, r))), se(this, "getPromise", r => (this.checkRefCount_INTERNAL(), this.getLoadable(r).toPromise())), se(this, "getNodes_UNSTABLE", r => {
            if (this.checkRefCount_INTERNAL(), (r == null ? void 0 : r.isModified) === !0) {
                if ((r == null ? void 0 : r.isInitialized) === !1) return [];
                const s = this._store.getState().currentTree;
                return fm(s.dirtyAtoms)
            }
            const o = this._store.getState().knownAtoms,
                l = this._store.getState().knownSelectors;
            return (r == null ? void 0 : r.isInitialized) == null ? dm.values() : r.isInitialized === !0 ? fm(Yv([o, l])) : Dd(dm.values(), ({
                key: s
            }) => !o.has(s) && !l.has(s))
        }), se(this, "getInfo_UNSTABLE", ({
            key: r
        }) => (this.checkRefCount_INTERNAL(), Qw(this._store, this._store.getState().currentTree, r))), se(this, "map", r => {
            this.checkRefCount_INTERNAL();
            const o = new gc(this, vc);
            return r(o), o
        }), se(this, "asyncMap", async r => {
            this.checkRefCount_INTERNAL();
            const o = new gc(this, vc);
            return o.retain(), await r(o), o.autoRelease_INTERNAL(), o
        }), this._store = {
            storeID: Jw(),
            parentStoreID: n,
            getState: () => t,
            replaceState: r => {
                t.currentTree = r(t.currentTree)
            },
            getGraph: r => {
                const o = t.graphsByVersion;
                if (o.has(r)) return Pe(o.get(r));
                const l = Xw();
                return o.set(r, l), l
            },
            subscribeToTransactions: () => ({
                release: () => {}
            }),
            addTransactionMetadata: () => {
                throw ie("Cannot subscribe to Snapshots")
            }
        };
        for (const r of this._store.getState().knownAtoms) Yw(this._store, r, "get"), $s(this._store, r, 1);
        this.autoRelease_INTERNAL()
    }
    retain() {
        this._refCount <= 0, this._refCount++;
        let t = !1;
        return () => {
            t || (t = !0, this._release())
        }
    }
    autoRelease_INTERNAL() {
        sE || window.setTimeout(() => this._release(), 10)
    }
    _release() {
        if (this._refCount--, this._refCount === 0) {
            if (this._store.getState().nodeCleanupFunctions.forEach(t => t()), this._store.getState().nodeCleanupFunctions.clear(), !xe("recoil_memory_managament_2020")) return
        } else this._refCount < 0
    }
    isRetained() {
        return this._refCount > 0
    }
    checkRefCount_INTERNAL() {
        xe("recoil_memory_managament_2020") && this._refCount <= 0
    }
    getStore_INTERNAL() {
        return this.checkRefCount_INTERNAL(), this._store
    }
    getID() {
        return this.checkRefCount_INTERNAL(), this._store.getState().currentTree.stateID
    }
    getStoreID() {
        return this.checkRefCount_INTERNAL(), this._store.storeID
    }
}

function Xv(e, t, n = !1) {
    const r = e.getState(),
        o = n ? oE() : t.version;
    return {
        currentTree: {
            version: n ? o : t.version,
            stateID: n ? o : t.stateID,
            transactionMetadata: { ...t.transactionMetadata
            },
            dirtyAtoms: new Set(t.dirtyAtoms),
            atomValues: t.atomValues.clone(),
            nonvalidatedAtoms: t.nonvalidatedAtoms.clone()
        },
        commitDepth: 0,
        nextTree: null,
        previousTree: null,
        knownAtoms: new Set(r.knownAtoms),
        knownSelectors: new Set(r.knownSelectors),
        transactionSubscriptions: new Map,
        nodeTransactionSubscriptions: new Map,
        nodeToComponentSubscriptions: new Map,
        queuedComponentCallbacks_DEPRECATED: [],
        suspendedComponentResolvers: new Set,
        graphsByVersion: new Map().set(o, e.getGraph(t.version)),
        retention: {
            referenceCounts: new Map,
            nodesRetainedByZone: new Map,
            retainablesToCheckForRelease: new Set
        },
        nodeCleanupFunctions: new Map($a(r.nodeCleanupFunctions.entries(), ([l]) => [l, () => {}]))
    }
}

function iE(e) {
    const t = new Ga(lE());
    return e != null ? t.map(e) : t
}
const [pm, Jv] = aE((e, t) => {
    var n;
    const r = e.getState(),
        o = t === "latest" ? (n = r.nextTree) !== null && n !== void 0 ? n : r.currentTree : Pe(r.previousTree);
    return new Ga(Xv(e, o), e.storeID)
}, (e, t) => {
    var n, r;
    return String(t) + String(e.storeID) + String((n = e.getState().nextTree) === null || n === void 0 ? void 0 : n.version) + String(e.getState().currentTree.version) + String((r = e.getState().previousTree) === null || r === void 0 ? void 0 : r.version)
});
rE(Jv);

function uE(e, t = "latest") {
    const n = pm(e, t);
    return n.isRetained() ? n : (Jv(), pm(e, t))
}
class gc extends Ga {
    constructor(t, n) {
        super(Xv(t.getStore_INTERNAL(), t.getStore_INTERNAL().getState().currentTree, !0), t.getStoreID()), se(this, "_batch", void 0), se(this, "set", (r, o) => {
            this.checkRefCount_INTERNAL();
            const l = this.getStore_INTERNAL();
            this._batch(() => {
                $s(l, r.key, 1), mm(this.getStore_INTERNAL(), r, o)
            })
        }), se(this, "reset", r => {
            this.checkRefCount_INTERNAL();
            const o = this.getStore_INTERNAL();
            this._batch(() => {
                $s(o, r.key, 1), mm(this.getStore_INTERNAL(), r, Zw)
            })
        }), se(this, "setUnvalidatedAtomValues_DEPRECATED", r => {
            this.checkRefCount_INTERNAL();
            const o = this.getStore_INTERNAL();
            vc(() => {
                for (const [l, s] of r.entries()) $s(o, l, 1), nE(o, new eE(l), s)
            })
        }), this._batch = n
    }
}
var qa = {
        Snapshot: Ga,
        MutableSnapshot: gc,
        freshSnapshot: iE,
        cloneSnapshot: uE
    },
    cE = qa.Snapshot,
    dE = qa.MutableSnapshot,
    fE = qa.freshSnapshot,
    mE = qa.cloneSnapshot,
    Ya = Object.freeze({
        __proto__: null,
        Snapshot: cE,
        MutableSnapshot: dE,
        freshSnapshot: fE,
        cloneSnapshot: mE
    });

function pE(...e) {
    const t = new Set;
    for (const n of e)
        for (const r of n) t.add(r);
    return t
}
var hE = pE;
const {
    useRef: vE
} = Ce;

function gE(e) {
    const t = vE(e);
    return t.current === e && typeof e == "function" && (t.current = e()), t
}
var hm = gE;
const {
    getNextTreeStateVersion: yE,
    makeEmptyStoreState: Zv
} = jv, {
    cleanUpNode: _E,
    getDownstreamNodes: SE,
    initializeNode: wE,
    setNodeValue: EE,
    setUnvalidatedAtomValue_DEPRECATED: xE
} = Jn, {
    graph: NE
} = Cl, {
    cloneGraph: RE
} = Cl, {
    getNextStoreID: eg
} = Ha, {
    createMutableSource: uu,
    reactMode: tg
} = jl, {
    applyAtomValueWrites: kE
} = en, {
    releaseScheduledRetainablesNow: ng
} = Nr, {
    freshSnapshot: AE
} = Ya, {
    useCallback: TE,
    useContext: rg,
    useEffect: yc,
    useMemo: jE,
    useRef: CE,
    useState: LE
} = Ce;

function Lo() {
    throw ie("This component must be used inside a <RecoilRoot> component.")
}
const og = Object.freeze({
    storeID: eg(),
    getState: Lo,
    replaceState: Lo,
    getGraph: Lo,
    subscribeToTransactions: Lo,
    addTransactionMetadata: Lo
});
let _c = !1;

function vm(e) {
    if (_c) throw ie("An atom update was triggered within the execution of a state updater function. State updater functions provided to Recoil must be pure functions.");
    const t = e.getState();
    if (t.nextTree === null) {
        xe("recoil_memory_managament_2020") && xe("recoil_release_on_cascading_update_killswitch_2021") && t.commitDepth > 0 && ng(e);
        const n = t.currentTree.version,
            r = yE();
        t.nextTree = { ...t.currentTree,
            version: r,
            stateID: r,
            dirtyAtoms: new Set,
            transactionMetadata: {}
        }, t.graphsByVersion.set(r, RE(Pe(t.graphsByVersion.get(n))))
    }
}
const lg = Ce.createContext({
        current: og
    }),
    Qa = () => rg(lg),
    sg = Ce.createContext(null);

function DE() {
    return rg(sg)
}

function Id(e, t, n) {
    const r = SE(e, n, n.dirtyAtoms);
    for (const o of r) {
        const l = t.nodeToComponentSubscriptions.get(o);
        if (l)
            for (const [s, [i, u]] of l) u(n)
    }
}

function ag(e) {
    const t = e.getState(),
        n = t.currentTree,
        r = n.dirtyAtoms;
    if (r.size) {
        for (const [o, l] of t.nodeTransactionSubscriptions)
            if (r.has(o))
                for (const [s, i] of l) i(e);
        for (const [o, l] of t.transactionSubscriptions) l(e);
        (!tg().early || t.suspendedComponentResolvers.size > 0) && (Id(e, t, n), t.suspendedComponentResolvers.forEach(o => o()), t.suspendedComponentResolvers.clear())
    }
    t.queuedComponentCallbacks_DEPRECATED.forEach(o => o(n)), t.queuedComponentCallbacks_DEPRECATED.splice(0, t.queuedComponentCallbacks_DEPRECATED.length)
}

function PE(e) {
    const t = e.getState();
    t.commitDepth++;
    try {
        const {
            nextTree: n
        } = t;
        if (n == null) return;
        t.previousTree = t.currentTree, t.currentTree = n, t.nextTree = null, ag(e), t.previousTree != null ? t.graphsByVersion.delete(t.previousTree.version) : Ad("Ended batch with no previous state, which is unexpected", "recoil"), t.previousTree = null, xe("recoil_memory_managament_2020") && n == null && ng(e)
    } finally {
        t.commitDepth--
    }
}

function OE({
    setNotifyBatcherOfChange: e
}) {
    const t = Qa(),
        [, n] = LE([]);
    return e(() => n({})), yc(() => (e(() => n({})), () => {
        e(() => {})
    }), [e]), yc(() => {
        f1.enqueueExecution("Batcher", () => {
            PE(t.current)
        })
    }), null
}

function bE(e, t) {
    const n = Zv();
    return t({
        set: (r, o) => {
            const l = n.currentTree,
                s = EE(e, l, r.key, o),
                i = new Set(s.keys()),
                u = l.nonvalidatedAtoms.clone();
            for (const c of i) u.delete(c);
            n.currentTree = { ...l,
                dirtyAtoms: hE(l.dirtyAtoms, i),
                atomValues: kE(l.atomValues, s),
                nonvalidatedAtoms: u
            }
        },
        setUnvalidatedAtomValues: r => {
            r.forEach((o, l) => {
                n.currentTree = xE(n.currentTree, l, o)
            })
        }
    }), n
}

function IE(e) {
    const t = AE(e),
        n = t.getStore_INTERNAL().getState();
    return t.retain(), n.nodeCleanupFunctions.forEach(r => r()), n.nodeCleanupFunctions.clear(), n
}
let gm = 0;

function ME({
    initializeState_DEPRECATED: e,
    initializeState: t,
    store_INTERNAL: n,
    children: r
}) {
    let o;
    const l = S => {
            const v = o.current.graphsByVersion;
            if (v.has(S)) return Pe(v.get(S));
            const _ = NE();
            return v.set(S, _), _
        },
        s = (S, v) => {
            if (v == null) {
                const {
                    transactionSubscriptions: _
                } = d.current.getState(), R = gm++;
                return _.set(R, S), {
                    release: () => {
                        _.delete(R)
                    }
                }
            } else {
                const {
                    nodeTransactionSubscriptions: _
                } = d.current.getState();
                _.has(v) || _.set(v, new Map);
                const R = gm++;
                return Pe(_.get(v)).set(R, S), {
                    release: () => {
                        const p = _.get(v);
                        p && (p.delete(R), p.size === 0 && _.delete(v))
                    }
                }
            }
        },
        i = S => {
            vm(d.current);
            for (const v of Object.keys(S)) Pe(d.current.getState().nextTree).transactionMetadata[v] = S[v]
        },
        u = S => {
            vm(d.current);
            const v = Pe(o.current.nextTree);
            let _;
            try {
                _c = !0, _ = S(v)
            } finally {
                _c = !1
            }
            _ !== v && (o.current.nextTree = _, tg().early && Id(d.current, o.current, _), Pe(c.current)())
        },
        c = CE(null),
        f = TE(S => {
            c.current = S
        }, [c]),
        d = hm(() => n ? ? {
            storeID: eg(),
            getState: () => o.current,
            replaceState: u,
            getGraph: l,
            subscribeToTransactions: s,
            addTransactionMetadata: i
        });
    n != null && (d.current = n), o = hm(() => e != null ? bE(d.current, e) : t != null ? IE(t) : Zv());
    const g = jE(() => uu == null ? void 0 : uu(o, () => o.current.currentTree.version), [o]);
    return yc(() => {
        const S = d.current;
        for (const v of new Set(S.getState().knownAtoms)) wE(S, v, "get");
        return () => {
            for (const v of S.getState().knownAtoms) _E(S, v)
        }
    }, [d]), Ce.createElement(lg.Provider, {
        value: d
    }, Ce.createElement(sg.Provider, {
        value: g
    }, Ce.createElement(OE, {
        setNotifyBatcherOfChange: f
    }), r))
}

function UE(e) {
    const {
        override: t,
        ...n
    } = e, r = Qa();
    return t === !1 && r.current !== og ? e.children : Ce.createElement(ME, n)
}

function FE() {
    return Qa().current.storeID
}
var yn = {
    RecoilRoot: UE,
    useStoreRef: Qa,
    useRecoilMutableSource: DE,
    useRecoilStoreID: FE,
    notifyComponents_FOR_TESTING: Id,
    sendEndOfBatchNotifications_FOR_TESTING: ag
};

function VE(e, t) {
    if (e === t) return !0;
    if (e.length !== t.length) return !1;
    for (let n = 0, r = e.length; n < r; n++)
        if (e[n] !== t[n]) return !1;
    return !0
}
var $E = VE;
const {
    useEffect: HE,
    useRef: BE
} = Ce;

function zE(e) {
    const t = BE();
    return HE(() => {
        t.current = e
    }), t.current
}
var ig = zE;
const {
    useStoreRef: WE
} = yn, {
    SUSPENSE_TIMEOUT_MS: KE
} = Nr, {
    updateRetainCount: Do
} = Nr, {
    RetentionZone: GE
} = Ba, {
    useEffect: qE,
    useRef: YE
} = Ce, {
    isSSR: ym
} = Ka;

function QE(e) {
    if (xe("recoil_memory_managament_2020")) return XE(e)
}

function XE(e) {
    const n = (Array.isArray(e) ? e : [e]).map(s => s instanceof GE ? s : s.key),
        r = WE();
    qE(() => {
        if (!xe("recoil_memory_managament_2020")) return;
        const s = r.current;
        if (o.current && !ym) window.clearTimeout(o.current), o.current = null;
        else
            for (const i of n) Do(s, i, 1);
        return () => {
            for (const i of n) Do(s, i, -1)
        }
    }, [r, ...n]);
    const o = YE(),
        l = ig(n);
    if (!ym && (l === void 0 || !$E(l, n))) {
        const s = r.current;
        for (const i of n) Do(s, i, 1);
        if (l)
            for (const i of l) Do(s, i, -1);
        o.current && window.clearTimeout(o.current), o.current = window.setTimeout(() => {
            o.current = null;
            for (const i of n) Do(s, i, -1)
        }, KE)
    }
}
var Md = QE;

function JE() {
    return "<component name not available>"
}
var Dl = JE;
const {
    batchUpdates: ZE
} = Wa, {
    DEFAULT_VALUE: ug
} = gt, {
    currentRendererSupportsUseSyncExternalStore: ex,
    reactMode: yo,
    useMutableSource: tx,
    useSyncExternalStore: nx
} = jl, {
    useRecoilMutableSource: rx,
    useStoreRef: tn
} = yn, {
    AbstractRecoilValue: Sc,
    getRecoilValueAsLoadable: Pl,
    setRecoilValue: ga,
    setUnvalidatedRecoilValue: ox,
    subscribeToRecoilValue: uo
} = en, {
    useCallback: vt,
    useEffect: co,
    useMemo: cg,
    useRef: tl,
    useState: Ud
} = Ce, {
    setByAddingToSet: lx
} = Lv, {
    isSSR: sx
} = Ka;

function Fd(e, t, n) {
    if (e.state === "hasValue") return e.contents;
    throw e.state === "loading" ? new Promise(o => {
        const l = n.current.getState().suspendedComponentResolvers;
        l.add(o), sx && Te(e.contents) && e.contents.finally(() => {
            l.delete(o)
        })
    }) : e.state === "hasError" ? e.contents : ie(`Invalid value of loadable atom "${t.key}"`)
}

function ax() {
    const e = Dl(),
        t = tn(),
        [, n] = Ud([]),
        r = tl(new Set);
    r.current = new Set;
    const o = tl(new Set),
        l = tl(new Map),
        s = vt(u => {
            const c = l.current.get(u);
            c && (c.release(), l.current.delete(u))
        }, [l]),
        i = vt((u, c) => {
            l.current.has(c) && n([])
        }, []);
    return co(() => {
        const u = t.current;
        Zo(r.current, o.current).forEach(c => {
            if (l.current.has(c)) return;
            const f = uo(u, new Sc(c), g => i(g, c), e);
            l.current.set(c, f), u.getState().nextTree ? u.getState().queuedComponentCallbacks_DEPRECATED.push(() => {
                i(u.getState(), c)
            }) : i(u.getState(), c)
        }), Zo(o.current, r.current).forEach(c => {
            s(c)
        }), o.current = r.current
    }), co(() => {
        const u = l.current;
        return Zo(r.current, new Set(u.keys())).forEach(c => {
            const f = uo(t.current, new Sc(c), d => i(d, c), e);
            u.set(c, f)
        }), () => u.forEach((c, f) => s(f))
    }, [e, t, s, i]), cg(() => {
        function u(v) {
            return _ => {
                ga(t.current, v, _)
            }
        }

        function c(v) {
            return () => ga(t.current, v, ug)
        }

        function f(v) {
            var _;
            r.current.has(v.key) || (r.current = lx(r.current, v.key));
            const R = t.current.getState();
            return Pl(t.current, v, yo().early && (_ = R.nextTree) !== null && _ !== void 0 ? _ : R.currentTree)
        }

        function d(v) {
            const _ = f(v);
            return Fd(_, v, t)
        }

        function g(v) {
            return [d(v), u(v)]
        }

        function S(v) {
            return [f(v), u(v)]
        }
        return {
            getRecoilValue: d,
            getRecoilValueLoadable: f,
            getRecoilState: g,
            getRecoilStateLoadable: S,
            getSetRecoilState: u,
            getResetRecoilState: c
        }
    }, [r, t])
}
const ix = {
    current: 0
};

function ux(e) {
    const t = tn(),
        n = Dl(),
        r = vt(() => {
            var i;
            const u = t.current,
                c = u.getState(),
                f = yo().early && (i = c.nextTree) !== null && i !== void 0 ? i : c.currentTree;
            return {
                loadable: Pl(u, e, f),
                key: e.key
            }
        }, [t, e]),
        o = vt(i => {
            let u;
            return () => {
                var c, f;
                const d = i();
                return (c = u) !== null && c !== void 0 && c.loadable.is(d.loadable) && ((f = u) === null || f === void 0 ? void 0 : f.key) === d.key ? u : (u = d, d)
            }
        }, []),
        l = cg(() => o(r), [r, o]),
        s = vt(i => {
            const u = t.current;
            return uo(u, e, i, n).release
        }, [t, e, n]);
    return nx(s, l, l).loadable
}

function cx(e) {
    const t = tn(),
        n = vt(() => {
            var c;
            const f = t.current,
                d = f.getState(),
                g = yo().early && (c = d.nextTree) !== null && c !== void 0 ? c : d.currentTree;
            return Pl(f, e, g)
        }, [t, e]),
        r = vt(() => n(), [n]),
        o = Dl(),
        l = vt((c, f) => {
            const d = t.current;
            return uo(d, e, () => {
                if (!xe("recoil_suppress_rerender_in_callback")) return f();
                const S = n();
                u.current.is(S) || f(), u.current = S
            }, o).release
        }, [t, e, o, n]),
        s = rx();
    if (s == null) throw ie("Recoil hooks must be used in components contained within a <RecoilRoot> component.");
    const i = tx(s, r, l),
        u = tl(i);
    return co(() => {
        u.current = i
    }), i
}

function wc(e) {
    const t = tn(),
        n = Dl(),
        r = vt(() => {
            var u;
            const c = t.current,
                f = c.getState(),
                d = yo().early && (u = f.nextTree) !== null && u !== void 0 ? u : f.currentTree;
            return Pl(c, e, d)
        }, [t, e]),
        o = vt(() => ({
            loadable: r(),
            key: e.key
        }), [r, e.key]),
        l = vt(u => {
            const c = o();
            return u.loadable.is(c.loadable) && u.key === c.key ? u : c
        }, [o]);
    co(() => {
        const u = uo(t.current, e, c => {
            i(l)
        }, n);
        return i(l), u.release
    }, [n, e, t, l]);
    const [s, i] = Ud(o);
    return s.key !== e.key ? o().loadable : s.loadable
}

function dx(e) {
    const t = tn(),
        [, n] = Ud([]),
        r = Dl(),
        o = vt(() => {
            var i;
            const u = t.current,
                c = u.getState(),
                f = yo().early && (i = c.nextTree) !== null && i !== void 0 ? i : c.currentTree;
            return Pl(u, e, f)
        }, [t, e]),
        l = o(),
        s = tl(l);
    return co(() => {
        s.current = l
    }), co(() => {
        const i = t.current,
            u = i.getState(),
            c = uo(i, e, d => {
                var g;
                if (!xe("recoil_suppress_rerender_in_callback")) return n([]);
                const S = o();
                (g = s.current) !== null && g !== void 0 && g.is(S) || n(S), s.current = S
            }, r);
        if (u.nextTree) i.getState().queuedComponentCallbacks_DEPRECATED.push(() => {
            s.current = null, n([])
        });
        else {
            var f;
            if (!xe("recoil_suppress_rerender_in_callback")) return n([]);
            const d = o();
            (f = s.current) !== null && f !== void 0 && f.is(d) || n(d), s.current = d
        }
        return c.release
    }, [r, o, e, t]), l
}

function Vd(e) {
    return xe("recoil_memory_managament_2020") && Md(e), {
        TRANSITION_SUPPORT: wc,
        SYNC_EXTERNAL_STORE: ex() ? ux : wc,
        MUTABLE_SOURCE: cx,
        LEGACY: dx
    }[yo().mode](e)
}

function dg(e) {
    const t = tn(),
        n = Vd(e);
    return Fd(n, e, t)
}

function Xa(e) {
    const t = tn();
    return vt(n => {
        ga(t.current, e, n)
    }, [t, e])
}

function fx(e) {
    const t = tn();
    return vt(() => {
        ga(t.current, e, ug)
    }, [t, e])
}

function mx(e) {
    return [dg(e), Xa(e)]
}

function px(e) {
    return [Vd(e), Xa(e)]
}

function hx() {
    const e = tn();
    return (t, n = {}) => {
        ZE(() => {
            e.current.addTransactionMetadata(n), t.forEach((r, o) => ox(e.current, new Sc(o), r))
        })
    }
}

function fg(e) {
    return xe("recoil_memory_managament_2020") && Md(e), wc(e)
}

function mg(e) {
    const t = tn(),
        n = fg(e);
    return Fd(n, e, t)
}

function vx(e) {
    return [mg(e), Xa(e)]
}
var gx = {
    recoilComponentGetRecoilValueCount_FOR_TESTING: ix,
    useRecoilInterface: ax,
    useRecoilState: mx,
    useRecoilStateLoadable: px,
    useRecoilValue: dg,
    useRecoilValueLoadable: Vd,
    useResetRecoilState: fx,
    useSetRecoilState: Xa,
    useSetUnvalidatedAtomValues: hx,
    useRecoilValueLoadable_TRANSITION_SUPPORT_UNSTABLE: fg,
    useRecoilValue_TRANSITION_SUPPORT_UNSTABLE: mg,
    useRecoilState_TRANSITION_SUPPORT_UNSTABLE: vx
};

function yx(e, t) {
    const n = new Map;
    for (const [r, o] of e) t(o, r) && n.set(r, o);
    return n
}
var _x = yx;

function Sx(e, t) {
    const n = new Set;
    for (const r of e) t(r) && n.add(r);
    return n
}
var wx = Sx;

function Ex(...e) {
    const t = new Map;
    for (let n = 0; n < e.length; n++) {
        const r = e[n].keys();
        let o;
        for (; !(o = r.next()).done;) t.set(o.value, e[n].get(o.value))
    }
    return t
}
var xx = Ex;
const {
    batchUpdates: Nx
} = Wa, {
    DEFAULT_VALUE: Rx,
    getNode: pg,
    nodes: kx
} = gt, {
    useStoreRef: $d
} = yn, {
    AbstractRecoilValue: Ax,
    setRecoilValueLoadable: Tx
} = en, {
    SUSPENSE_TIMEOUT_MS: jx
} = Nr, {
    cloneSnapshot: ya
} = Ya, {
    useCallback: Ja,
    useEffect: hg,
    useRef: _m,
    useState: Cx
} = Ce, {
    isSSR: Sm
} = Ka;

function Za(e) {
    const t = $d();
    hg(() => t.current.subscribeToTransactions(e).release, [e, t])
}

function wm(e) {
    const t = e.atomValues.toMap(),
        n = va(_x(t, (r, o) => {
            const s = pg(o).persistence_UNSTABLE;
            return s != null && s.type !== "none" && r.state === "hasValue"
        }), r => r.contents);
    return xx(e.nonvalidatedAtoms.toMap(), n)
}

function Lx(e) {
    Za(Ja(t => {
        let n = t.getState().previousTree;
        const r = t.getState().currentTree;
        n || (n = t.getState().currentTree);
        const o = wm(r),
            l = wm(n),
            s = va(kx, u => {
                var c, f, d, g;
                return {
                    persistence_UNSTABLE: {
                        type: (c = (f = u.persistence_UNSTABLE) === null || f === void 0 ? void 0 : f.type) !== null && c !== void 0 ? c : "none",
                        backButton: (d = (g = u.persistence_UNSTABLE) === null || g === void 0 ? void 0 : g.backButton) !== null && d !== void 0 ? d : !1
                    }
                }
            }),
            i = wx(r.dirtyAtoms, u => o.has(u) || l.has(u));
        e({
            atomValues: o,
            previousAtomValues: l,
            atomInfo: s,
            modifiedAtoms: i,
            transactionMetadata: { ...r.transactionMetadata
            }
        })
    }, [e]))
}

function Dx(e) {
    Za(Ja(t => {
        const n = ya(t, "latest"),
            r = ya(t, "previous");
        e({
            snapshot: n,
            previousSnapshot: r
        })
    }, [e]))
}

function Px() {
    const e = $d(),
        [t, n] = Cx(() => ya(e.current)),
        r = ig(t),
        o = _m(),
        l = _m();
    if (Za(Ja(i => n(ya(i)), [])), hg(() => {
            const i = t.retain();
            if (o.current && !Sm) {
                var u;
                window.clearTimeout(o.current), o.current = null, (u = l.current) === null || u === void 0 || u.call(l), l.current = null
            }
            return () => {
                window.setTimeout(i, 10)
            }
        }, [t]), r !== t && !Sm) {
        if (o.current) {
            var s;
            window.clearTimeout(o.current), o.current = null, (s = l.current) === null || s === void 0 || s.call(l), l.current = null
        }
        l.current = t.retain(), o.current = window.setTimeout(() => {
            var i;
            o.current = null, (i = l.current) === null || i === void 0 || i.call(l), l.current = null
        }, jx)
    }
    return t
}

function vg(e, t) {
    var n;
    const r = e.getState(),
        o = (n = r.nextTree) !== null && n !== void 0 ? n : r.currentTree,
        l = t.getStore_INTERNAL().getState().currentTree;
    Nx(() => {
        const s = new Set;
        for (const c of [o.atomValues.keys(), l.atomValues.keys()])
            for (const f of c) {
                var i, u;
                ((i = o.atomValues.get(f)) === null || i === void 0 ? void 0 : i.contents) !== ((u = l.atomValues.get(f)) === null || u === void 0 ? void 0 : u.contents) && pg(f).shouldRestoreFromSnapshots && s.add(f)
            }
        s.forEach(c => {
            Tx(e, new Ax(c), l.atomValues.has(c) ? Pe(l.atomValues.get(c)) : Rx)
        }), e.replaceState(c => ({ ...c,
            stateID: t.getID()
        }))
    })
}

function Ox() {
    const e = $d();
    return Ja(t => vg(e.current, t), [e])
}
var gg = {
    useRecoilSnapshot: Px,
    gotoSnapshot: vg,
    useGotoRecoilSnapshot: Ox,
    useRecoilTransactionObserver: Dx,
    useTransactionObservation_DEPRECATED: Lx,
    useTransactionSubscription_DEPRECATED: Za
};
const {
    peekNodeInfo: bx
} = Jn, {
    useStoreRef: Ix
} = yn;

function Mx() {
    const e = Ix();
    return ({
        key: t
    }) => bx(e.current, e.current.getState().currentTree, t)
}
var Ux = Mx;
const {
    reactMode: Fx
} = jl, {
    RecoilRoot: Vx,
    useStoreRef: $x
} = yn, {
    useMemo: Hx
} = Ce;

function Bx() {
    Fx().mode === "MUTABLE_SOURCE" && console.warn("Warning: There are known issues using useRecoilBridgeAcrossReactRoots() in recoil_mutable_source rendering mode.  Please consider upgrading to recoil_sync_external_store mode.");
    const e = $x().current;
    return Hx(() => {
        function t({
            children: n
        }) {
            return Ce.createElement(Vx, {
                store_INTERNAL: e
            }, n)
        }
        return t
    }, [e])
}
var zx = Bx;
const {
    loadableWithValue: Wx
} = Tl, {
    initializeNode: Kx
} = Jn, {
    DEFAULT_VALUE: Gx,
    getNode: qx
} = gt, {
    copyTreeState: Yx,
    getRecoilValueAsLoadable: Qx,
    invalidateDownstreams: Xx,
    writeLoadableToTreeState: Jx
} = en;

function Em(e) {
    return qx(e.key).nodeType === "atom"
}
class Zx {
    constructor(t, n) {
        se(this, "_store", void 0), se(this, "_treeState", void 0), se(this, "_changes", void 0), se(this, "get", r => {
            if (this._changes.has(r.key)) return this._changes.get(r.key);
            if (!Em(r)) throw ie("Reading selectors within atomicUpdate is not supported");
            const o = Qx(this._store, r, this._treeState);
            if (o.state === "hasValue") return o.contents;
            throw o.state === "hasError" ? o.contents : ie(`Expected Recoil atom ${r.key} to have a value, but it is in a loading state.`)
        }), se(this, "set", (r, o) => {
            if (!Em(r)) throw ie("Setting selectors within atomicUpdate is not supported");
            if (typeof o == "function") {
                const l = this.get(r);
                this._changes.set(r.key, o(l))
            } else Kx(this._store, r.key, "set"), this._changes.set(r.key, o)
        }), se(this, "reset", r => {
            this.set(r, Gx)
        }), this._store = t, this._treeState = n, this._changes = new Map
    }
    newTreeState_INTERNAL() {
        if (this._changes.size === 0) return this._treeState;
        const t = Yx(this._treeState);
        for (const [n, r] of this._changes) Jx(t, n, Wx(r));
        return Xx(this._store, t), t
    }
}

function eN(e) {
    return t => {
        e.replaceState(n => {
            const r = new Zx(e, n);
            return t(r), r.newTreeState_INTERNAL()
        })
    }
}
var tN = {
        atomicUpdater: eN
    },
    nN = tN.atomicUpdater,
    yg = Object.freeze({
        __proto__: null,
        atomicUpdater: nN
    });

function rN(e, t) {
    if (!e) throw new Error(t)
}
var oN = rN,
    Bo = oN;
const {
    atomicUpdater: lN
} = yg, {
    batchUpdates: sN
} = Wa, {
    DEFAULT_VALUE: aN
} = gt, {
    useStoreRef: iN
} = yn, {
    refreshRecoilValue: uN,
    setRecoilValue: xm
} = en, {
    cloneSnapshot: cN
} = Ya, {
    gotoSnapshot: dN
} = gg, {
    useCallback: fN
} = Ce;
class _g {}
const mN = new _g;

function Sg(e, t, n, r) {
    let o = mN,
        l;
    if (sN(() => {
            const i = "useRecoilCallback() expects a function that returns a function: it accepts a function of the type (RecoilInterface) => (Args) => ReturnType and returns a callback function (Args) => ReturnType, where RecoilInterface is an object {snapshot, set, ...} and Args and ReturnType are the argument and return types of the callback you want to create.  Please see the docs at recoiljs.org for details.";
            if (typeof t != "function") throw ie(i);
            const u = Dv({ ...r ? ? {},
                    set : (f, d) => xm(e, f, d),
                    reset : f => xm(e, f, aN),
                    refresh: f => uN(e, f),
                    gotoSnapshot: f => dN(e, f),
                    transact_UNSTABLE: f => lN(e)(f)
                }, {
                    snapshot: () => {
                        const f = cN(e);
                        return l = f.retain(), f
                    }
                }),
                c = t(u);
            if (typeof c != "function") throw ie(i);
            o = c(...n)
        }), o instanceof _g && Bo(!1), Te(o)) o = o.finally(() => {
        var i;
        (i = l) === null || i === void 0 || i()
    });
    else {
        var s;
        (s = l) === null || s === void 0 || s()
    }
    return o
}

function pN(e, t) {
    const n = iN();
    return fN((...r) => Sg(n.current, e, r), t != null ? [...t, n] : void 0)
}
var wg = {
    recoilCallback: Sg,
    useRecoilCallback: pN
};
const {
    useStoreRef: hN
} = yn, {
    refreshRecoilValue: vN
} = en, {
    useCallback: gN
} = Ce;

function yN(e) {
    const t = hN();
    return gN(() => {
        const n = t.current;
        vN(n, e)
    }, [e, t])
}
var _N = yN;
const {
    atomicUpdater: SN
} = yg, {
    useStoreRef: wN
} = yn, {
    useMemo: EN
} = Ce;

function xN(e, t) {
    const n = wN();
    return EN(() => (...r) => {
        SN(n.current)(l => {
            e(l)(...r)
        })
    }, t != null ? [...t, n] : void 0)
}
var NN = xN;
class RN {
    constructor(t) {
        se(this, "value", void 0), this.value = t
    }
}
var kN = {
        WrappedValue: RN
    },
    AN = kN.WrappedValue,
    Eg = Object.freeze({
        __proto__: null,
        WrappedValue: AN
    });
const {
    isFastRefreshEnabled: TN
} = jl;
class Nm extends Error {}
class jN {
    constructor(t) {
        var n, r, o;
        se(this, "_name", void 0), se(this, "_numLeafs", void 0), se(this, "_root", void 0), se(this, "_onHit", void 0), se(this, "_onSet", void 0), se(this, "_mapNodeValue", void 0), this._name = t == null ? void 0 : t.name, this._numLeafs = 0, this._root = null, this._onHit = (n = t == null ? void 0 : t.onHit) !== null && n !== void 0 ? n : () => {}, this._onSet = (r = t == null ? void 0 : t.onSet) !== null && r !== void 0 ? r : () => {}, this._mapNodeValue = (o = t == null ? void 0 : t.mapNodeValue) !== null && o !== void 0 ? o : l => l
    }
    size() {
        return this._numLeafs
    }
    root() {
        return this._root
    }
    get(t, n) {
        var r;
        return (r = this.getLeafNode(t, n)) === null || r === void 0 ? void 0 : r.value
    }
    getLeafNode(t, n) {
        if (this._root == null) return;
        let r = this._root;
        for (; r;) {
            if (n == null || n.onNodeVisit(r), r.type === "leaf") return this._onHit(r), r;
            const o = this._mapNodeValue(t(r.nodeKey));
            r = r.branches.get(o)
        }
    }
    set(t, n, r) {
        const o = () => {
            var l, s, i, u;
            let c, f;
            for (const [R, p] of t) {
                var d, g, S;
                const m = this._root;
                if ((m == null ? void 0 : m.type) === "leaf") throw this.invalidCacheError();
                const h = c;
                if (c = h ? h.branches.get(f) : m, c = (d = c) !== null && d !== void 0 ? d : {
                        type: "branch",
                        nodeKey: R,
                        parent: h,
                        branches: new Map,
                        branchKey: f
                    }, c.type !== "branch" || c.nodeKey !== R) throw this.invalidCacheError();
                h == null || h.branches.set(f, c), r == null || (g = r.onNodeVisit) === null || g === void 0 || g.call(r, c), f = this._mapNodeValue(p), this._root = (S = this._root) !== null && S !== void 0 ? S : c
            }
            const v = c ? (l = c) === null || l === void 0 ? void 0 : l.branches.get(f) : this._root;
            if (v != null && (v.type !== "leaf" || v.branchKey !== f)) throw this.invalidCacheError();
            const _ = {
                type: "leaf",
                value: n,
                parent: c,
                branchKey: f
            };
            (s = c) === null || s === void 0 || s.branches.set(f, _), this._root = (i = this._root) !== null && i !== void 0 ? i : _, this._numLeafs++, this._onSet(_), r == null || (u = r.onNodeVisit) === null || u === void 0 || u.call(r, _)
        };
        try {
            o()
        } catch (l) {
            if (l instanceof Nm) this.clear(), o();
            else throw l
        }
    }
    delete(t) {
        const n = this.root();
        if (!n) return !1;
        if (t === n) return this._root = null, this._numLeafs = 0, !0;
        let r = t.parent,
            o = t.branchKey;
        for (; r;) {
            var l;
            if (r.branches.delete(o), r === n) return r.branches.size === 0 ? (this._root = null, this._numLeafs = 0) : this._numLeafs--, !0;
            if (r.branches.size > 0) break;
            o = (l = r) === null || l === void 0 ? void 0 : l.branchKey, r = r.parent
        }
        for (; r !== n; r = r.parent)
            if (r == null) return !1;
        return this._numLeafs--, !0
    }
    clear() {
        this._numLeafs = 0, this._root = null
    }
    invalidCacheError() {
        const t = TN() ? "Possible Fast Refresh module reload detected.  This may also be caused by an selector returning inconsistent values. Resetting cache." : "Invalid cache values.  This happens when selectors do not return consistent values for the same input dependency values.  That may also be caused when using Fast Refresh to change a selector implementation.  Resetting cache.";
        throw Ad(t + (this._name != null ? ` - ${this._name}` : "")), new Nm
    }
}
var CN = {
        TreeCache: jN
    },
    LN = CN.TreeCache,
    xg = Object.freeze({
        __proto__: null,
        TreeCache: LN
    });
class DN {
    constructor(t) {
        var n;
        se(this, "_maxSize", void 0), se(this, "_size", void 0), se(this, "_head", void 0), se(this, "_tail", void 0), se(this, "_map", void 0), se(this, "_keyMapper", void 0), this._maxSize = t.maxSize, this._size = 0, this._head = null, this._tail = null, this._map = new Map, this._keyMapper = (n = t.mapKey) !== null && n !== void 0 ? n : r => r
    }
    head() {
        return this._head
    }
    tail() {
        return this._tail
    }
    size() {
        return this._size
    }
    maxSize() {
        return this._maxSize
    }
    has(t) {
        return this._map.has(this._keyMapper(t))
    }
    get(t) {
        const n = this._keyMapper(t),
            r = this._map.get(n);
        if (r) return this.set(t, r.value), r.value
    }
    set(t, n) {
        const r = this._keyMapper(t);
        this._map.get(r) && this.delete(t);
        const l = this.head(),
            s = {
                key: t,
                right: l,
                left: null,
                value: n
            };
        l ? l.left = s : this._tail = s, this._map.set(r, s), this._head = s, this._size++, this._maybeDeleteLRU()
    }
    _maybeDeleteLRU() {
        this.size() > this.maxSize() && this.deleteLru()
    }
    deleteLru() {
        const t = this.tail();
        t && this.delete(t.key)
    }
    delete(t) {
        const n = this._keyMapper(t);
        if (!this._size || !this._map.has(n)) return;
        const r = Pe(this._map.get(n)),
            o = r.right,
            l = r.left;
        o && (o.left = r.left), l && (l.right = r.right), r === this.head() && (this._head = o), r === this.tail() && (this._tail = l), this._map.delete(n), this._size--
    }
    clear() {
        this._size = 0, this._head = null, this._tail = null, this._map = new Map
    }
}
var PN = {
        LRUCache: DN
    },
    ON = PN.LRUCache,
    Ng = Object.freeze({
        __proto__: null,
        LRUCache: ON
    });
const {
    LRUCache: bN
} = Ng, {
    TreeCache: IN
} = xg;

function MN({
    name: e,
    maxSize: t,
    mapNodeValue: n = r => r
}) {
    const r = new bN({
            maxSize: t
        }),
        o = new IN({
            name: e,
            mapNodeValue: n,
            onHit: l => {
                r.set(l, !0)
            },
            onSet: l => {
                const s = r.tail();
                r.set(l, !0), s && o.size() > t && o.delete(s.key)
            }
        });
    return o
}
var Rm = MN;

function Ft(e, t, n) {
    if (typeof e == "string" && !e.includes('"') && !e.includes("\\")) return `"${e}"`;
    switch (typeof e) {
        case "undefined":
            return "";
        case "boolean":
            return e ? "true" : "false";
        case "number":
        case "symbol":
            return String(e);
        case "string":
            return JSON.stringify(e);
        case "function":
            if ((t == null ? void 0 : t.allowFunctions) !== !0) throw ie("Attempt to serialize function in a Recoil cache key");
            return `__FUNCTION(${e.name})__`
    }
    if (e === null) return "null";
    if (typeof e != "object") {
        var r;
        return (r = JSON.stringify(e)) !== null && r !== void 0 ? r : ""
    }
    if (Te(e)) return "__PROMISE__";
    if (Array.isArray(e)) return `[${e.map((o,l)=>Ft(o,t,l.toString()))}]`;
    if (typeof e.toJSON == "function") return Ft(e.toJSON(n), t, n);
    if (e instanceof Map) {
        const o = {};
        for (const [l, s] of e) o[typeof l == "string" ? l : Ft(l, t)] = s;
        return Ft(o, t, n)
    }
    return e instanceof Set ? Ft(Array.from(e).sort((o, l) => Ft(o, t).localeCompare(Ft(l, t))), t, n) : Symbol !== void 0 && e[Symbol.iterator] != null && typeof e[Symbol.iterator] == "function" ? Ft(Array.from(e), t, n) : `{${Object.keys(e).filter(o=>e[o]!==void 0).sort().map(o=>`${Ft(o,t)}:${Ft(e[o],t,o)}`).join(",")}}`
}

function UN(e, t = {
    allowFunctions: !1
}) {
    return Ft(e, t)
}
var ei = UN;
const {
    TreeCache: FN
} = xg, gs = {
    equality: "reference",
    eviction: "keep-all",
    maxSize: 1 / 0
};

function VN({
    equality: e = gs.equality,
    eviction: t = gs.eviction,
    maxSize: n = gs.maxSize
} = gs, r) {
    const o = $N(e);
    return HN(t, n, o, r)
}

function $N(e) {
    switch (e) {
        case "reference":
            return t => t;
        case "value":
            return t => ei(t)
    }
    throw ie(`Unrecognized equality policy ${e}`)
}

function HN(e, t, n, r) {
    switch (e) {
        case "keep-all":
            return new FN({
                name: r,
                mapNodeValue: n
            });
        case "lru":
            return Rm({
                name: r,
                maxSize: Pe(t),
                mapNodeValue: n
            });
        case "most-recent":
            return Rm({
                name: r,
                maxSize: 1,
                mapNodeValue: n
            })
    }
    throw ie(`Unrecognized eviction policy ${e}`)
}
var BN = VN;

function zN(e) {
    return () => null
}
var WN = {
    startPerfBlock: zN
};
const {
    isLoadable: KN,
    loadableWithError: ys,
    loadableWithPromise: GN,
    loadableWithValue: cu
} = Tl, {
    WrappedValue: Rg
} = Eg, {
    getNodeLoadable: _s,
    peekNodeLoadable: qN,
    setNodeValue: YN
} = Jn, {
    saveDepsToStore: QN
} = Cl, {
    DEFAULT_VALUE: XN,
    getConfigDeletionHandler: JN,
    getNode: ZN,
    registerNode: km
} = gt, {
    isRecoilValue: eR
} = io, {
    markRecoilValueModified: Am
} = en, {
    retainedByOptionWithDefault: tR
} = Nr, {
    recoilCallback: nR
} = wg, {
    startPerfBlock: rR
} = WN;
class kg {}
const Po = new kg,
    Oo = [],
    Ss = new Map,
    oR = (() => {
        let e = 0;
        return () => e++
    })();

function Ag(e) {
    let t = null;
    const {
        key: n,
        get: r,
        cachePolicy_UNSTABLE: o
    } = e, l = e.set != null ? e.set : void 0, s = new Set, i = BN(o ? ? {
        equality: "reference",
        eviction: "keep-all"
    }, n), u = tR(e.retainedBy_UNSTABLE), c = new Map;
    let f = 0;

    function d() {
        return !xe("recoil_memory_managament_2020") || f > 0
    }

    function g(E) {
        return E.getState().knownSelectors.add(n), f++, () => {
            f--
        }
    }

    function S() {
        return JN(n) !== void 0 && !d()
    }

    function v(E, P, O, Q, $) {
        Re(P, Q, $), _(E, O)
    }

    function _(E, P) {
        Ne(E, P) && de(E), p(P, !0)
    }

    function R(E, P) {
        Ne(E, P) && (Pe(H(E)).stateVersions.clear(), p(P, !1))
    }

    function p(E, P) {
        const O = Ss.get(E);
        if (O != null) {
            for (const Q of O) Am(Q, Pe(t));
            P && Ss.delete(E)
        }
    }

    function m(E, P) {
        let O = Ss.get(P);
        O == null && Ss.set(P, O = new Set), O.add(E)
    }

    function h(E, P, O, Q, $, ne) {
        return P.then(te => {
            if (!d()) throw de(E), Po;
            const G = cu(te);
            return v(E, O, $, G, Q), te
        }).catch(te => {
            if (!d()) throw de(E), Po;
            if (Te(te)) return x(E, te, O, Q, $, ne);
            const G = ys(te);
            throw v(E, O, $, G, Q), te
        })
    }

    function x(E, P, O, Q, $, ne) {
        return P.then(te => {
            if (!d()) throw de(E), Po;
            ne.loadingDepKey != null && ne.loadingDepPromise === P ? O.atomValues.set(ne.loadingDepKey, cu(te)) : E.getState().knownSelectors.forEach(ce => {
                O.atomValues.delete(ce)
            });
            const G = L(E, O);
            if (G && G.state !== "loading") {
                if ((Ne(E, $) || H(E) == null) && _(E, $), G.state === "hasValue") return G.contents;
                throw G.contents
            }
            if (!Ne(E, $)) {
                const ce = oe(E, O);
                if (ce != null) return ce.loadingLoadable.contents
            }
            const [me, Se] = C(E, O, $);
            if (me.state !== "loading" && v(E, O, $, me, Se), me.state === "hasError") throw me.contents;
            return me.contents
        }).catch(te => {
            if (te instanceof kg) throw Po;
            if (!d()) throw de(E), Po;
            const G = ys(te);
            throw v(E, O, $, G, Q), te
        })
    }

    function k(E, P, O, Q) {
        var $, ne, te, G;
        if (Ne(E, Q) || P.version === (($ = E.getState()) === null || $ === void 0 || (ne = $.currentTree) === null || ne === void 0 ? void 0 : ne.version) || P.version === ((te = E.getState()) === null || te === void 0 || (G = te.nextTree) === null || G === void 0 ? void 0 : G.version)) {
            var me, Se, ce;
            QN(n, O, E, (me = (Se = E.getState()) === null || Se === void 0 || (ce = Se.nextTree) === null || ce === void 0 ? void 0 : ce.version) !== null && me !== void 0 ? me : E.getState().currentTree.version)
        }
        for (const he of O) s.add(he)
    }

    function C(E, P, O) {
        const Q = rR(n);
        let $ = !0,
            ne = !0;
        const te = () => {
            Q(), ne = !1
        };
        let G, me = !1,
            Se;
        const ce = {
                loadingDepKey: null,
                loadingDepPromise: null
            },
            he = new Map;

        function W({
            key: ye
        }) {
            const Ee = _s(E, P, ye);
            switch (he.set(ye, Ee), $ || (k(E, P, new Set(he.keys()), O), R(E, O)), Ee.state) {
                case "hasValue":
                    return Ee.contents;
                case "hasError":
                    throw Ee.contents;
                case "loading":
                    throw ce.loadingDepKey = ye, ce.loadingDepPromise = Ee.contents, Ee.contents
            }
            throw ie("Invalid Loadable state")
        }
        const ee = ye => (...Ee) => {
            if (ne) throw ie("Callbacks from getCallback() should only be called asynchronously after the selector is evalutated.  It can be used for selectors to return objects with callbacks that can work with Recoil state without a subscription.");
            return t == null && Bo(!1), nR(E, ye, Ee, {
                node: t
            })
        };
        try {
            G = r({
                get: W,
                getCallback: ee
            }), G = eR(G) ? W(G) : G, KN(G) && (G.state === "hasError" && (me = !0), G = G.contents), Te(G) ? G = h(E, G, P, he, O, ce).finally(te) : te(), G = G instanceof Rg ? G.value : G
        } catch (ye) {
            G = ye, Te(G) ? G = x(E, G, P, he, O, ce).finally(te) : (me = !0, te())
        }
        return me ? Se = ys(G) : Te(G) ? Se = GN(G) : Se = cu(G), $ = !1, Ue(E, O, he), k(E, P, new Set(he.keys()), O), [Se, he]
    }

    function L(E, P) {
        let O = P.atomValues.get(n);
        if (O != null) return O;
        const Q = new Set;
        try {
            O = i.get(ne => (typeof ne != "string" && Bo(!1), _s(E, P, ne).contents), {
                onNodeVisit: ne => {
                    ne.type === "branch" && ne.nodeKey !== n && Q.add(ne.nodeKey)
                }
            })
        } catch (ne) {
            throw ie(`Problem with cache lookup for selector "${n}": ${ne.message}`)
        }
        if (O) {
            var $;
            P.atomValues.set(n, O), k(E, P, Q, ($ = H(E)) === null || $ === void 0 ? void 0 : $.executionID)
        }
        return O
    }

    function M(E, P) {
        const O = L(E, P);
        if (O != null) return de(E), O;
        const Q = oe(E, P);
        if (Q != null) {
            var $;
            return (($ = Q.loadingLoadable) === null || $ === void 0 ? void 0 : $.state) === "loading" && m(E, Q.executionID), Q.loadingLoadable
        }
        const ne = oR(),
            [te, G] = C(E, P, ne);
        return te.state === "loading" ? (ge(E, ne, te, G, P), m(E, ne)) : (de(E), Re(P, te, G)), te
    }

    function oe(E, P) {
        const O = Yv([c.has(E) ? [Pe(c.get(E))] : [], $a(Dd(c, ([$]) => $ !== E), ([, $]) => $)]);

        function Q($) {
            for (const [ne, te] of $)
                if (!_s(E, P, ne).is(te)) return !0;
            return !1
        }
        for (const $ of O) {
            if ($.stateVersions.get(P.version) || !Q($.depValuesDiscoveredSoFarDuringAsyncWork)) return $.stateVersions.set(P.version, !0), $;
            $.stateVersions.set(P.version, !1)
        }
    }

    function H(E) {
        return c.get(E)
    }

    function ge(E, P, O, Q, $) {
        c.set(E, {
            depValuesDiscoveredSoFarDuringAsyncWork: Q,
            executionID: P,
            loadingLoadable: O,
            stateVersions: new Map([
                [$.version, !0]
            ])
        })
    }

    function Ue(E, P, O) {
        if (Ne(E, P)) {
            const Q = H(E);
            Q != null && (Q.depValuesDiscoveredSoFarDuringAsyncWork = O)
        }
    }

    function de(E) {
        c.delete(E)
    }

    function Ne(E, P) {
        var O;
        return P === ((O = H(E)) === null || O === void 0 ? void 0 : O.executionID)
    }

    function Xe(E) {
        return Array.from(E.entries()).map(([P, O]) => [P, O.contents])
    }

    function Re(E, P, O) {
        E.atomValues.set(n, P);
        try {
            i.set(Xe(O), P)
        } catch (Q) {
            throw ie(`Problem with setting cache for selector "${n}": ${Q.message}`)
        }
    }

    function Ve(E) {
        if (Oo.includes(n)) {
            const P = `Recoil selector has circular dependencies: ${Oo.slice(Oo.indexOf(n)).join(" → ")}`;
            return ys(ie(P))
        }
        Oo.push(n);
        try {
            return E()
        } finally {
            Oo.pop()
        }
    }

    function I(E, P) {
        const O = P.atomValues.get(n);
        return O ? ? i.get(Q => {
            var $;
            return typeof Q != "string" && Bo(!1), ($ = qN(E, P, Q)) === null || $ === void 0 ? void 0 : $.contents
        })
    }

    function Y(E, P) {
        return Ve(() => M(E, P))
    }

    function b(E) {
        E.atomValues.delete(n)
    }

    function q(E, P) {
        t == null && Bo(!1);
        for (const Q of s) {
            var O;
            const $ = ZN(Q);
            (O = $.clearCache) === null || O === void 0 || O.call($, E, P)
        }
        s.clear(), b(P), i.clear(), Am(E, t)
    }
    return l != null ? t = km({
        key: n,
        nodeType: "selector",
        peek: I,
        get: Y,
        set: (P, O, Q) => {
            let $ = !1;
            const ne = new Map;

            function te({
                key: ce
            }) {
                if ($) throw ie("Recoil: Async selector sets are not currently supported.");
                const he = _s(P, O, ce);
                if (he.state === "hasValue") return he.contents;
                if (he.state === "loading") {
                    const W = `Getting value of asynchronous atom or selector "${ce}" in a pending state while setting selector "${n}" is not yet supported.`;
                    throw ie(W)
                } else throw he.contents
            }

            function G(ce, he) {
                if ($) throw ie("Recoil: Async selector sets are not currently supported.");
                const W = typeof he == "function" ? he(te(ce)) : he;
                YN(P, O, ce.key, W).forEach((ye, Ee) => ne.set(Ee, ye))
            }

            function me(ce) {
                G(ce, XN)
            }
            const Se = l({
                set: G,
                get: te,
                reset: me
            }, Q);
            if (Se !== void 0) throw Te(Se) ? ie("Recoil: Async selector sets are not currently supported.") : ie("Recoil: selector set should be a void function.");
            return $ = !0, ne
        },
        init: g,
        invalidate: b,
        clearCache: q,
        shouldDeleteConfigOnRelease: S,
        dangerouslyAllowMutability: e.dangerouslyAllowMutability,
        shouldRestoreFromSnapshots: !1,
        retainedBy: u
    }) : t = km({
        key: n,
        nodeType: "selector",
        peek: I,
        get: Y,
        init: g,
        invalidate: b,
        clearCache: q,
        shouldDeleteConfigOnRelease: S,
        dangerouslyAllowMutability: e.dangerouslyAllowMutability,
        shouldRestoreFromSnapshots: !1,
        retainedBy: u
    })
}
Ag.value = e => new Rg(e);
var fo = Ag;
const {
    isLoadable: lR,
    loadableWithError: du,
    loadableWithPromise: fu,
    loadableWithValue: Pr
} = Tl, {
    WrappedValue: Tg
} = Eg, {
    peekNodeInfo: sR
} = Jn, {
    DEFAULT_VALUE: sr,
    DefaultValue: Ln,
    getConfigDeletionHandler: jg,
    registerNode: aR,
    setConfigDeletionHandler: iR
} = gt, {
    isRecoilValue: uR
} = io, {
    getRecoilValueAsLoadable: cR,
    markRecoilValueModified: dR,
    setRecoilValue: Tm,
    setRecoilValueLoadable: fR
} = en, {
    retainedByOptionWithDefault: mR
} = Nr, bo = e => e instanceof Tg ? e.value : e;

function pR(e) {
    const {
        key: t,
        persistence_UNSTABLE: n
    } = e, r = mR(e.retainedBy_UNSTABLE);
    let o = 0;

    function l(m) {
        return fu(m.then(h => (s = Pr(h), h)).catch(h => {
            throw s = du(h), h
        }))
    }
    let s = Te(e.default) ? l(e.default) : lR(e.default) ? e.default.state === "loading" ? l(e.default.contents) : e.default : Pr(bo(e.default));
    s.contents;
    let i;
    const u = new Map;

    function c(m) {
        return m
    }

    function f(m, h) {
        const x = h.then(k => {
            var C, L;
            return ((L = ((C = m.getState().nextTree) !== null && C !== void 0 ? C : m.getState().currentTree).atomValues.get(t)) === null || L === void 0 ? void 0 : L.contents) === x && Tm(m, p, k), k
        }).catch(k => {
            var C, L;
            throw ((L = ((C = m.getState().nextTree) !== null && C !== void 0 ? C : m.getState().currentTree).atomValues.get(t)) === null || L === void 0 ? void 0 : L.contents) === x && fR(m, p, du(k)), k
        });
        return x
    }

    function d(m, h, x) {
        var k;
        o++;
        const C = () => {
            var H;
            o--, (H = u.get(m)) === null || H === void 0 || H.forEach(ge => ge()), u.delete(m)
        };
        if (m.getState().knownAtoms.add(t), s.state === "loading") {
            const H = () => {
                var ge;
                ((ge = m.getState().nextTree) !== null && ge !== void 0 ? ge : m.getState().currentTree).atomValues.has(t) || dR(m, p)
            };
            s.contents.finally(H)
        }
        const L = (k = e.effects) !== null && k !== void 0 ? k : e.effects_UNSTABLE;
        if (L != null) {
            let H = function(b) {
                    if (Ne && b.key === t) {
                        const q = de;
                        return q instanceof Ln ? g(m, h) : Te(q) ? fu(q.then(E => E instanceof Ln ? s.toPromise() : E)) : Pr(q)
                    }
                    return cR(m, b)
                },
                ge = function(b) {
                    return H(b).toPromise()
                },
                Ue = function(b) {
                    var q;
                    const E = sR(m, (q = m.getState().nextTree) !== null && q !== void 0 ? q : m.getState().currentTree, b.key);
                    return Ne && b.key === t && !(de instanceof Ln) ? { ...E,
                        isSet: !0,
                        loadable: H(b)
                    } : E
                },
                de = sr,
                Ne = !0,
                Xe = !1,
                Re = null;
            const Ve = b => q => {
                    if (Ne) {
                        const E = H(p),
                            P = E.state === "hasValue" ? E.contents : sr;
                        de = typeof q == "function" ? q(P) : q, Te(de) && (de = de.then(O => (Re = {
                            effect: b,
                            value: O
                        }, O)))
                    } else {
                        if (Te(q)) throw ie("Setting atoms to async values is not implemented.");
                        typeof q != "function" && (Re = {
                            effect: b,
                            value: bo(q)
                        }), Tm(m, p, typeof q == "function" ? E => {
                            const P = bo(q(E));
                            return Re = {
                                effect: b,
                                value: P
                            }, P
                        } : bo(q))
                    }
                },
                I = b => () => Ve(b)(sr),
                Y = b => q => {
                    var E;
                    const {
                        release: P
                    } = m.subscribeToTransactions(O => {
                        var Q;
                        let {
                            currentTree: $,
                            previousTree: ne
                        } = O.getState();
                        ne || (ne = $);
                        const te = (Q = $.atomValues.get(t)) !== null && Q !== void 0 ? Q : s;
                        if (te.state === "hasValue") {
                            var G, me, Se, ce;
                            const he = te.contents,
                                W = (G = ne.atomValues.get(t)) !== null && G !== void 0 ? G : s,
                                ee = W.state === "hasValue" ? W.contents : sr;
                            ((me = Re) === null || me === void 0 ? void 0 : me.effect) !== b || ((Se = Re) === null || Se === void 0 ? void 0 : Se.value) !== he ? q(he, ee, !$.atomValues.has(t)) : ((ce = Re) === null || ce === void 0 ? void 0 : ce.effect) === b && (Re = null)
                        }
                    }, t);
                    u.set(m, [...(E = u.get(m)) !== null && E !== void 0 ? E : [], P])
                };
            for (const b of L) try {
                const q = b({
                    node: p,
                    storeID: m.storeID,
                    parentStoreID_UNSTABLE: m.parentStoreID,
                    trigger: x,
                    setSelf: Ve(b),
                    resetSelf: I(b),
                    onSet: Y(b),
                    getPromise: ge,
                    getLoadable: H,
                    getInfo_UNSTABLE: Ue
                });
                if (q != null) {
                    var M;
                    u.set(m, [...(M = u.get(m)) !== null && M !== void 0 ? M : [], q])
                }
            } catch (q) {
                de = q, Xe = !0
            }
            if (Ne = !1, !(de instanceof Ln)) {
                var oe;
                const b = Xe ? du(de) : Te(de) ? fu(f(m, de)) : Pr(bo(de));
                b.contents, h.atomValues.set(t, b), (oe = m.getState().nextTree) === null || oe === void 0 || oe.atomValues.set(t, b)
            }
        }
        return C
    }

    function g(m, h) {
        var x, k;
        return (x = (k = h.atomValues.get(t)) !== null && k !== void 0 ? k : i) !== null && x !== void 0 ? x : s
    }

    function S(m, h) {
        if (h.atomValues.has(t)) return Pe(h.atomValues.get(t));
        if (h.nonvalidatedAtoms.has(t)) {
            if (i != null) return i;
            if (n == null) return s;
            const x = h.nonvalidatedAtoms.get(t),
                k = n.validator(x, sr);
            return i = k instanceof Ln ? s : Pr(k), i
        } else return s
    }

    function v() {
        i = void 0
    }

    function _(m, h, x) {
        if (h.atomValues.has(t)) {
            const k = Pe(h.atomValues.get(t));
            if (k.state === "hasValue" && x === k.contents) return new Map
        } else if (!h.nonvalidatedAtoms.has(t) && x instanceof Ln) return new Map;
        return i = void 0, new Map().set(t, Pr(x))
    }

    function R() {
        return jg(t) !== void 0 && o <= 0
    }
    const p = aR({
        key: t,
        nodeType: "atom",
        peek: g,
        get: S,
        set: _,
        init: d,
        invalidate: v,
        shouldDeleteConfigOnRelease: R,
        dangerouslyAllowMutability: e.dangerouslyAllowMutability,
        persistence_UNSTABLE: e.persistence_UNSTABLE ? {
            type: e.persistence_UNSTABLE.type,
            backButton: e.persistence_UNSTABLE.backButton
        } : void 0,
        shouldRestoreFromSnapshots: !0,
        retainedBy: r
    });
    return p
}

function Hd(e) {
    const { ...t
    } = e, n = "default" in e ? e.default : new Promise(() => {});
    return uR(n) ? hR({ ...t,
        default: n
    }) : pR({ ...t,
        default: n
    })
}

function hR(e) {
    const t = Hd({ ...e,
            default: sr,
            persistence_UNSTABLE: e.persistence_UNSTABLE === void 0 ? void 0 : { ...e.persistence_UNSTABLE,
                validator: r => r instanceof Ln ? r : Pe(e.persistence_UNSTABLE).validator(r, sr)
            },
            effects: e.effects,
            effects_UNSTABLE: e.effects_UNSTABLE
        }),
        n = fo({
            key: `${e.key}__withFallback`,
            get: ({
                get: r
            }) => {
                const o = r(t);
                return o instanceof Ln ? e.default : o
            },
            set: ({
                set: r
            }, o) => r(t, o),
            cachePolicy_UNSTABLE: {
                eviction: "most-recent"
            },
            dangerouslyAllowMutability: e.dangerouslyAllowMutability
        });
    return iR(n.key, jg(e.key)), n
}
Hd.value = e => new Tg(e);
var Cg = Hd;
class vR {
    constructor(t) {
        var n;
        se(this, "_map", void 0), se(this, "_keyMapper", void 0), this._map = new Map, this._keyMapper = (n = t == null ? void 0 : t.mapKey) !== null && n !== void 0 ? n : r => r
    }
    size() {
        return this._map.size
    }
    has(t) {
        return this._map.has(this._keyMapper(t))
    }
    get(t) {
        return this._map.get(this._keyMapper(t))
    }
    set(t, n) {
        this._map.set(this._keyMapper(t), n)
    }
    delete(t) {
        this._map.delete(this._keyMapper(t))
    }
    clear() {
        this._map.clear()
    }
}
var gR = {
        MapCache: vR
    },
    yR = gR.MapCache,
    _R = Object.freeze({
        __proto__: null,
        MapCache: yR
    });
const {
    LRUCache: jm
} = Ng, {
    MapCache: SR
} = _R, ws = {
    equality: "reference",
    eviction: "none",
    maxSize: 1 / 0
};

function wR({
    equality: e = ws.equality,
    eviction: t = ws.eviction,
    maxSize: n = ws.maxSize
} = ws) {
    const r = ER(e);
    return xR(t, n, r)
}

function ER(e) {
    switch (e) {
        case "reference":
            return t => t;
        case "value":
            return t => ei(t)
    }
    throw ie(`Unrecognized equality policy ${e}`)
}

function xR(e, t, n) {
    switch (e) {
        case "keep-all":
            return new SR({
                mapKey: n
            });
        case "lru":
            return new jm({
                mapKey: n,
                maxSize: Pe(t)
            });
        case "most-recent":
            return new jm({
                mapKey: n,
                maxSize: 1
            })
    }
    throw ie(`Unrecognized eviction policy ${e}`)
}
var Lg = wR;
const {
    setConfigDeletionHandler: NR
} = gt;

function RR(e) {
    var t, n;
    const r = Lg({
        equality: (t = (n = e.cachePolicyForParams_UNSTABLE) === null || n === void 0 ? void 0 : n.equality) !== null && t !== void 0 ? t : "value",
        eviction: "keep-all"
    });
    return o => {
        var l, s;
        const i = r.get(o);
        if (i != null) return i;
        const {
            cachePolicyForParams_UNSTABLE: u,
            ...c
        } = e, f = "default" in e ? e.default : new Promise(() => {}), d = Cg({ ...c,
            key: `${e.key}__${(l=ei(o))!==null&&l!==void 0?l:"void"}`,
            default: typeof f == "function" ? f(o) : f,
            retainedBy_UNSTABLE: typeof e.retainedBy_UNSTABLE == "function" ? e.retainedBy_UNSTABLE(o) : e.retainedBy_UNSTABLE,
            effects: typeof e.effects == "function" ? e.effects(o) : typeof e.effects_UNSTABLE == "function" ? e.effects_UNSTABLE(o) : (s = e.effects) !== null && s !== void 0 ? s : e.effects_UNSTABLE
        });
        return r.set(o, d), NR(d.key, () => {
            r.delete(o)
        }), d
    }
}
var kR = RR;
const {
    setConfigDeletionHandler: AR
} = gt;
let TR = 0;

function jR(e) {
    var t, n;
    const r = Lg({
        equality: (t = (n = e.cachePolicyForParams_UNSTABLE) === null || n === void 0 ? void 0 : n.equality) !== null && t !== void 0 ? t : "value",
        eviction: "keep-all"
    });
    return o => {
        var l;
        let s;
        try {
            s = r.get(o)
        } catch (g) {
            throw ie(`Problem with cache lookup for selector ${e.key}: ${g.message}`)
        }
        if (s != null) return s;
        const i = `${e.key}__selectorFamily/${(l=ei(o,{allowFunctions:!0}))!==null&&l!==void 0?l:"void"}/${TR++}`,
            u = g => e.get(o)(g),
            c = e.cachePolicy_UNSTABLE,
            f = typeof e.retainedBy_UNSTABLE == "function" ? e.retainedBy_UNSTABLE(o) : e.retainedBy_UNSTABLE;
        let d;
        if (e.set != null) {
            const g = e.set;
            d = fo({
                key: i,
                get: u,
                set: (v, _) => g(o)(v, _),
                cachePolicy_UNSTABLE: c,
                dangerouslyAllowMutability: e.dangerouslyAllowMutability,
                retainedBy_UNSTABLE: f
            })
        } else d = fo({
            key: i,
            get: u,
            cachePolicy_UNSTABLE: c,
            dangerouslyAllowMutability: e.dangerouslyAllowMutability,
            retainedBy_UNSTABLE: f
        });
        return r.set(o, d), AR(d.key, () => {
            r.delete(o)
        }), d
    }
}
var Zn = jR;
const CR = Zn({
    key: "__constant",
    get: e => () => e,
    cachePolicyForParams_UNSTABLE: {
        equality: "reference"
    }
});

function LR(e) {
    return CR(e)
}
var DR = LR;
const PR = Zn({
    key: "__error",
    get: e => () => {
        throw ie(e)
    },
    cachePolicyForParams_UNSTABLE: {
        equality: "reference"
    }
});

function OR(e) {
    return PR(e)
}
var bR = OR;

function IR(e) {
    return e
}
var MR = IR;
const {
    loadableWithError: Dg,
    loadableWithPromise: Pg,
    loadableWithValue: Og
} = Tl;

function ti(e, t) {
    const n = Array(t.length).fill(void 0),
        r = Array(t.length).fill(void 0);
    for (const [o, l] of t.entries()) try {
        n[o] = e(l)
    } catch (s) {
        r[o] = s
    }
    return [n, r]
}

function UR(e) {
    return e != null && !Te(e)
}

function ni(e) {
    return Array.isArray(e) ? e : Object.getOwnPropertyNames(e).map(t => e[t])
}

function Ec(e, t) {
    return Array.isArray(e) ? t : Object.getOwnPropertyNames(e).reduce((n, r, o) => ({ ...n,
        [r]: t[o]
    }), {})
}

function Zr(e, t, n) {
    const r = n.map((o, l) => o == null ? Og(t[l]) : Te(o) ? Pg(o) : Dg(o));
    return Ec(e, r)
}

function FR(e, t) {
    return t.map((n, r) => n === void 0 ? e[r] : n)
}
const VR = Zn({
        key: "__waitForNone",
        get: e => ({
            get: t
        }) => {
            const n = ni(e),
                [r, o] = ti(t, n);
            return Zr(e, r, o)
        },
        dangerouslyAllowMutability: !0
    }),
    $R = Zn({
        key: "__waitForAny",
        get: e => ({
            get: t
        }) => {
            const n = ni(e),
                [r, o] = ti(t, n);
            return o.some(l => !Te(l)) ? Zr(e, r, o) : new Promise(l => {
                for (const [s, i] of o.entries()) Te(i) && i.then(u => {
                    r[s] = u, o[s] = void 0, l(Zr(e, r, o))
                }).catch(u => {
                    o[s] = u, l(Zr(e, r, o))
                })
            })
        },
        dangerouslyAllowMutability: !0
    }),
    HR = Zn({
        key: "__waitForAll",
        get: e => ({
            get: t
        }) => {
            const n = ni(e),
                [r, o] = ti(t, n);
            if (o.every(s => s == null)) return Ec(e, r);
            const l = o.find(UR);
            if (l != null) throw l;
            return Promise.all(o).then(s => Ec(e, FR(r, s)))
        },
        dangerouslyAllowMutability: !0
    }),
    BR = Zn({
        key: "__waitForAllSettled",
        get: e => ({
            get: t
        }) => {
            const n = ni(e),
                [r, o] = ti(t, n);
            return o.every(l => !Te(l)) ? Zr(e, r, o) : Promise.all(o.map((l, s) => Te(l) ? l.then(i => {
                r[s] = i, o[s] = void 0
            }).catch(i => {
                r[s] = void 0, o[s] = i
            }) : null)).then(() => Zr(e, r, o))
        },
        dangerouslyAllowMutability: !0
    }),
    zR = Zn({
        key: "__noWait",
        get: e => ({
            get: t
        }) => {
            try {
                return fo.value(Og(t(e)))
            } catch (n) {
                return fo.value(Te(n) ? Pg(n) : Dg(n))
            }
        },
        dangerouslyAllowMutability: !0
    });
var WR = {
    waitForNone: VR,
    waitForAny: $R,
    waitForAll: HR,
    waitForAllSettled: BR,
    noWait: zR
};
const {
    RecoilLoadable: KR
} = Tl, {
    DefaultValue: GR
} = gt, {
    RecoilRoot: qR,
    useRecoilStoreID: YR
} = yn, {
    isRecoilValue: QR
} = io, {
    retentionZone: XR
} = Ba, {
    freshSnapshot: JR
} = Ya, {
    useRecoilState: ZR,
    useRecoilState_TRANSITION_SUPPORT_UNSTABLE: ek,
    useRecoilStateLoadable: tk,
    useRecoilValue: nk,
    useRecoilValue_TRANSITION_SUPPORT_UNSTABLE: rk,
    useRecoilValueLoadable: ok,
    useRecoilValueLoadable_TRANSITION_SUPPORT_UNSTABLE: lk,
    useResetRecoilState: sk,
    useSetRecoilState: ak
} = gx, {
    useGotoRecoilSnapshot: ik,
    useRecoilSnapshot: uk,
    useRecoilTransactionObserver: ck
} = gg, {
    useRecoilCallback: dk
} = wg, {
    noWait: fk,
    waitForAll: mk,
    waitForAllSettled: pk,
    waitForAny: hk,
    waitForNone: vk
} = WR;
var Ol = {
        DefaultValue: GR,
        isRecoilValue: QR,
        RecoilLoadable: KR,
        RecoilEnv: go,
        RecoilRoot: qR,
        useRecoilStoreID: YR,
        useRecoilBridgeAcrossReactRoots_UNSTABLE: zx,
        atom: Cg,
        selector: fo,
        atomFamily: kR,
        selectorFamily: Zn,
        constSelector: DR,
        errorSelector: bR,
        readOnlySelector: MR,
        noWait: fk,
        waitForNone: vk,
        waitForAny: hk,
        waitForAll: mk,
        waitForAllSettled: pk,
        useRecoilValue: nk,
        useRecoilValueLoadable: ok,
        useRecoilState: ZR,
        useRecoilStateLoadable: tk,
        useSetRecoilState: ak,
        useResetRecoilState: sk,
        useGetRecoilValueInfo_UNSTABLE: Ux,
        useRecoilRefresher_UNSTABLE: _N,
        useRecoilValueLoadable_TRANSITION_SUPPORT_UNSTABLE: lk,
        useRecoilValue_TRANSITION_SUPPORT_UNSTABLE: rk,
        useRecoilState_TRANSITION_SUPPORT_UNSTABLE: ek,
        useRecoilCallback: dk,
        useRecoilTransaction_UNSTABLE: NN,
        useGotoRecoilSnapshot: ik,
        useRecoilSnapshot: uk,
        useRecoilTransactionObserver_UNSTABLE: ck,
        snapshot_UNSTABLE: JR,
        useRetain: Md,
        retentionZone: XR
    },
    gk = Ol.RecoilRoot,
    bg = Ol.atom,
    Cm = Ol.useRecoilValue,
    _a = Ol.useRecoilState,
    Lm = Ol.useSetRecoilState,
    Bd = {};
Object.defineProperty(Bd, "__esModule", {
    value: !0
});
var Ig = Bd.recoilPersist = void 0;
const yk = (e = {}) => {
    if (typeof window > "u") return {
        persistAtom: () => {}
    };
    const {
        key: t = "recoil-persist",
        storage: n = localStorage,
        converter: r = JSON
    } = e, o = ({
        onSet: c,
        node: f,
        trigger: d,
        setSelf: g
    }) => {
        if (d === "get") {
            const S = s();
            typeof S.then == "function" && S.then(v => {
                v.hasOwnProperty(f.key) && g(v[f.key])
            }), S.hasOwnProperty(f.key) && g(S[f.key])
        }
        c(async (S, v, _) => {
            const R = s();
            typeof R.then == "function" ? R.then(p => l(S, p, f.key, _)) : l(S, R, f.key, _)
        })
    }, l = (c, f, d, g) => {
        g ? delete f[d] : f[d] = c, u(f)
    }, s = () => {
        const c = n.getItem(t);
        return c == null ? {} : typeof c == "string" ? i(c) : typeof c.then == "function" ? c.then(i) : {}
    }, i = c => {
        if (c === void 0) return {};
        try {
            return r.parse(c)
        } catch (f) {
            return console.error(f), {}
        }
    }, u = c => {
        try {
            typeof n.mergeItem == "function" ? n.mergeItem(t, r.stringify(c)) : n.setItem(t, r.stringify(c))
        } catch (f) {
            console.error(f)
        }
    };
    return {
        persistAtom: o
    }
};
Ig = Bd.recoilPersist = yk;
const xc = "GUEST",
    _k = "USER",
    Sk = "ADMIN",
    {
        persistAtom: Mg
    } = Ig(),
    wk = "LOGIN_STATE",
    Ek = "MEMBER_STATE",
    ri = bg({
        key: wk,
        default: !1,
        effects_UNSTABLE: [Mg]
    }),
    oi = bg({
        key: Ek,
        default: _k,
        effects_UNSTABLE: [Mg]
    });
/**
 * @remix-run/router v1.15.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function _l() {
    return _l = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, _l.apply(this, arguments)
}
var In;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(In || (In = {}));
const Dm = "popstate";

function xk(e) {
    e === void 0 && (e = {});

    function t(r, o) {
        let {
            pathname: l,
            search: s,
            hash: i
        } = r.location;
        return Nc("", {
            pathname: l,
            search: s,
            hash: i
        }, o.state && o.state.usr || null, o.state && o.state.key || "default")
    }

    function n(r, o) {
        return typeof o == "string" ? o : Ug(o)
    }
    return Rk(t, n, null, e)
}

function We(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function zd(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function Nk() {
    return Math.random().toString(36).substr(2, 8)
}

function Pm(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function Nc(e, t, n, r) {
    return n === void 0 && (n = null), _l({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? _o(t) : t, {
        state: n,
        key: t && t.key || r || Nk()
    })
}

function Ug(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function _o(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function Rk(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: o = document.defaultView,
        v5Compat: l = !1
    } = r, s = o.history, i = In.Pop, u = null, c = f();
    c == null && (c = 0, s.replaceState(_l({}, s.state, {
        idx: c
    }), ""));

    function f() {
        return (s.state || {
            idx: null
        }).idx
    }

    function d() {
        i = In.Pop;
        let R = f(),
            p = R == null ? null : R - c;
        c = R, u && u({
            action: i,
            location: _.location,
            delta: p
        })
    }

    function g(R, p) {
        i = In.Push;
        let m = Nc(_.location, R, p);
        c = f() + 1;
        let h = Pm(m, c),
            x = _.createHref(m);
        try {
            s.pushState(h, "", x)
        } catch (k) {
            if (k instanceof DOMException && k.name === "DataCloneError") throw k;
            o.location.assign(x)
        }
        l && u && u({
            action: i,
            location: _.location,
            delta: 1
        })
    }

    function S(R, p) {
        i = In.Replace;
        let m = Nc(_.location, R, p);
        c = f();
        let h = Pm(m, c),
            x = _.createHref(m);
        s.replaceState(h, "", x), l && u && u({
            action: i,
            location: _.location,
            delta: 0
        })
    }

    function v(R) {
        let p = o.location.origin !== "null" ? o.location.origin : o.location.href,
            m = typeof R == "string" ? R : Ug(R);
        return We(p, "No window.location.(origin|href) available to create URL for href: " + m), new URL(m, p)
    }
    let _ = {
        get action() {
            return i
        },
        get location() {
            return e(o, s)
        },
        listen(R) {
            if (u) throw new Error("A history only accepts one active listener");
            return o.addEventListener(Dm, d), u = R, () => {
                o.removeEventListener(Dm, d), u = null
            }
        },
        createHref(R) {
            return t(o, R)
        },
        createURL: v,
        encodeLocation(R) {
            let p = v(R);
            return {
                pathname: p.pathname,
                search: p.search,
                hash: p.hash
            }
        },
        push: g,
        replace: S,
        go(R) {
            return s.go(R)
        }
    };
    return _
}
var Om;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(Om || (Om = {}));

function kk(e, t, n) {
    n === void 0 && (n = "/");
    let r = typeof t == "string" ? _o(t) : t,
        o = $g(r.pathname || "/", n);
    if (o == null) return null;
    let l = Fg(e);
    Ak(l);
    let s = null;
    for (let i = 0; s == null && i < l.length; ++i) s = Ik(l[i], Fk(o));
    return s
}

function Fg(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let o = (l, s, i) => {
        let u = {
            relativePath: i === void 0 ? l.path || "" : i,
            caseSensitive: l.caseSensitive === !0,
            childrenIndex: s,
            route: l
        };
        u.relativePath.startsWith("/") && (We(u.relativePath.startsWith(r), 'Absolute route path "' + u.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), u.relativePath = u.relativePath.slice(r.length));
        let c = fr([r, u.relativePath]),
            f = n.concat(u);
        l.children && l.children.length > 0 && (We(l.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + c + '".')), Fg(l.children, t, f, c)), !(l.path == null && !l.index) && t.push({
            path: c,
            score: Ok(c, l.index),
            routesMeta: f
        })
    };
    return e.forEach((l, s) => {
        var i;
        if (l.path === "" || !((i = l.path) != null && i.includes("?"))) o(l, s);
        else
            for (let u of Vg(l.path)) o(l, s, u)
    }), t
}

function Vg(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, o = n.endsWith("?"), l = n.replace(/\?$/, "");
    if (r.length === 0) return o ? [l, ""] : [l];
    let s = Vg(r.join("/")),
        i = [];
    return i.push(...s.map(u => u === "" ? l : [l, u].join("/"))), o && i.push(...s), i.map(u => e.startsWith("/") && u === "" ? "/" : u)
}

function Ak(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : bk(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const Tk = /^:[\w-]+$/,
    jk = 3,
    Ck = 2,
    Lk = 1,
    Dk = 10,
    Pk = -2,
    bm = e => e === "*";

function Ok(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(bm) && (r += Pk), t && (r += Ck), n.filter(o => !bm(o)).reduce((o, l) => o + (Tk.test(l) ? jk : l === "" ? Lk : Dk), r)
}

function bk(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, o) => r === t[o]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function Ik(e, t) {
    let {
        routesMeta: n
    } = e, r = {}, o = "/", l = [];
    for (let s = 0; s < n.length; ++s) {
        let i = n[s],
            u = s === n.length - 1,
            c = o === "/" ? t : t.slice(o.length) || "/",
            f = Mk({
                path: i.relativePath,
                caseSensitive: i.caseSensitive,
                end: u
            }, c);
        if (!f) return null;
        Object.assign(r, f.params);
        let d = i.route;
        l.push({
            params: r,
            pathname: fr([o, f.pathname]),
            pathnameBase: zk(fr([o, f.pathnameBase])),
            route: d
        }), f.pathnameBase !== "/" && (o = fr([o, f.pathnameBase]))
    }
    return l
}

function Mk(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = Uk(e.path, e.caseSensitive, e.end), o = t.match(n);
    if (!o) return null;
    let l = o[0],
        s = l.replace(/(.)\/+$/, "$1"),
        i = o.slice(1);
    return {
        params: r.reduce((c, f, d) => {
            let {
                paramName: g,
                isOptional: S
            } = f;
            if (g === "*") {
                let _ = i[d] || "";
                s = l.slice(0, l.length - _.length).replace(/(.)\/+$/, "$1")
            }
            const v = i[d];
            return S && !v ? c[g] = void 0 : c[g] = Vk(v || "", g), c
        }, {}),
        pathname: l,
        pathnameBase: s,
        pattern: e
    }
}

function Uk(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), zd(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        o = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (s, i, u) => (r.push({
            paramName: i,
            isOptional: u != null
        }), u ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
        paramName: "*"
    }), o += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? o += "\\/*$" : e !== "" && e !== "/" && (o += "(?:(?=\\/|$))"), [new RegExp(o, t ? void 0 : "i"), r]
}

function Fk(e) {
    try {
        return decodeURI(e)
    } catch (t) {
        return zd(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function Vk(e, t) {
    try {
        return decodeURIComponent(e)
    } catch (n) {
        return zd(!1, 'The value for the URL param "' + t + '" will not be decoded because' + (' the string "' + e + '" is a malformed URL segment. This is probably') + (" due to a bad percent encoding (" + n + ").")), e
    }
}

function $g(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}

function $k(e, t) {
    t === void 0 && (t = "/");
    let {
        pathname: n,
        search: r = "",
        hash: o = ""
    } = typeof e == "string" ? _o(e) : e;
    return {
        pathname: n ? n.startsWith("/") ? n : Hk(n, t) : t,
        search: Wk(r),
        hash: Kk(o)
    }
}

function Hk(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach(o => {
        o === ".." ? n.length > 1 && n.pop() : o !== "." && n.push(o)
    }), n.length > 1 ? n.join("/") : "/"
}

function mu(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.'
}

function Bk(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0)
}

function Hg(e, t) {
    let n = Bk(e);
    return t ? n.map((r, o) => o === e.length - 1 ? r.pathname : r.pathnameBase) : n.map(r => r.pathnameBase)
}

function Bg(e, t, n, r) {
    r === void 0 && (r = !1);
    let o;
    typeof e == "string" ? o = _o(e) : (o = _l({}, e), We(!o.pathname || !o.pathname.includes("?"), mu("?", "pathname", "search", o)), We(!o.pathname || !o.pathname.includes("#"), mu("#", "pathname", "hash", o)), We(!o.search || !o.search.includes("#"), mu("#", "search", "hash", o)));
    let l = e === "" || o.pathname === "",
        s = l ? "/" : o.pathname,
        i;
    if (s == null) i = n;
    else {
        let d = t.length - 1;
        if (!r && s.startsWith("..")) {
            let g = s.split("/");
            for (; g[0] === "..";) g.shift(), d -= 1;
            o.pathname = g.join("/")
        }
        i = d >= 0 ? t[d] : "/"
    }
    let u = $k(o, i),
        c = s && s !== "/" && s.endsWith("/"),
        f = (l || s === ".") && n.endsWith("/");
    return !u.pathname.endsWith("/") && (c || f) && (u.pathname += "/"), u
}
const fr = e => e.join("/").replace(/\/\/+/g, "/"),
    zk = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
    Wk = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
    Kk = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;

function Gk(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const zg = ["post", "put", "patch", "delete"];
new Set(zg);
const qk = ["get", ...zg];
new Set(qk);
/**
 * React Router v6.22.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function Sl() {
    return Sl = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Sl.apply(this, arguments)
}
const Wd = y.createContext(null),
    Yk = y.createContext(null),
    bl = y.createContext(null),
    li = y.createContext(null),
    _n = y.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    Wg = y.createContext(null);

function Il() {
    return y.useContext(li) != null
}

function Kd() {
    return Il() || We(!1), y.useContext(li).location
}

function Kg(e) {
    y.useContext(bl).static || y.useLayoutEffect(e)
}

function si() {
    let {
        isDataRoute: e
    } = y.useContext(_n);
    return e ? dA() : Qk()
}

function Qk() {
    Il() || We(!1);
    let e = y.useContext(Wd),
        {
            basename: t,
            future: n,
            navigator: r
        } = y.useContext(bl),
        {
            matches: o
        } = y.useContext(_n),
        {
            pathname: l
        } = Kd(),
        s = JSON.stringify(Hg(o, n.v7_relativeSplatPath)),
        i = y.useRef(!1);
    return Kg(() => {
        i.current = !0
    }), y.useCallback(function(c, f) {
        if (f === void 0 && (f = {}), !i.current) return;
        if (typeof c == "number") {
            r.go(c);
            return
        }
        let d = Bg(c, JSON.parse(s), l, f.relative === "path");
        e == null && t !== "/" && (d.pathname = d.pathname === "/" ? t : fr([t, d.pathname])), (f.replace ? r.replace : r.push)(d, f.state, f)
    }, [t, r, s, l, e])
}
const Xk = y.createContext(null);

function Jk(e) {
    let t = y.useContext(_n).outlet;
    return t && y.createElement(Xk.Provider, {
        value: e
    }, t)
}

function Zk() {
    let {
        matches: e
    } = y.useContext(_n), t = e[e.length - 1];
    return t ? t.params : {}
}

function eA(e, t) {
    return tA(e, t)
}

function tA(e, t, n, r) {
    Il() || We(!1);
    let {
        navigator: o
    } = y.useContext(bl), {
        matches: l
    } = y.useContext(_n), s = l[l.length - 1], i = s ? s.params : {};
    s && s.pathname;
    let u = s ? s.pathnameBase : "/";
    s && s.route;
    let c = Kd(),
        f;
    if (t) {
        var d;
        let R = typeof t == "string" ? _o(t) : t;
        u === "/" || (d = R.pathname) != null && d.startsWith(u) || We(!1), f = R
    } else f = c;
    let g = f.pathname || "/",
        S = u === "/" ? g : g.slice(u.length) || "/",
        v = kk(e, {
            pathname: S
        }),
        _ = sA(v && v.map(R => Object.assign({}, R, {
            params: Object.assign({}, i, R.params),
            pathname: fr([u, o.encodeLocation ? o.encodeLocation(R.pathname).pathname : R.pathname]),
            pathnameBase: R.pathnameBase === "/" ? u : fr([u, o.encodeLocation ? o.encodeLocation(R.pathnameBase).pathname : R.pathnameBase])
        })), l, n, r);
    return t && _ ? y.createElement(li.Provider, {
        value: {
            location: Sl({
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default"
            }, f),
            navigationType: In.Pop
        }
    }, _) : _
}

function nA() {
    let e = cA(),
        t = Gk(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        o = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        };
    return y.createElement(y.Fragment, null, y.createElement("h2", null, "Unexpected Application Error!"), y.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? y.createElement("pre", {
        style: o
    }, n) : null, null)
}
const rA = y.createElement(nA, null);
class oA extends y.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error !== void 0 ? t.error : n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error !== void 0 ? y.createElement(_n.Provider, {
            value: this.props.routeContext
        }, y.createElement(Wg.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function lA(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, o = y.useContext(Wd);
    return o && o.static && o.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (o.staticContext._deepestRenderedBoundaryId = n.route.id), y.createElement(_n.Provider, {
        value: t
    }, r)
}

function sA(e, t, n, r) {
    var o;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
        var l;
        if ((l = n) != null && l.errors) e = n.matches;
        else return null
    }
    let s = e,
        i = (o = n) == null ? void 0 : o.errors;
    if (i != null) {
        let f = s.findIndex(d => d.route.id && (i == null ? void 0 : i[d.route.id]));
        f >= 0 || We(!1), s = s.slice(0, Math.min(s.length, f + 1))
    }
    let u = !1,
        c = -1;
    if (n && r && r.v7_partialHydration)
        for (let f = 0; f < s.length; f++) {
            let d = s[f];
            if ((d.route.HydrateFallback || d.route.hydrateFallbackElement) && (c = f), d.route.id) {
                let {
                    loaderData: g,
                    errors: S
                } = n, v = d.route.loader && g[d.route.id] === void 0 && (!S || S[d.route.id] === void 0);
                if (d.route.lazy || v) {
                    u = !0, c >= 0 ? s = s.slice(0, c + 1) : s = [s[0]];
                    break
                }
            }
        }
    return s.reduceRight((f, d, g) => {
        let S, v = !1,
            _ = null,
            R = null;
        n && (S = i && d.route.id ? i[d.route.id] : void 0, _ = d.route.errorElement || rA, u && (c < 0 && g === 0 ? (v = !0, R = null) : c === g && (v = !0, R = d.route.hydrateFallbackElement || null)));
        let p = t.concat(s.slice(0, g + 1)),
            m = () => {
                let h;
                return S ? h = _ : v ? h = R : d.route.Component ? h = y.createElement(d.route.Component, null) : d.route.element ? h = d.route.element : h = f, y.createElement(lA, {
                    match: d,
                    routeContext: {
                        outlet: f,
                        matches: p,
                        isDataRoute: n != null
                    },
                    children: h
                })
            };
        return n && (d.route.ErrorBoundary || d.route.errorElement || g === 0) ? y.createElement(oA, {
            location: n.location,
            revalidation: n.revalidation,
            component: _,
            error: S,
            children: m(),
            routeContext: {
                outlet: null,
                matches: p,
                isDataRoute: !0
            }
        }) : m()
    }, null)
}
var Gg = function(e) {
        return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
    }(Gg || {}),
    Sa = function(e) {
        return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
    }(Sa || {});

function aA(e) {
    let t = y.useContext(Wd);
    return t || We(!1), t
}

function iA(e) {
    let t = y.useContext(Yk);
    return t || We(!1), t
}

function uA(e) {
    let t = y.useContext(_n);
    return t || We(!1), t
}

function qg(e) {
    let t = uA(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || We(!1), n.route.id
}

function cA() {
    var e;
    let t = y.useContext(Wg),
        n = iA(Sa.UseRouteError),
        r = qg(Sa.UseRouteError);
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r]
}

function dA() {
    let {
        router: e
    } = aA(Gg.UseNavigateStable), t = qg(Sa.UseNavigateStable), n = y.useRef(!1);
    return Kg(() => {
        n.current = !0
    }), y.useCallback(function(o, l) {
        l === void 0 && (l = {}), n.current && (typeof o == "number" ? e.navigate(o) : e.navigate(o, Sl({
            fromRouteId: t
        }, l)))
    }, [e, t])
}

function fA(e) {
    let {
        to: t,
        replace: n,
        state: r,
        relative: o
    } = e;
    Il() || We(!1);
    let {
        future: l,
        static: s
    } = y.useContext(bl), {
        matches: i
    } = y.useContext(_n), {
        pathname: u
    } = Kd(), c = si(), f = Bg(t, Hg(i, l.v7_relativeSplatPath), u, o === "path"), d = JSON.stringify(f);
    return y.useEffect(() => c(JSON.parse(d), {
        replace: n,
        state: r,
        relative: o
    }), [c, d, o, n, r]), null
}

function mA(e) {
    return Jk(e.context)
}

function lr(e) {
    We(!1)
}

function pA(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: o = In.Pop,
        navigator: l,
        static: s = !1,
        future: i
    } = e;
    Il() && We(!1);
    let u = t.replace(/^\/*/, "/"),
        c = y.useMemo(() => ({
            basename: u,
            navigator: l,
            static: s,
            future: Sl({
                v7_relativeSplatPath: !1
            }, i)
        }), [u, i, l, s]);
    typeof r == "string" && (r = _o(r));
    let {
        pathname: f = "/",
        search: d = "",
        hash: g = "",
        state: S = null,
        key: v = "default"
    } = r, _ = y.useMemo(() => {
        let R = $g(f, u);
        return R == null ? null : {
            location: {
                pathname: R,
                search: d,
                hash: g,
                state: S,
                key: v
            },
            navigationType: o
        }
    }, [u, f, d, g, S, v, o]);
    return _ == null ? null : y.createElement(bl.Provider, {
        value: c
    }, y.createElement(li.Provider, {
        children: n,
        value: _
    }))
}

function hA(e) {
    let {
        children: t,
        location: n
    } = e;
    return eA(Rc(t), n)
}
new Promise(() => {});

function Rc(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return y.Children.forEach(e, (r, o) => {
        if (!y.isValidElement(r)) return;
        let l = [...t, o];
        if (r.type === y.Fragment) {
            n.push.apply(n, Rc(r.props.children, l));
            return
        }
        r.type !== lr && We(!1), !r.props.index || !r.props.children || We(!1);
        let s = {
            id: r.props.id || l.join("-"),
            caseSensitive: r.props.caseSensitive,
            element: r.props.element,
            Component: r.props.Component,
            index: r.props.index,
            path: r.props.path,
            loader: r.props.loader,
            action: r.props.action,
            errorElement: r.props.errorElement,
            ErrorBoundary: r.props.ErrorBoundary,
            hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
            shouldRevalidate: r.props.shouldRevalidate,
            handle: r.props.handle,
            lazy: r.props.lazy
        };
        r.props.children && (s.children = Rc(r.props.children, l)), n.push(s)
    }), n
}
/**
 * React Router DOM v6.22.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
const vA = "6";
try {
    window.__reactRouterVersion = vA
} catch {}
const gA = "startTransition",
    Im = v0[gA];

function yA(e) {
    let {
        basename: t,
        children: n,
        future: r,
        window: o
    } = e, l = y.useRef();
    l.current == null && (l.current = xk({
        window: o,
        v5Compat: !0
    }));
    let s = l.current,
        [i, u] = y.useState({
            action: s.action,
            location: s.location
        }),
        {
            v7_startTransition: c
        } = r || {},
        f = y.useCallback(d => {
            c && Im ? Im(() => u(d)) : u(d)
        }, [u, c]);
    return y.useLayoutEffect(() => s.listen(f), [s, f]), y.createElement(pA, {
        basename: t,
        children: n,
        location: i.location,
        navigationType: i.action,
        navigator: s,
        future: r
    })
}
var Mm;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
})(Mm || (Mm = {}));
var Um;
(function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(Um || (Um = {}));

function Yg(e, t) {
    return function() {
        return e.apply(t, arguments)
    }
}
const {
    toString: _A
} = Object.prototype, {
    getPrototypeOf: Gd
} = Object, ai = (e => t => {
    const n = _A.call(t);
    return e[n] || (e[n] = n.slice(8, -1).toLowerCase())
})(Object.create(null)), nn = e => (e = e.toLowerCase(), t => ai(t) === e), ii = e => t => typeof t === e, {
    isArray: So
} = Array, wl = ii("undefined");

function SA(e) {
    return e !== null && !wl(e) && e.constructor !== null && !wl(e.constructor) && Dt(e.constructor.isBuffer) && e.constructor.isBuffer(e)
}
const Qg = nn("ArrayBuffer");

function wA(e) {
    let t;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && Qg(e.buffer), t
}
const EA = ii("string"),
    Dt = ii("function"),
    Xg = ii("number"),
    ui = e => e !== null && typeof e == "object",
    xA = e => e === !0 || e === !1,
    Hs = e => {
        if (ai(e) !== "object") return !1;
        const t = Gd(e);
        return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
    },
    NA = nn("Date"),
    RA = nn("File"),
    kA = nn("Blob"),
    AA = nn("FileList"),
    TA = e => ui(e) && Dt(e.pipe),
    jA = e => {
        let t;
        return e && (typeof FormData == "function" && e instanceof FormData || Dt(e.append) && ((t = ai(e)) === "formdata" || t === "object" && Dt(e.toString) && e.toString() === "[object FormData]"))
    },
    CA = nn("URLSearchParams"),
    LA = e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");

function Ml(e, t, {
    allOwnKeys: n = !1
} = {}) {
    if (e === null || typeof e > "u") return;
    let r, o;
    if (typeof e != "object" && (e = [e]), So(e))
        for (r = 0, o = e.length; r < o; r++) t.call(null, e[r], r, e);
    else {
        const l = n ? Object.getOwnPropertyNames(e) : Object.keys(e),
            s = l.length;
        let i;
        for (r = 0; r < s; r++) i = l[r], t.call(null, e[i], i, e)
    }
}

function Jg(e, t) {
    t = t.toLowerCase();
    const n = Object.keys(e);
    let r = n.length,
        o;
    for (; r-- > 0;)
        if (o = n[r], t === o.toLowerCase()) return o;
    return null
}
const Zg = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global,
    ey = e => !wl(e) && e !== Zg;

function kc() {
    const {
        caseless: e
    } = ey(this) && this || {}, t = {}, n = (r, o) => {
        const l = e && Jg(t, o) || o;
        Hs(t[l]) && Hs(r) ? t[l] = kc(t[l], r) : Hs(r) ? t[l] = kc({}, r) : So(r) ? t[l] = r.slice() : t[l] = r
    };
    for (let r = 0, o = arguments.length; r < o; r++) arguments[r] && Ml(arguments[r], n);
    return t
}
const DA = (e, t, n, {
        allOwnKeys: r
    } = {}) => (Ml(t, (o, l) => {
        n && Dt(o) ? e[l] = Yg(o, n) : e[l] = o
    }, {
        allOwnKeys: r
    }), e),
    PA = e => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e),
    OA = (e, t, n, r) => {
        e.prototype = Object.create(t.prototype, r), e.prototype.constructor = e, Object.defineProperty(e, "super", {
            value: t.prototype
        }), n && Object.assign(e.prototype, n)
    },
    bA = (e, t, n, r) => {
        let o, l, s;
        const i = {};
        if (t = t || {}, e == null) return t;
        do {
            for (o = Object.getOwnPropertyNames(e), l = o.length; l-- > 0;) s = o[l], (!r || r(s, e, t)) && !i[s] && (t[s] = e[s], i[s] = !0);
            e = n !== !1 && Gd(e)
        } while (e && (!n || n(e, t)) && e !== Object.prototype);
        return t
    },
    IA = (e, t, n) => {
        e = String(e), (n === void 0 || n > e.length) && (n = e.length), n -= t.length;
        const r = e.indexOf(t, n);
        return r !== -1 && r === n
    },
    MA = e => {
        if (!e) return null;
        if (So(e)) return e;
        let t = e.length;
        if (!Xg(t)) return null;
        const n = new Array(t);
        for (; t-- > 0;) n[t] = e[t];
        return n
    },
    UA = (e => t => e && t instanceof e)(typeof Uint8Array < "u" && Gd(Uint8Array)),
    FA = (e, t) => {
        const r = (e && e[Symbol.iterator]).call(e);
        let o;
        for (;
            (o = r.next()) && !o.done;) {
            const l = o.value;
            t.call(e, l[0], l[1])
        }
    },
    VA = (e, t) => {
        let n;
        const r = [];
        for (;
            (n = e.exec(t)) !== null;) r.push(n);
        return r
    },
    $A = nn("HTMLFormElement"),
    HA = e => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(n, r, o) {
        return r.toUpperCase() + o
    }),
    Fm = (({
        hasOwnProperty: e
    }) => (t, n) => e.call(t, n))(Object.prototype),
    BA = nn("RegExp"),
    ty = (e, t) => {
        const n = Object.getOwnPropertyDescriptors(e),
            r = {};
        Ml(n, (o, l) => {
            let s;
            (s = t(o, l, e)) !== !1 && (r[l] = s || o)
        }), Object.defineProperties(e, r)
    },
    zA = e => {
        ty(e, (t, n) => {
            if (Dt(e) && ["arguments", "caller", "callee"].indexOf(n) !== -1) return !1;
            const r = e[n];
            if (Dt(r)) {
                if (t.enumerable = !1, "writable" in t) {
                    t.writable = !1;
                    return
                }
                t.set || (t.set = () => {
                    throw Error("Can not rewrite read-only method '" + n + "'")
                })
            }
        })
    },
    WA = (e, t) => {
        const n = {},
            r = o => {
                o.forEach(l => {
                    n[l] = !0
                })
            };
        return So(e) ? r(e) : r(String(e).split(t)), n
    },
    KA = () => {},
    GA = (e, t) => (e = +e, Number.isFinite(e) ? e : t),
    pu = "abcdefghijklmnopqrstuvwxyz",
    Vm = "0123456789",
    ny = {
        DIGIT: Vm,
        ALPHA: pu,
        ALPHA_DIGIT: pu + pu.toUpperCase() + Vm
    },
    qA = (e = 16, t = ny.ALPHA_DIGIT) => {
        let n = "";
        const {
            length: r
        } = t;
        for (; e--;) n += t[Math.random() * r | 0];
        return n
    };

function YA(e) {
    return !!(e && Dt(e.append) && e[Symbol.toStringTag] === "FormData" && e[Symbol.iterator])
}
const QA = e => {
        const t = new Array(10),
            n = (r, o) => {
                if (ui(r)) {
                    if (t.indexOf(r) >= 0) return;
                    if (!("toJSON" in r)) {
                        t[o] = r;
                        const l = So(r) ? [] : {};
                        return Ml(r, (s, i) => {
                            const u = n(s, o + 1);
                            !wl(u) && (l[i] = u)
                        }), t[o] = void 0, l
                    }
                }
                return r
            };
        return n(e, 0)
    },
    XA = nn("AsyncFunction"),
    JA = e => e && (ui(e) || Dt(e)) && Dt(e.then) && Dt(e.catch),
    A = {
        isArray: So,
        isArrayBuffer: Qg,
        isBuffer: SA,
        isFormData: jA,
        isArrayBufferView: wA,
        isString: EA,
        isNumber: Xg,
        isBoolean: xA,
        isObject: ui,
        isPlainObject: Hs,
        isUndefined: wl,
        isDate: NA,
        isFile: RA,
        isBlob: kA,
        isRegExp: BA,
        isFunction: Dt,
        isStream: TA,
        isURLSearchParams: CA,
        isTypedArray: UA,
        isFileList: AA,
        forEach: Ml,
        merge: kc,
        extend: DA,
        trim: LA,
        stripBOM: PA,
        inherits: OA,
        toFlatObject: bA,
        kindOf: ai,
        kindOfTest: nn,
        endsWith: IA,
        toArray: MA,
        forEachEntry: FA,
        matchAll: VA,
        isHTMLForm: $A,
        hasOwnProperty: Fm,
        hasOwnProp: Fm,
        reduceDescriptors: ty,
        freezeMethods: zA,
        toObjectSet: WA,
        toCamelCase: HA,
        noop: KA,
        toFiniteNumber: GA,
        findKey: Jg,
        global: Zg,
        isContextDefined: ey,
        ALPHABET: ny,
        generateString: qA,
        isSpecCompliantForm: YA,
        toJSONObject: QA,
        isAsyncFn: XA,
        isThenable: JA
    };

function pe(e, t, n, r, o) {
    Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = e, this.name = "AxiosError", t && (this.code = t), n && (this.config = n), r && (this.request = r), o && (this.response = o)
}
A.inherits(pe, Error, {
    toJSON: function() {
        return {
            message: this.message,
            name: this.name,
            description: this.description,
            number: this.number,
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            config: A.toJSONObject(this.config),
            code: this.code,
            status: this.response && this.response.status ? this.response.status : null
        }
    }
});
const ry = pe.prototype,
    oy = {};
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach(e => {
    oy[e] = {
        value: e
    }
});
Object.defineProperties(pe, oy);
Object.defineProperty(ry, "isAxiosError", {
    value: !0
});
pe.from = (e, t, n, r, o, l) => {
    const s = Object.create(ry);
    return A.toFlatObject(e, s, function(u) {
        return u !== Error.prototype
    }, i => i !== "isAxiosError"), pe.call(s, e.message, t, n, r, o), s.cause = e, s.name = e.name, l && Object.assign(s, l), s
};
const ZA = null;

function Ac(e) {
    return A.isPlainObject(e) || A.isArray(e)
}

function ly(e) {
    return A.endsWith(e, "[]") ? e.slice(0, -2) : e
}

function $m(e, t, n) {
    return e ? e.concat(t).map(function(o, l) {
        return o = ly(o), !n && l ? "[" + o + "]" : o
    }).join(n ? "." : "") : t
}

function eT(e) {
    return A.isArray(e) && !e.some(Ac)
}
const tT = A.toFlatObject(A, {}, null, function(t) {
    return /^is[A-Z]/.test(t)
});

function ci(e, t, n) {
    if (!A.isObject(e)) throw new TypeError("target must be an object");
    t = t || new FormData, n = A.toFlatObject(n, {
        metaTokens: !0,
        dots: !1,
        indexes: !1
    }, !1, function(_, R) {
        return !A.isUndefined(R[_])
    });
    const r = n.metaTokens,
        o = n.visitor || f,
        l = n.dots,
        s = n.indexes,
        u = (n.Blob || typeof Blob < "u" && Blob) && A.isSpecCompliantForm(t);
    if (!A.isFunction(o)) throw new TypeError("visitor must be a function");

    function c(v) {
        if (v === null) return "";
        if (A.isDate(v)) return v.toISOString();
        if (!u && A.isBlob(v)) throw new pe("Blob is not supported. Use a Buffer instead.");
        return A.isArrayBuffer(v) || A.isTypedArray(v) ? u && typeof Blob == "function" ? new Blob([v]) : Buffer.from(v) : v
    }

    function f(v, _, R) {
        let p = v;
        if (v && !R && typeof v == "object") {
            if (A.endsWith(_, "{}")) _ = r ? _ : _.slice(0, -2), v = JSON.stringify(v);
            else if (A.isArray(v) && eT(v) || (A.isFileList(v) || A.endsWith(_, "[]")) && (p = A.toArray(v))) return _ = ly(_), p.forEach(function(h, x) {
                !(A.isUndefined(h) || h === null) && t.append(s === !0 ? $m([_], x, l) : s === null ? _ : _ + "[]", c(h))
            }), !1
        }
        return Ac(v) ? !0 : (t.append($m(R, _, l), c(v)), !1)
    }
    const d = [],
        g = Object.assign(tT, {
            defaultVisitor: f,
            convertValue: c,
            isVisitable: Ac
        });

    function S(v, _) {
        if (!A.isUndefined(v)) {
            if (d.indexOf(v) !== -1) throw Error("Circular reference detected in " + _.join("."));
            d.push(v), A.forEach(v, function(p, m) {
                (!(A.isUndefined(p) || p === null) && o.call(t, p, A.isString(m) ? m.trim() : m, _, g)) === !0 && S(p, _ ? _.concat(m) : [m])
            }), d.pop()
        }
    }
    if (!A.isObject(e)) throw new TypeError("data must be an object");
    return S(e), t
}

function Hm(e) {
    const t = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
    };
    return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(r) {
        return t[r]
    })
}

function qd(e, t) {
    this._pairs = [], e && ci(e, this, t)
}
const sy = qd.prototype;
sy.append = function(t, n) {
    this._pairs.push([t, n])
};
sy.toString = function(t) {
    const n = t ? function(r) {
        return t.call(this, r, Hm)
    } : Hm;
    return this._pairs.map(function(o) {
        return n(o[0]) + "=" + n(o[1])
    }, "").join("&")
};

function nT(e) {
    return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
}

function ay(e, t, n) {
    if (!t) return e;
    const r = n && n.encode || nT,
        o = n && n.serialize;
    let l;
    if (o ? l = o(t, n) : l = A.isURLSearchParams(t) ? t.toString() : new qd(t, n).toString(r), l) {
        const s = e.indexOf("#");
        s !== -1 && (e = e.slice(0, s)), e += (e.indexOf("?") === -1 ? "?" : "&") + l
    }
    return e
}
class Bm {
    constructor() {
        this.handlers = []
    }
    use(t, n, r) {
        return this.handlers.push({
            fulfilled: t,
            rejected: n,
            synchronous: r ? r.synchronous : !1,
            runWhen: r ? r.runWhen : null
        }), this.handlers.length - 1
    }
    eject(t) {
        this.handlers[t] && (this.handlers[t] = null)
    }
    clear() {
        this.handlers && (this.handlers = [])
    }
    forEach(t) {
        A.forEach(this.handlers, function(r) {
            r !== null && t(r)
        })
    }
}
const iy = {
        silentJSONParsing: !0,
        forcedJSONParsing: !0,
        clarifyTimeoutError: !1
    },
    rT = typeof URLSearchParams < "u" ? URLSearchParams : qd,
    oT = typeof FormData < "u" ? FormData : null,
    lT = typeof Blob < "u" ? Blob : null,
    sT = {
        isBrowser: !0,
        classes: {
            URLSearchParams: rT,
            FormData: oT,
            Blob: lT
        },
        protocols: ["http", "https", "file", "blob", "url", "data"]
    },
    uy = typeof window < "u" && typeof document < "u",
    aT = (e => uy && ["ReactNative", "NativeScript", "NS"].indexOf(e) < 0)(typeof navigator < "u" && navigator.product),
    iT = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function",
    uT = Object.freeze(Object.defineProperty({
        __proto__: null,
        hasBrowserEnv: uy,
        hasStandardBrowserEnv: aT,
        hasStandardBrowserWebWorkerEnv: iT
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Xt = { ...uT,
        ...sT
    };

function cT(e, t) {
    return ci(e, new Xt.classes.URLSearchParams, Object.assign({
        visitor: function(n, r, o, l) {
            return Xt.isNode && A.isBuffer(n) ? (this.append(r, n.toString("base64")), !1) : l.defaultVisitor.apply(this, arguments)
        }
    }, t))
}

function dT(e) {
    return A.matchAll(/\w+|\[(\w*)]/g, e).map(t => t[0] === "[]" ? "" : t[1] || t[0])
}

function fT(e) {
    const t = {},
        n = Object.keys(e);
    let r;
    const o = n.length;
    let l;
    for (r = 0; r < o; r++) l = n[r], t[l] = e[l];
    return t
}

function cy(e) {
    function t(n, r, o, l) {
        let s = n[l++];
        if (s === "__proto__") return !0;
        const i = Number.isFinite(+s),
            u = l >= n.length;
        return s = !s && A.isArray(o) ? o.length : s, u ? (A.hasOwnProp(o, s) ? o[s] = [o[s], r] : o[s] = r, !i) : ((!o[s] || !A.isObject(o[s])) && (o[s] = []), t(n, r, o[s], l) && A.isArray(o[s]) && (o[s] = fT(o[s])), !i)
    }
    if (A.isFormData(e) && A.isFunction(e.entries)) {
        const n = {};
        return A.forEachEntry(e, (r, o) => {
            t(dT(r), o, n, 0)
        }), n
    }
    return null
}

function mT(e, t, n) {
    if (A.isString(e)) try {
        return (t || JSON.parse)(e), A.trim(e)
    } catch (r) {
        if (r.name !== "SyntaxError") throw r
    }
    return (n || JSON.stringify)(e)
}
const Ul = {
    transitional: iy,
    adapter: ["xhr", "http"],
    transformRequest: [function(t, n) {
        const r = n.getContentType() || "",
            o = r.indexOf("application/json") > -1,
            l = A.isObject(t);
        if (l && A.isHTMLForm(t) && (t = new FormData(t)), A.isFormData(t)) return o ? JSON.stringify(cy(t)) : t;
        if (A.isArrayBuffer(t) || A.isBuffer(t) || A.isStream(t) || A.isFile(t) || A.isBlob(t)) return t;
        if (A.isArrayBufferView(t)) return t.buffer;
        if (A.isURLSearchParams(t)) return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), t.toString();
        let i;
        if (l) {
            if (r.indexOf("application/x-www-form-urlencoded") > -1) return cT(t, this.formSerializer).toString();
            if ((i = A.isFileList(t)) || r.indexOf("multipart/form-data") > -1) {
                const u = this.env && this.env.FormData;
                return ci(i ? {
                    "files[]": t
                } : t, u && new u, this.formSerializer)
            }
        }
        return l || o ? (n.setContentType("application/json", !1), mT(t)) : t
    }],
    transformResponse: [function(t) {
        const n = this.transitional || Ul.transitional,
            r = n && n.forcedJSONParsing,
            o = this.responseType === "json";
        if (t && A.isString(t) && (r && !this.responseType || o)) {
            const s = !(n && n.silentJSONParsing) && o;
            try {
                return JSON.parse(t)
            } catch (i) {
                if (s) throw i.name === "SyntaxError" ? pe.from(i, pe.ERR_BAD_RESPONSE, this, null, this.response) : i
            }
        }
        return t
    }],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: Xt.classes.FormData,
        Blob: Xt.classes.Blob
    },
    validateStatus: function(t) {
        return t >= 200 && t < 300
    },
    headers: {
        common: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": void 0
        }
    }
};
A.forEach(["delete", "get", "head", "post", "put", "patch"], e => {
    Ul.headers[e] = {}
});
const pT = A.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
    hT = e => {
        const t = {};
        let n, r, o;
        return e && e.split(`
`).forEach(function(s) {
            o = s.indexOf(":"), n = s.substring(0, o).trim().toLowerCase(), r = s.substring(o + 1).trim(), !(!n || t[n] && pT[n]) && (n === "set-cookie" ? t[n] ? t[n].push(r) : t[n] = [r] : t[n] = t[n] ? t[n] + ", " + r : r)
        }), t
    },
    zm = Symbol("internals");

function Io(e) {
    return e && String(e).trim().toLowerCase()
}

function Bs(e) {
    return e === !1 || e == null ? e : A.isArray(e) ? e.map(Bs) : String(e)
}

function vT(e) {
    const t = Object.create(null),
        n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let r;
    for (; r = n.exec(e);) t[r[1]] = r[2];
    return t
}
const gT = e => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());

function hu(e, t, n, r, o) {
    if (A.isFunction(r)) return r.call(this, t, n);
    if (o && (t = n), !!A.isString(t)) {
        if (A.isString(r)) return t.indexOf(r) !== -1;
        if (A.isRegExp(r)) return r.test(t)
    }
}

function yT(e) {
    return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, n, r) => n.toUpperCase() + r)
}

function _T(e, t) {
    const n = A.toCamelCase(" " + t);
    ["get", "set", "has"].forEach(r => {
        Object.defineProperty(e, r + n, {
            value: function(o, l, s) {
                return this[r].call(this, t, o, l, s)
            },
            configurable: !0
        })
    })
}
class Pt {
    constructor(t) {
        t && this.set(t)
    }
    set(t, n, r) {
        const o = this;

        function l(i, u, c) {
            const f = Io(u);
            if (!f) throw new Error("header name must be a non-empty string");
            const d = A.findKey(o, f);
            (!d || o[d] === void 0 || c === !0 || c === void 0 && o[d] !== !1) && (o[d || u] = Bs(i))
        }
        const s = (i, u) => A.forEach(i, (c, f) => l(c, f, u));
        return A.isPlainObject(t) || t instanceof this.constructor ? s(t, n) : A.isString(t) && (t = t.trim()) && !gT(t) ? s(hT(t), n) : t != null && l(n, t, r), this
    }
    get(t, n) {
        if (t = Io(t), t) {
            const r = A.findKey(this, t);
            if (r) {
                const o = this[r];
                if (!n) return o;
                if (n === !0) return vT(o);
                if (A.isFunction(n)) return n.call(this, o, r);
                if (A.isRegExp(n)) return n.exec(o);
                throw new TypeError("parser must be boolean|regexp|function")
            }
        }
    }
    has(t, n) {
        if (t = Io(t), t) {
            const r = A.findKey(this, t);
            return !!(r && this[r] !== void 0 && (!n || hu(this, this[r], r, n)))
        }
        return !1
    }
    delete(t, n) {
        const r = this;
        let o = !1;

        function l(s) {
            if (s = Io(s), s) {
                const i = A.findKey(r, s);
                i && (!n || hu(r, r[i], i, n)) && (delete r[i], o = !0)
            }
        }
        return A.isArray(t) ? t.forEach(l) : l(t), o
    }
    clear(t) {
        const n = Object.keys(this);
        let r = n.length,
            o = !1;
        for (; r--;) {
            const l = n[r];
            (!t || hu(this, this[l], l, t, !0)) && (delete this[l], o = !0)
        }
        return o
    }
    normalize(t) {
        const n = this,
            r = {};
        return A.forEach(this, (o, l) => {
            const s = A.findKey(r, l);
            if (s) {
                n[s] = Bs(o), delete n[l];
                return
            }
            const i = t ? yT(l) : String(l).trim();
            i !== l && delete n[l], n[i] = Bs(o), r[i] = !0
        }), this
    }
    concat(...t) {
        return this.constructor.concat(this, ...t)
    }
    toJSON(t) {
        const n = Object.create(null);
        return A.forEach(this, (r, o) => {
            r != null && r !== !1 && (n[o] = t && A.isArray(r) ? r.join(", ") : r)
        }), n
    }[Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]()
    }
    toString() {
        return Object.entries(this.toJSON()).map(([t, n]) => t + ": " + n).join(`
`)
    }
    get[Symbol.toStringTag]() {
        return "AxiosHeaders"
    }
    static from(t) {
        return t instanceof this ? t : new this(t)
    }
    static concat(t, ...n) {
        const r = new this(t);
        return n.forEach(o => r.set(o)), r
    }
    static accessor(t) {
        const r = (this[zm] = this[zm] = {
                accessors: {}
            }).accessors,
            o = this.prototype;

        function l(s) {
            const i = Io(s);
            r[i] || (_T(o, s), r[i] = !0)
        }
        return A.isArray(t) ? t.forEach(l) : l(t), this
    }
}
Pt.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
A.reduceDescriptors(Pt.prototype, ({
    value: e
}, t) => {
    let n = t[0].toUpperCase() + t.slice(1);
    return {
        get: () => e,
        set(r) {
            this[n] = r
        }
    }
});
A.freezeMethods(Pt);

function vu(e, t) {
    const n = this || Ul,
        r = t || n,
        o = Pt.from(r.headers);
    let l = r.data;
    return A.forEach(e, function(i) {
        l = i.call(n, l, o.normalize(), t ? t.status : void 0)
    }), o.normalize(), l
}

function dy(e) {
    return !!(e && e.__CANCEL__)
}

function Fl(e, t, n) {
    pe.call(this, e ? ? "canceled", pe.ERR_CANCELED, t, n), this.name = "CanceledError"
}
A.inherits(Fl, pe, {
    __CANCEL__: !0
});

function ST(e, t, n) {
    const r = n.config.validateStatus;
    !n.status || !r || r(n.status) ? e(n) : t(new pe("Request failed with status code " + n.status, [pe.ERR_BAD_REQUEST, pe.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4], n.config, n.request, n))
}
const wT = Xt.hasStandardBrowserEnv ? {
    write(e, t, n, r, o, l) {
        const s = [e + "=" + encodeURIComponent(t)];
        A.isNumber(n) && s.push("expires=" + new Date(n).toGMTString()), A.isString(r) && s.push("path=" + r), A.isString(o) && s.push("domain=" + o), l === !0 && s.push("secure"), document.cookie = s.join("; ")
    },
    read(e) {
        const t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
        return t ? decodeURIComponent(t[3]) : null
    },
    remove(e) {
        this.write(e, "", Date.now() - 864e5)
    }
} : {
    write() {},
    read() {
        return null
    },
    remove() {}
};

function ET(e) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)
}

function xT(e, t) {
    return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e
}

function fy(e, t) {
    return e && !ET(t) ? xT(e, t) : t
}
const NT = Xt.hasStandardBrowserEnv ? function() {
    const t = /(msie|trident)/i.test(navigator.userAgent),
        n = document.createElement("a");
    let r;

    function o(l) {
        let s = l;
        return t && (n.setAttribute("href", s), s = n.href), n.setAttribute("href", s), {
            href: n.href,
            protocol: n.protocol ? n.protocol.replace(/:$/, "") : "",
            host: n.host,
            search: n.search ? n.search.replace(/^\?/, "") : "",
            hash: n.hash ? n.hash.replace(/^#/, "") : "",
            hostname: n.hostname,
            port: n.port,
            pathname: n.pathname.charAt(0) === "/" ? n.pathname : "/" + n.pathname
        }
    }
    return r = o(window.location.href),
        function(s) {
            const i = A.isString(s) ? o(s) : s;
            return i.protocol === r.protocol && i.host === r.host
        }
}() : function() {
    return function() {
        return !0
    }
}();

function RT(e) {
    const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
    return t && t[1] || ""
}

function kT(e, t) {
    e = e || 10;
    const n = new Array(e),
        r = new Array(e);
    let o = 0,
        l = 0,
        s;
    return t = t !== void 0 ? t : 1e3,
        function(u) {
            const c = Date.now(),
                f = r[l];
            s || (s = c), n[o] = u, r[o] = c;
            let d = l,
                g = 0;
            for (; d !== o;) g += n[d++], d = d % e;
            if (o = (o + 1) % e, o === l && (l = (l + 1) % e), c - s < t) return;
            const S = f && c - f;
            return S ? Math.round(g * 1e3 / S) : void 0
        }
}

function Wm(e, t) {
    let n = 0;
    const r = kT(50, 250);
    return o => {
        const l = o.loaded,
            s = o.lengthComputable ? o.total : void 0,
            i = l - n,
            u = r(i),
            c = l <= s;
        n = l;
        const f = {
            loaded: l,
            total: s,
            progress: s ? l / s : void 0,
            bytes: i,
            rate: u || void 0,
            estimated: u && s && c ? (s - l) / u : void 0,
            event: o
        };
        f[t ? "download" : "upload"] = !0, e(f)
    }
}
const AT = typeof XMLHttpRequest < "u",
    TT = AT && function(e) {
        return new Promise(function(n, r) {
            let o = e.data;
            const l = Pt.from(e.headers).normalize();
            let {
                responseType: s,
                withXSRFToken: i
            } = e, u;

            function c() {
                e.cancelToken && e.cancelToken.unsubscribe(u), e.signal && e.signal.removeEventListener("abort", u)
            }
            let f;
            if (A.isFormData(o)) {
                if (Xt.hasStandardBrowserEnv || Xt.hasStandardBrowserWebWorkerEnv) l.setContentType(!1);
                else if ((f = l.getContentType()) !== !1) {
                    const [_, ...R] = f ? f.split(";").map(p => p.trim()).filter(Boolean) : [];
                    l.setContentType([_ || "multipart/form-data", ...R].join("; "))
                }
            }
            let d = new XMLHttpRequest;
            if (e.auth) {
                const _ = e.auth.username || "",
                    R = e.auth.password ? unescape(encodeURIComponent(e.auth.password)) : "";
                l.set("Authorization", "Basic " + btoa(_ + ":" + R))
            }
            const g = fy(e.baseURL, e.url);
            d.open(e.method.toUpperCase(), ay(g, e.params, e.paramsSerializer), !0), d.timeout = e.timeout;

            function S() {
                if (!d) return;
                const _ = Pt.from("getAllResponseHeaders" in d && d.getAllResponseHeaders()),
                    p = {
                        data: !s || s === "text" || s === "json" ? d.responseText : d.response,
                        status: d.status,
                        statusText: d.statusText,
                        headers: _,
                        config: e,
                        request: d
                    };
                ST(function(h) {
                    n(h), c()
                }, function(h) {
                    r(h), c()
                }, p), d = null
            }
            if ("onloadend" in d ? d.onloadend = S : d.onreadystatechange = function() {
                    !d || d.readyState !== 4 || d.status === 0 && !(d.responseURL && d.responseURL.indexOf("file:") === 0) || setTimeout(S)
                }, d.onabort = function() {
                    d && (r(new pe("Request aborted", pe.ECONNABORTED, e, d)), d = null)
                }, d.onerror = function() {
                    r(new pe("Network Error", pe.ERR_NETWORK, e, d)), d = null
                }, d.ontimeout = function() {
                    let R = e.timeout ? "timeout of " + e.timeout + "ms exceeded" : "timeout exceeded";
                    const p = e.transitional || iy;
                    e.timeoutErrorMessage && (R = e.timeoutErrorMessage), r(new pe(R, p.clarifyTimeoutError ? pe.ETIMEDOUT : pe.ECONNABORTED, e, d)), d = null
                }, Xt.hasStandardBrowserEnv && (i && A.isFunction(i) && (i = i(e)), i || i !== !1 && NT(g))) {
                const _ = e.xsrfHeaderName && e.xsrfCookieName && wT.read(e.xsrfCookieName);
                _ && l.set(e.xsrfHeaderName, _)
            }
            o === void 0 && l.setContentType(null), "setRequestHeader" in d && A.forEach(l.toJSON(), function(R, p) {
                d.setRequestHeader(p, R)
            }), A.isUndefined(e.withCredentials) || (d.withCredentials = !!e.withCredentials), s && s !== "json" && (d.responseType = e.responseType), typeof e.onDownloadProgress == "function" && d.addEventListener("progress", Wm(e.onDownloadProgress, !0)), typeof e.onUploadProgress == "function" && d.upload && d.upload.addEventListener("progress", Wm(e.onUploadProgress)), (e.cancelToken || e.signal) && (u = _ => {
                d && (r(!_ || _.type ? new Fl(null, e, d) : _), d.abort(), d = null)
            }, e.cancelToken && e.cancelToken.subscribe(u), e.signal && (e.signal.aborted ? u() : e.signal.addEventListener("abort", u)));
            const v = RT(g);
            if (v && Xt.protocols.indexOf(v) === -1) {
                r(new pe("Unsupported protocol " + v + ":", pe.ERR_BAD_REQUEST, e));
                return
            }
            d.send(o || null)
        })
    },
    Tc = {
        http: ZA,
        xhr: TT
    };
A.forEach(Tc, (e, t) => {
    if (e) {
        try {
            Object.defineProperty(e, "name", {
                value: t
            })
        } catch {}
        Object.defineProperty(e, "adapterName", {
            value: t
        })
    }
});
const Km = e => `- ${e}`,
    jT = e => A.isFunction(e) || e === null || e === !1,
    my = {
        getAdapter: e => {
            e = A.isArray(e) ? e : [e];
            const {
                length: t
            } = e;
            let n, r;
            const o = {};
            for (let l = 0; l < t; l++) {
                n = e[l];
                let s;
                if (r = n, !jT(n) && (r = Tc[(s = String(n)).toLowerCase()], r === void 0)) throw new pe(`Unknown adapter '${s}'`);
                if (r) break;
                o[s || "#" + l] = r
            }
            if (!r) {
                const l = Object.entries(o).map(([i, u]) => `adapter ${i} ` + (u === !1 ? "is not supported by the environment" : "is not available in the build"));
                let s = t ? l.length > 1 ? `since :
` + l.map(Km).join(`
`) : " " + Km(l[0]) : "as no adapter specified";
                throw new pe("There is no suitable adapter to dispatch the request " + s, "ERR_NOT_SUPPORT")
            }
            return r
        },
        adapters: Tc
    };

function gu(e) {
    if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new Fl(null, e)
}

function Gm(e) {
    return gu(e), e.headers = Pt.from(e.headers), e.data = vu.call(e, e.transformRequest), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", !1), my.getAdapter(e.adapter || Ul.adapter)(e).then(function(r) {
        return gu(e), r.data = vu.call(e, e.transformResponse, r), r.headers = Pt.from(r.headers), r
    }, function(r) {
        return dy(r) || (gu(e), r && r.response && (r.response.data = vu.call(e, e.transformResponse, r.response), r.response.headers = Pt.from(r.response.headers))), Promise.reject(r)
    })
}
const qm = e => e instanceof Pt ? { ...e
} : e;

function mo(e, t) {
    t = t || {};
    const n = {};

    function r(c, f, d) {
        return A.isPlainObject(c) && A.isPlainObject(f) ? A.merge.call({
            caseless: d
        }, c, f) : A.isPlainObject(f) ? A.merge({}, f) : A.isArray(f) ? f.slice() : f
    }

    function o(c, f, d) {
        if (A.isUndefined(f)) {
            if (!A.isUndefined(c)) return r(void 0, c, d)
        } else return r(c, f, d)
    }

    function l(c, f) {
        if (!A.isUndefined(f)) return r(void 0, f)
    }

    function s(c, f) {
        if (A.isUndefined(f)) {
            if (!A.isUndefined(c)) return r(void 0, c)
        } else return r(void 0, f)
    }

    function i(c, f, d) {
        if (d in t) return r(c, f);
        if (d in e) return r(void 0, c)
    }
    const u = {
        url: l,
        method: l,
        data: l,
        baseURL: s,
        transformRequest: s,
        transformResponse: s,
        paramsSerializer: s,
        timeout: s,
        timeoutMessage: s,
        withCredentials: s,
        withXSRFToken: s,
        adapter: s,
        responseType: s,
        xsrfCookieName: s,
        xsrfHeaderName: s,
        onUploadProgress: s,
        onDownloadProgress: s,
        decompress: s,
        maxContentLength: s,
        maxBodyLength: s,
        beforeRedirect: s,
        transport: s,
        httpAgent: s,
        httpsAgent: s,
        cancelToken: s,
        socketPath: s,
        responseEncoding: s,
        validateStatus: i,
        headers: (c, f) => o(qm(c), qm(f), !0)
    };
    return A.forEach(Object.keys(Object.assign({}, e, t)), function(f) {
        const d = u[f] || o,
            g = d(e[f], t[f], f);
        A.isUndefined(g) && d !== i || (n[f] = g)
    }), n
}
const py = "1.6.8",
    Yd = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
    Yd[e] = function(r) {
        return typeof r === e || "a" + (t < 1 ? "n " : " ") + e
    }
});
const Ym = {};
Yd.transitional = function(t, n, r) {
    function o(l, s) {
        return "[Axios v" + py + "] Transitional option '" + l + "'" + s + (r ? ". " + r : "")
    }
    return (l, s, i) => {
        if (t === !1) throw new pe(o(s, " has been removed" + (n ? " in " + n : "")), pe.ERR_DEPRECATED);
        return n && !Ym[s] && (Ym[s] = !0, console.warn(o(s, " has been deprecated since v" + n + " and will be removed in the near future"))), t ? t(l, s, i) : !0
    }
};

function CT(e, t, n) {
    if (typeof e != "object") throw new pe("options must be an object", pe.ERR_BAD_OPTION_VALUE);
    const r = Object.keys(e);
    let o = r.length;
    for (; o-- > 0;) {
        const l = r[o],
            s = t[l];
        if (s) {
            const i = e[l],
                u = i === void 0 || s(i, l, e);
            if (u !== !0) throw new pe("option " + l + " must be " + u, pe.ERR_BAD_OPTION_VALUE);
            continue
        }
        if (n !== !0) throw new pe("Unknown option " + l, pe.ERR_BAD_OPTION)
    }
}
const jc = {
        assertOptions: CT,
        validators: Yd
    },
    Tn = jc.validators;
class mr {
    constructor(t) {
        this.defaults = t, this.interceptors = {
            request: new Bm,
            response: new Bm
        }
    }
    async request(t, n) {
        try {
            return await this._request(t, n)
        } catch (r) {
            if (r instanceof Error) {
                let o;
                Error.captureStackTrace ? Error.captureStackTrace(o = {}) : o = new Error;
                const l = o.stack ? o.stack.replace(/^.+\n/, "") : "";
                r.stack ? l && !String(r.stack).endsWith(l.replace(/^.+\n.+\n/, "")) && (r.stack += `
` + l) : r.stack = l
            }
            throw r
        }
    }
    _request(t, n) {
        typeof t == "string" ? (n = n || {}, n.url = t) : n = t || {}, n = mo(this.defaults, n);
        const {
            transitional: r,
            paramsSerializer: o,
            headers: l
        } = n;
        r !== void 0 && jc.assertOptions(r, {
            silentJSONParsing: Tn.transitional(Tn.boolean),
            forcedJSONParsing: Tn.transitional(Tn.boolean),
            clarifyTimeoutError: Tn.transitional(Tn.boolean)
        }, !1), o != null && (A.isFunction(o) ? n.paramsSerializer = {
            serialize: o
        } : jc.assertOptions(o, {
            encode: Tn.function,
            serialize: Tn.function
        }, !0)), n.method = (n.method || this.defaults.method || "get").toLowerCase();
        let s = l && A.merge(l.common, l[n.method]);
        l && A.forEach(["delete", "get", "head", "post", "put", "patch", "common"], v => {
            delete l[v]
        }), n.headers = Pt.concat(s, l);
        const i = [];
        let u = !0;
        this.interceptors.request.forEach(function(_) {
            typeof _.runWhen == "function" && _.runWhen(n) === !1 || (u = u && _.synchronous, i.unshift(_.fulfilled, _.rejected))
        });
        const c = [];
        this.interceptors.response.forEach(function(_) {
            c.push(_.fulfilled, _.rejected)
        });
        let f, d = 0,
            g;
        if (!u) {
            const v = [Gm.bind(this), void 0];
            for (v.unshift.apply(v, i), v.push.apply(v, c), g = v.length, f = Promise.resolve(n); d < g;) f = f.then(v[d++], v[d++]);
            return f
        }
        g = i.length;
        let S = n;
        for (d = 0; d < g;) {
            const v = i[d++],
                _ = i[d++];
            try {
                S = v(S)
            } catch (R) {
                _.call(this, R);
                break
            }
        }
        try {
            f = Gm.call(this, S)
        } catch (v) {
            return Promise.reject(v)
        }
        for (d = 0, g = c.length; d < g;) f = f.then(c[d++], c[d++]);
        return f
    }
    getUri(t) {
        t = mo(this.defaults, t);
        const n = fy(t.baseURL, t.url);
        return ay(n, t.params, t.paramsSerializer)
    }
}
A.forEach(["delete", "get", "head", "options"], function(t) {
    mr.prototype[t] = function(n, r) {
        return this.request(mo(r || {}, {
            method: t,
            url: n,
            data: (r || {}).data
        }))
    }
});
A.forEach(["post", "put", "patch"], function(t) {
    function n(r) {
        return function(l, s, i) {
            return this.request(mo(i || {}, {
                method: t,
                headers: r ? {
                    "Content-Type": "multipart/form-data"
                } : {},
                url: l,
                data: s
            }))
        }
    }
    mr.prototype[t] = n(), mr.prototype[t + "Form"] = n(!0)
});
class Qd {
    constructor(t) {
        if (typeof t != "function") throw new TypeError("executor must be a function.");
        let n;
        this.promise = new Promise(function(l) {
            n = l
        });
        const r = this;
        this.promise.then(o => {
            if (!r._listeners) return;
            let l = r._listeners.length;
            for (; l-- > 0;) r._listeners[l](o);
            r._listeners = null
        }), this.promise.then = o => {
            let l;
            const s = new Promise(i => {
                r.subscribe(i), l = i
            }).then(o);
            return s.cancel = function() {
                r.unsubscribe(l)
            }, s
        }, t(function(l, s, i) {
            r.reason || (r.reason = new Fl(l, s, i), n(r.reason))
        })
    }
    throwIfRequested() {
        if (this.reason) throw this.reason
    }
    subscribe(t) {
        if (this.reason) {
            t(this.reason);
            return
        }
        this._listeners ? this._listeners.push(t) : this._listeners = [t]
    }
    unsubscribe(t) {
        if (!this._listeners) return;
        const n = this._listeners.indexOf(t);
        n !== -1 && this._listeners.splice(n, 1)
    }
    static source() {
        let t;
        return {
            token: new Qd(function(o) {
                t = o
            }),
            cancel: t
        }
    }
}

function LT(e) {
    return function(n) {
        return e.apply(null, n)
    }
}

function DT(e) {
    return A.isObject(e) && e.isAxiosError === !0
}
const Cc = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
};
Object.entries(Cc).forEach(([e, t]) => {
    Cc[t] = e
});

function hy(e) {
    const t = new mr(e),
        n = Yg(mr.prototype.request, t);
    return A.extend(n, mr.prototype, t, {
        allOwnKeys: !0
    }), A.extend(n, t, null, {
        allOwnKeys: !0
    }), n.create = function(o) {
        return hy(mo(e, o))
    }, n
}
const ue = hy(Ul);
ue.Axios = mr;
ue.CanceledError = Fl;
ue.CancelToken = Qd;
ue.isCancel = dy;
ue.VERSION = py;
ue.toFormData = ci;
ue.AxiosError = pe;
ue.Cancel = ue.CanceledError;
ue.all = function(t) {
    return Promise.all(t)
};
ue.spread = LT;
ue.isAxiosError = DT;
ue.mergeConfig = mo;
ue.AxiosHeaders = Pt;
ue.formToJSON = e => cy(A.isHTMLForm(e) ? new FormData(e) : e);
ue.getAdapter = my.getAdapter;
ue.HttpStatusCode = Cc;
ue.default = ue;
const ze = "https://gongnomok.site";

function PT() {
    const [e, t] = _a(oi), [n, r] = _a(ri), o = si();
    async function l(s) {
        try {
            (await ue.post(`${ze}/api/logout`)).status === 204 && (r(!1), t(xc), o("/"))
        } catch (i) {
            console.log(i)
        }
    }
    return a.jsx(a.Fragment, {
        children: a.jsx("nav", {
            className: "navbar navbar-expand-lg bg-body-tertiary",
            children: a.jsxs("div", {
                className: "container-fluid",
                children: [a.jsx("div", {
                    className: "header-title",
                    children: a.jsxs("a", {
                        className: "navbar-brand",
                        href: "/",
                        children: [a.jsx("img", {
                            src: "/images/logo.png",
                            alt: "gongnomok-home"
                        }), a.jsx("span", {
                            children: "메이플 주문서 시뮬레이터"
                        })]
                    })
                }), a.jsx("button", {
                    className: "navbar-toggler",
                    type: "button",
                    "data-bs-toggle": "collapse",
                    "data-bs-target": "#navbarSupportedContent",
                    "aria-controls": "navbarSupportedContent",
                    "aria-expanded": "false",
                    "aria-label": "Toggle navigation",
                    children: a.jsx("span", {
                        className: "navbar-toggler-icon"
                    })
                }), a.jsxs("div", {
                    className: "collapse navbar-collapse",
                    id: "navbarSupportedContent",
                    children: [a.jsxs("ul", {
                        className: "navbar-nav me-auto mb-2 mb-lg-0",
                        children: [e === Sk ? a.jsxs("li", {
                            className: "nav-item dropdown",
                            children: [a.jsx("a", {
                                className: "nav-link dropdown-toggle",
                                href: "#",
                                role: "button",
                                "data-bs-toggle": "dropdown",
                                "aria-expanded": "false",
                                children: "관리"
                            }), a.jsxs("ul", {
                                className: "dropdown-menu",
                                children: [a.jsx("li", {
                                    children: a.jsx("a", {
                                        className: "dropdown-item",
                                        href: "/manage/item/new",
                                        children: "아이템 등록"
                                    })
                                }), a.jsx("li", {
                                    children: a.jsx("a", {
                                        className: "dropdown-item",
                                        href: "/manage/item",
                                        children: "아이템 관리"
                                    })
                                }), a.jsx("li", {
                                    children: a.jsx("a", {
                                        className: "dropdown-item",
                                        href: "/manage/comment",
                                        children: "신고댓글 관리"
                                    })
                                })]
                            })]
                        }) : null, n ? null : a.jsx("li", {
                            className: "nav-item",
                            children: a.jsx("a", {
                                className: "nav-link",
                                href: "/login",
                                children: "관리자 로그인"
                            })
                        })]
                    }), n ? a.jsx("form", {
                        className: "d-flex",
                        role: "logout",
                        children: a.jsx("button", {
                            className: "btn btn-outline-danger btn-sm",
                            type: "button",
                            onClick: l,
                            children: "로그아웃"
                        })
                    }) : null]
                })]
            })
        })
    })
}

function Es({
    isSelected: e,
    jobName: t,
    jobNameEng: n,
    changeHandler: r
}) {
    return a.jsx(a.Fragment, {
        children: a.jsxs("button", {
            className: `job-select-button ${e?"select-active":""}`,
            onClick: o => r(o, n),
            children: [a.jsx("img", {
                src: `/images/jobs/${n}.png`
            }), a.jsx("span", {
                children: t
            })]
        })
    })
}
const vy = {
    name: "",
    jobs: {
        warrior: !1,
        bowman: !1,
        magician: !1,
        thief: !1
    },
    minLevel: 0,
    category: "ALL"
};

function Oe({
    category: e,
    condition: t,
    name: n,
    representationItemNumber: r,
    changeHandler: o
}) {
    return a.jsx(a.Fragment, {
        children: a.jsxs("button", {
            className: `category-select-button ${t===e?"select-active-text":""}`,
            onClick: l => o(l, e),
            children: [a.jsx("img", {
                src: `/images/item/${r}.png`
            }), a.jsx("span", {
                children: n
            })]
        })
    })
}

function OT({
    searchCondition: e,
    handleItemNameChange: t,
    handleJobsChange: n,
    handleMinLevelChange: r,
    handleCategoryChange: o,
    doSearch: l
}) {
    var s, i, u, c;
    return a.jsx(a.Fragment, {
        children: a.jsxs("section", {
            className: "bg-light rounded py-3",
            children: [a.jsx("h2", {
                className: "text-center item-condition-title",
                children: "아이템 찾기"
            }), a.jsxs("form", {
                onSubmit: f => l(f, e),
                children: [a.jsxs("section", {
                    id: "item-name-condition",
                    className: "d-flex bd-highlight",
                    children: [a.jsx("div", {
                        className: "p-2 flex-grow-1 bd-highlight",
                        children: a.jsx("input", {
                            className: "form-control form-control-md",
                            placeholder: "아이템 이름",
                            onChange: t
                        })
                    }), a.jsx("div", {
                        className: "p-2 bd-highlight",
                        children: a.jsx("button", {
                            className: "btn btn-primary btn-md",
                            type: "submit",
                            children: "검색"
                        })
                    })]
                }), a.jsxs("section", {
                    className: "px-2 mt-2",
                    children: [a.jsx("span", {
                        className: "condition-title",
                        children: "직업"
                    }), a.jsxs("div", {
                        className: "job-select-button-container",
                        children: [a.jsx(Es, {
                            isSelected: (s = e == null ? void 0 : e.jobs) == null ? void 0 : s.warrior,
                            jobName: "전사",
                            jobNameEng: "warrior",
                            changeHandler: n
                        }), a.jsx(Es, {
                            isSelected: (i = e == null ? void 0 : e.jobs) == null ? void 0 : i.bowman,
                            jobName: "궁수",
                            jobNameEng: "bowman",
                            changeHandler: n
                        }), a.jsx(Es, {
                            isSelected: (u = e == null ? void 0 : e.jobs) == null ? void 0 : u.magician,
                            jobName: "마법사",
                            jobNameEng: "magician",
                            changeHandler: n
                        }), a.jsx(Es, {
                            isSelected: (c = e == null ? void 0 : e.jobs) == null ? void 0 : c.thief,
                            jobName: "도적",
                            jobNameEng: "thief",
                            changeHandler: n
                        })]
                    })]
                }), a.jsxs("section", {
                    className: "px-2 mt-3",
                    children: [a.jsxs("label", {
                        className: "form-label condition-title",
                        htmlFor: "min-level-range",
                        children: ["최소 레벨", a.jsxs("b", {
                            children: [" ", a.jsx("span", {
                                className: "text-success",
                                children: e == null ? void 0 : e.minLevel
                            })]
                        })]
                    }), a.jsx("input", {
                        type: "range",
                        className: "form-range",
                        min: "0",
                        max: "120",
                        step: "1",
                        id: "min-level-range",
                        defaultValue: vy.minLevel,
                        onChange: r
                    })]
                }), a.jsxs("section", {
                    className: "px-2 category-select-container",
                    children: [a.jsx("span", {
                        className: "condition-title",
                        children: "카테고리"
                    }), a.jsxs("div", {
                        className: "category-select-button-container",
                        children: [a.jsx(Oe, {
                            category: "ONE_HANDED_SWORD",
                            condition: e == null ? void 0 : e.category,
                            name: "한손검",
                            representationItemNumber: 5,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "TWO_HANDED_SWORD",
                            condition: e == null ? void 0 : e.category,
                            name: "두손검",
                            representationItemNumber: 36,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "ONE_HANDED_AXE",
                            condition: e == null ? void 0 : e.category,
                            name: "한손 도끼",
                            representationItemNumber: 58,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "TWO_HANDED_AXE",
                            condition: e == null ? void 0 : e.category,
                            name: "두손 도끼",
                            representationItemNumber: 73,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "ONE_HANDED_BLUNT",
                            condition: e == null ? void 0 : e.category,
                            name: "한손 둔기",
                            representationItemNumber: 96,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "TWO_HANDED_BLUNT",
                            condition: e == null ? void 0 : e.category,
                            name: "두손 둔기",
                            representationItemNumber: 106,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "SPEAR",
                            condition: e == null ? void 0 : e.category,
                            name: "창",
                            representationItemNumber: 125,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "POLEARM",
                            condition: e == null ? void 0 : e.category,
                            name: "폴암",
                            representationItemNumber: 147,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "BOW",
                            condition: e == null ? void 0 : e.category,
                            name: "활",
                            representationItemNumber: 193,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "CROSSBOW",
                            condition: e == null ? void 0 : e.category,
                            name: "석궁",
                            representationItemNumber: 218,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "WAND",
                            condition: e == null ? void 0 : e.category,
                            name: "완드",
                            representationItemNumber: 160,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "STAFF",
                            condition: e == null ? void 0 : e.category,
                            name: "스태프",
                            representationItemNumber: 181,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "DAGGER",
                            condition: e == null ? void 0 : e.category,
                            name: "단검",
                            representationItemNumber: 278,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "CLAW",
                            condition: e == null ? void 0 : e.category,
                            name: "아대",
                            representationItemNumber: 254,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "HAT",
                            condition: e == null ? void 0 : e.category,
                            name: "모자",
                            representationItemNumber: 330,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "GLOVES",
                            condition: e == null ? void 0 : e.category,
                            name: "장갑",
                            representationItemNumber: 2060,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "SHOES",
                            condition: e == null ? void 0 : e.category,
                            name: "신발",
                            representationItemNumber: 847,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "OVERALL",
                            condition: e == null ? void 0 : e.category,
                            name: "한벌옷",
                            representationItemNumber: 461,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "TOP",
                            condition: e == null ? void 0 : e.category,
                            name: "상의",
                            representationItemNumber: 976,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "BOTTOM",
                            condition: e == null ? void 0 : e.category,
                            name: "하의",
                            representationItemNumber: 435,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "SHIELD",
                            condition: e == null ? void 0 : e.category,
                            name: "방패",
                            representationItemNumber: 2203,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "EARRING",
                            condition: e.category,
                            name: "귀고리",
                            representationItemNumber: 2031,
                            changeHandler: o
                        }), a.jsx(Oe, {
                            category: "CAPE",
                            condition: e == null ? void 0 : e.category,
                            name: "망토",
                            representationItemNumber: 2109,
                            changeHandler: o
                        })]
                    })]
                })]
            })]
        })
    })
}

function bT({
    id: e,
    name: t
}) {
    return a.jsx(a.Fragment, {
        children: a.jsx("div", {
            className: "item-list-button text-center",
            children: a.jsx("a", {
                href: `/item/${e}`,
                className: "link-underline link-underline-opacity-0",
                children: a.jsxs("button", {
                    children: [a.jsx("img", {
                        src: `/images/item/${e}.png`
                    }), a.jsx("span", {
                        children: t
                    })]
                })
            })
        })
    })
}

function IT({
    searchCondition: e,
    itemList: t,
    isItemLoaded: n,
    hasNextPage: r,
    handleMoreItemButton: o
}) {
    return a.jsx(a.Fragment, {
        children: a.jsxs("section", {
            className: "bg-light rounded py-3 px-1",
            children: [a.jsx("h2", {
                className: "item-list-title text-center",
                children: "아이템 목록"
            }), a.jsxs("section", {
                className: "col-md-12 bg-light rounded item-list-container px-2 py-2",
                children: [a.jsx("div", {
                    className: "item-list-grid",
                    children: t != null && (t == null ? void 0 : t.length) > 0 && (t == null ? void 0 : t.map(l => a.jsx("div", {
                        className: "col d-flex justify-content-center",
                        children: a.jsx(bT, {
                            id: l.itemId,
                            name: l.name
                        }, `item${l.itemId}`)
                    }, l.itemId)))
                }), !n && a.jsx("div", {
                    className: "text-center mt-3",
                    children: a.jsx("div", {
                        className: "spinner-border",
                        role: "status",
                        children: a.jsx("span", {
                            className: "visually-hidden",
                            children: "Loading..."
                        })
                    })
                }), r && a.jsx("button", {
                    className: "btn btn-light more-item-button",
                    onClick: l => o(l, e),
                    children: "더보기"
                })]
            })]
        })
    })
}
const xs = 30,
    Ns = 5,
    Qm = 4,
    MT = {
        name: "",
        score: 0,
        success: {
            total: 0,
            ten: 0,
            sixty: 0,
            hundred: 0
        },
        status: {
            str: 0,
            successCount: 0,
            dex: 0,
            intel: 0,
            luk: 0,
            phyAtk: 0,
            mgAtk: 0,
            phyDef: 0,
            mgDef: 0,
            acc: 0,
            avo: 0,
            move: 0,
            jump: 0,
            hp: 0,
            mp: 0
        }
    },
    Xm = {
        total: 0,
        ten: 0,
        sixty: 0,
        hundred: 0
    },
    gy = new Map([
        ["ONE_HANDED_SWORD", "한손검"],
        ["TWO_HANDED_SWORD", "두손검"],
        ["ONE_HANDED_AXE", "한손 도끼"],
        ["TWO_HANDED_AXE", "두손 도끼"],
        ["ONE_HANDED_BLUNT", "한손 둔기"],
        ["TWO_HANDED_BLUNT", "두손 둔기"],
        ["SPEAR", "창"],
        ["POLEARM", "폴암"],
        ["BOW", "활"],
        ["CROSSBOW", "석궁"],
        ["WAND", "완드"],
        ["STAFF", "스태프"],
        ["DAGGER", "단검"],
        ["CLAW", "아대"],
        ["HAT", "모자"],
        ["GLOVES", "장갑"],
        ["SHOES", "신발"],
        ["OVERALL", "한벌옷"],
        ["TOP", "상의"],
        ["BOTTOM", "하의"],
        ["SHIELD", "방패"],
        ["EARRING", "귀고리"],
        ["CAPE", "망토"]
    ]),
    yy = new Map([
        ["VERY_SLOW", "매우 느림"],
        ["SLOW", "느림"],
        ["NORMAL", "보통"],
        ["FAST", "빠름"],
        ["VERY_FAST", "매우 빠름"]
    ]);

function UT() {
    return a.jsx(a.Fragment, {
        children: a.jsxs("div", {
            className: "feedback-banner-root banner",
            children: ["버그, 건의사항은 ", a.jsx("a", {
                href: "https://forms.gle/Wsf2tfZz9xfDJyat8",
                children: "[링크]"
            }), "로 부탁드립니다"]
        })
    })
}

function FT() {
    return a.jsx(a.Fragment, {
        children: a.jsx("div", {
            className: "inform-banner-root banner",
            children: a.jsx("div", {
                children: "5/15 ~ 최고기록이 초기화 되었습니다"
            })
        })
    })
}

function VT() {
    const [e, t] = y.useState([]), [n, r] = y.useState(0);
    y.useEffect(() => {
        ue.get(`${ze}/api/item/ranking?page=0&size=${Ns}`, {
            withCredentials: !0
        }).then(s => {
            t(s == null ? void 0 : s.data)
        }).catch(s => {
            console.log(s)
        })
    }, []);

    function o() {
        n <= 0 || (ue.get(`${ze}/api/item/ranking?page=${n-1}&size=${Ns}`, {
            withCredentials: !0
        }).then(s => {
            t(s == null ? void 0 : s.data)
        }).catch(s => {
            console.log(s)
        }), r(s => s - 1))
    }

    function l() {
        n >= Qm - 1 || (ue.get(`${ze}/api/item/ranking?page=${n+1}&size=${Ns}`, {
            withCredentials: !0
        }).then(s => {
            t(s == null ? void 0 : s.data)
        }).catch(s => {
            console.log(s)
        }), r(s => s + 1))
    }
    return a.jsx(a.Fragment, {
        children: a.jsxs("section", {
            className: "item-ranking-container d-flex bg-light",
            children: [a.jsx("span", {
                className: "item-ranking-title",
                children: "인기 아이템"
            }), a.jsx("div", {
                className: "item-ranking-controller",
                children: a.jsx("div", {
                    className: "ranking-items",
                    children: e != null && (e == null ? void 0 : e.length) > 0 && (e == null ? void 0 : e.map(s => a.jsx("div", {
                        children: a.jsx("a", {
                            href: `/item/${s.itemId}`,
                            children: a.jsxs("div", {
                                className: "single-ranking-item",
                                children: [a.jsx("span", {
                                    className: "item-rank-text",
                                    children: `${s.rank+n*Ns}위 `
                                }), a.jsx("img", {
                                    src: `/images/item/${s.itemId}.png`
                                }), a.jsx("span", {
                                    children: `${s.name}`
                                }), a.jsx("span", {
                                    children: ` (${s.viewCount}회)`
                                })]
                            })
                        })
                    }, `item-rank${s.rank}`)))
                })
            }), a.jsxs("section", {
                className: "item-ranking-page-controller-container",
                children: [a.jsx("button", {
                    className: "item-ranking-button",
                    onClick: o,
                    children: a.jsx("img", {
                        src: "/images/etc/previous.png"
                    })
                }), a.jsx("span", {
                    children: `${n+1}/${Qm}`
                }), a.jsx("button", {
                    className: "item-ranking-button",
                    onClick: l,
                    children: a.jsx("img", {
                        src: "/images/etc/next.png"
                    })
                })]
            })]
        })
    })
}

function $T() {
    const [e, t] = y.useState([]), [n, r] = y.useState(!1), o = y.useRef(0), [l, s] = y.useState(!0);
    y.useEffect(() => {
        i()
    }, []);

    function i() {
        r(!1), ue.get(`${ze}/api/items?page=0&size=${xs}`).then(p => {
            var h, x;
            const m = (h = p == null ? void 0 : p.data) == null ? void 0 : h.items;
            m == null ? t([]) : t(m), r(!0), ((x = p.data.items) == null ? void 0 : x.length) < xs ? s(!1) : s(!0), o.current += 1
        }).catch(p => {
            console.log(p), t([])
        })
    }

    function u(p) {
        ue.post(`${ze}/api/items?page=${o.current}&size=${xs}`, p, {
            withCredentials: !0
        }).then(m => {
            var h;
            o.current == 0 ? t([...m.data.items]) : t([...e, ...m.data.items]), r(!0), ((h = m.data.items) == null ? void 0 : h.length) < xs ? s(!1) : s(!0), o.current += 1
        }).catch(m => {
            console.log(m), t([])
        })
    }

    function c(p, m) {
        p.preventDefault(), u(m)
    }

    function f(p, m) {
        p.preventDefault(), u(m)
    }
    const [d, g] = y.useState(vy);

    function S(p) {
        p.preventDefault(), o.current = 0;
        let m = { ...d
        };
        m.name = p.target.value, g(m)
    }

    function v(p, m) {
        p.preventDefault(), o.current = 0;
        let h = { ...d
        };
        switch (m) {
            case "warrior":
                h.jobs.warrior = !h.jobs.warrior;
                break;
            case "bowman":
                h.jobs.bowman = !h.jobs.bowman;
                break;
            case "magician":
                h.jobs.magician = !h.jobs.magician;
                break;
            case "thief":
                h.jobs.thief = !h.jobs.thief;
                break
        }
        g(h), u(h)
    }

    function _(p) {
        o.current = 0;
        let m = { ...d
        };
        m.minLevel = p.target.value, g(m)
    }

    function R(p, m) {
        p.preventDefault(), o.current = 0;
        let h = { ...d
        };
        h.category === m ? h.category = "ALL" : h.category = m, g(h), u(h)
    }
    return a.jsx(a.Fragment, {
        children: a.jsxs("section", {
            className: "mt-3",
            children: [a.jsx("div", {
                className: "row mb-3",
                children: a.jsxs("section", {
                    children: [a.jsx(UT, {}), a.jsx(FT, {})]
                })
            }), a.jsxs("div", {
                className: "row",
                children: [a.jsxs("div", {
                    className: "col-lg-12 col-xl-4",
                    children: [a.jsx("section", {
                        className: "col-md-12",
                        children: a.jsx(OT, {
                            searchCondition: d,
                            handleItemNameChange: S,
                            handleJobsChange: v,
                            handleCategoryChange: R,
                            handleMinLevelChange: _,
                            doSearch: c
                        })
                    }), a.jsx(VT, {})]
                }), a.jsx("div", {
                    className: "col-lg-12 col-xl-8",
                    children: a.jsx("section", {
                        children: a.jsx(IT, {
                            searchCondition: d,
                            itemList: e,
                            isItemLoaded: n,
                            hasNextPage: l,
                            handleMoreItemButton: f
                        })
                    })
                })]
            })]
        })
    })
}

function HT() {
    const [e, t] = y.useState(""), [n, r] = y.useState(""), [o, l] = y.useState(!1), [s, i] = _a(ri), [u, c] = _a(oi), f = v => {
        v.preventDefault(), t(v.target.value)
    }, d = v => {
        v.preventDefault(), r(v.target.value)
    }, g = si(), S = v => {
        v.preventDefault(), ue.post(`${ze}/api/login`, {
            id: e,
            password: n
        }, {
            withCredentials: !0
        }).then(_ => {
            l(!1), i(!0), c(_.data.role), g("/")
        }).catch(_ => {
            l(!0)
        })
    };
    return a.jsx(a.Fragment, {
        children: a.jsxs("section", {
            className: "justify-content-center text-center mt-3",
            children: [a.jsx("h2", {
                children: "관리자 로그인"
            }), a.jsx("div", {
                className: "text-start text-danger",
                children: o && a.jsx("p", {
                    children: "아이디나 패스워드를 잘못 입력하였습니다."
                })
            }), a.jsx("form", {
                onSubmit: S,
                children: a.jsx("div", {
                    className: "text-start",
                    children: a.jsxs("div", {
                        className: "d-grid gap-2",
                        children: [a.jsxs("div", {
                            children: [a.jsx("label", {
                                htmlFor: "id",
                                className: "form-label",
                                children: "아이디"
                            }), a.jsx("input", {
                                type: "text",
                                id: "id",
                                className: "form-control",
                                "aria-describedby": "id-input",
                                placeholder: "아이디를 입력하세요",
                                value: e,
                                onChange: f
                            })]
                        }), a.jsxs("div", {
                            children: [a.jsx("label", {
                                htmlFor: "password",
                                className: "form-label",
                                children: "패스워드"
                            }), a.jsx("input", {
                                type: "password",
                                id: "password",
                                className: "form-control",
                                "aria-describedby": "password-input",
                                placeholder: "비밀번호를 입력하세요",
                                value: n,
                                onChange: d
                            })]
                        }), a.jsx("button", {
                            className: " btn btn-success mt-3",
                            type: "submit",
                            children: "로그인"
                        })]
                    })
                })
            })]
        })
    })
}

function BT() {
    let e = new Audio("/sound/fail.mp3");
    e.volume = .15, e.currentTime = 0, e.play()
}

function zT() {
    let e = new Audio("/sound/success.mp3");
    e.volume = .15, e.currentTime = 0, e.play()
}

function WT() {
    let e = new Audio("/sound/purchase.mp3");
    e.volume = .15, e.currentTime = 0, e.play()
}

function KT() {
    let e = new Audio("/sound/dice.mp3");
    e.volume = .2, e.currentTime = 0, e.play()
}

function Lc() {
    return Lc = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Lc.apply(this, arguments)
}
var _y = ["shift", "alt", "meta", "mod", "ctrl"],
    GT = {
        esc: "escape",
        return: "enter",
        ".": "period",
        ",": "comma",
        "-": "slash",
        " ": "space",
        "`": "backquote",
        "#": "backslash",
        "+": "bracketright",
        ShiftLeft: "shift",
        ShiftRight: "shift",
        AltLeft: "alt",
        AltRight: "alt",
        MetaLeft: "meta",
        MetaRight: "meta",
        OSLeft: "meta",
        OSRight: "meta",
        ControlLeft: "ctrl",
        ControlRight: "ctrl"
    };

function Mn(e) {
    return (GT[e] || e).trim().toLowerCase().replace(/key|digit|numpad|arrow/, "")
}

function qT(e) {
    return _y.includes(e)
}

function yu(e, t) {
    return t === void 0 && (t = ","), e.split(t)
}

function _u(e, t, n) {
    t === void 0 && (t = "+");
    var r = e.toLocaleLowerCase().split(t).map(function(s) {
            return Mn(s)
        }),
        o = {
            alt: r.includes("alt"),
            ctrl: r.includes("ctrl") || r.includes("control"),
            shift: r.includes("shift"),
            meta: r.includes("meta"),
            mod: r.includes("mod")
        },
        l = r.filter(function(s) {
            return !_y.includes(s)
        });
    return Lc({}, o, {
        keys: l,
        description: n
    })
}(function() {
    typeof document < "u" && (document.addEventListener("keydown", function(e) {
        e.key !== void 0 && Sy([Mn(e.key), Mn(e.code)])
    }), document.addEventListener("keyup", function(e) {
        e.key !== void 0 && wy([Mn(e.key), Mn(e.code)])
    })), typeof window < "u" && window.addEventListener("blur", function() {
        Un.clear()
    })
})();
var Un = new Set;

function Xd(e) {
    return Array.isArray(e)
}

function YT(e, t) {
    t === void 0 && (t = ",");
    var n = Xd(e) ? e : e.split(t);
    return n.every(function(r) {
        return Un.has(r.trim().toLowerCase())
    })
}

function Sy(e) {
    var t = Array.isArray(e) ? e : [e];
    Un.has("meta") && Un.forEach(function(n) {
        return !qT(n) && Un.delete(n.toLowerCase())
    }), t.forEach(function(n) {
        return Un.add(n.toLowerCase())
    })
}

function wy(e) {
    var t = Array.isArray(e) ? e : [e];
    e === "meta" ? Un.clear() : t.forEach(function(n) {
        return Un.delete(n.toLowerCase())
    })
}

function QT(e, t, n) {
    (typeof n == "function" && n(e, t) || n === !0) && e.preventDefault()
}

function XT(e, t, n) {
    return typeof n == "function" ? n(e, t) : n === !0 || n === void 0
}

function JT(e) {
    return Ey(e, ["input", "textarea", "select"])
}

function Ey(e, t) {
    var n = e.target;
    t === void 0 && (t = !1);
    var r = n && n.tagName;
    return Xd(t) ? !!(r && t && t.some(function(o) {
        return o.toLowerCase() === r.toLowerCase()
    })) : !!(r && t && t === !0)
}

function ZT(e, t) {
    return e.length === 0 && t ? (console.warn('A hotkey has the "scopes" option set, however no active scopes were found. If you want to use the global scopes feature, you need to wrap your app in a <HotkeysProvider>'), !0) : t ? e.some(function(n) {
        return t.includes(n)
    }) || e.includes("*") : !0
}
var ej = function(t, n, r) {
        r === void 0 && (r = !1);
        var o = n.alt,
            l = n.meta,
            s = n.mod,
            i = n.shift,
            u = n.ctrl,
            c = n.keys,
            f = t.key,
            d = t.code,
            g = t.ctrlKey,
            S = t.metaKey,
            v = t.shiftKey,
            _ = t.altKey,
            R = Mn(d),
            p = f.toLowerCase();
        if (!(c != null && c.includes(R)) && !(c != null && c.includes(p)) && !["ctrl", "control", "unknown", "meta", "alt", "shift", "os"].includes(R)) return !1;
        if (!r) {
            if (o === !_ && p !== "alt" || i === !v && p !== "shift") return !1;
            if (s) {
                if (!S && !g) return !1
            } else if (l === !S && p !== "meta" && p !== "os" || u === !g && p !== "ctrl" && p !== "control") return !1
        }
        return c && c.length === 1 && (c.includes(p) || c.includes(R)) ? !0 : c ? YT(c) : !c
    },
    tj = y.createContext(void 0),
    nj = function() {
        return y.useContext(tj)
    };

function xy(e, t) {
    return e && t && typeof e == "object" && typeof t == "object" ? Object.keys(e).length === Object.keys(t).length && Object.keys(e).reduce(function(n, r) {
        return n && xy(e[r], t[r])
    }, !0) : e === t
}
var rj = y.createContext({
        hotkeys: [],
        enabledScopes: [],
        toggleScope: function() {},
        enableScope: function() {},
        disableScope: function() {}
    }),
    oj = function() {
        return y.useContext(rj)
    };

function lj(e) {
    var t = y.useRef(void 0);
    return xy(t.current, e) || (t.current = e), t.current
}
var Jm = function(t) {
        t.stopPropagation(), t.preventDefault(), t.stopImmediatePropagation()
    },
    sj = typeof window < "u" ? y.useLayoutEffect : y.useEffect;

function qt(e, t, n, r) {
    var o = y.useRef(null),
        l = y.useRef(!1),
        s = n instanceof Array ? r instanceof Array ? void 0 : r : n,
        i = Xd(e) ? e.join(s == null ? void 0 : s.splitKey) : e,
        u = n instanceof Array ? n : r instanceof Array ? r : void 0,
        c = y.useCallback(t, u ? ? []),
        f = y.useRef(c);
    u ? f.current = c : f.current = t;
    var d = lj(s),
        g = oj(),
        S = g.enabledScopes,
        v = nj();
    return sj(function() {
        if (!((d == null ? void 0 : d.enabled) === !1 || !ZT(S, d == null ? void 0 : d.scopes))) {
            var _ = function(x, k) {
                    var C;
                    if (k === void 0 && (k = !1), !(JT(x) && !Ey(x, d == null ? void 0 : d.enableOnFormTags))) {
                        if (o.current !== null) {
                            var L = o.current.getRootNode();
                            if ((L instanceof Document || L instanceof ShadowRoot) && L.activeElement !== o.current && !o.current.contains(L.activeElement)) {
                                Jm(x);
                                return
                            }
                        }(C = x.target) != null && C.isContentEditable && !(d != null && d.enableOnContentEditable) || yu(i, d == null ? void 0 : d.splitKey).forEach(function(M) {
                            var oe, H = _u(M, d == null ? void 0 : d.combinationKey);
                            if (ej(x, H, d == null ? void 0 : d.ignoreModifiers) || (oe = H.keys) != null && oe.includes("*")) {
                                if (d != null && d.ignoreEventWhen != null && d.ignoreEventWhen(x) || k && l.current) return;
                                if (QT(x, H, d == null ? void 0 : d.preventDefault), !XT(x, H, d == null ? void 0 : d.enabled)) {
                                    Jm(x);
                                    return
                                }
                                f.current(x, H), k || (l.current = !0)
                            }
                        })
                    }
                },
                R = function(x) {
                    x.key !== void 0 && (Sy(Mn(x.code)), ((d == null ? void 0 : d.keydown) === void 0 && (d == null ? void 0 : d.keyup) !== !0 || d != null && d.keydown) && _(x))
                },
                p = function(x) {
                    x.key !== void 0 && (wy(Mn(x.code)), l.current = !1, d != null && d.keyup && _(x, !0))
                },
                m = o.current || (s == null ? void 0 : s.document) || document;
            return m.addEventListener("keyup", p), m.addEventListener("keydown", R), v && yu(i, d == null ? void 0 : d.splitKey).forEach(function(h) {
                    return v.addHotkey(_u(h, d == null ? void 0 : d.combinationKey, d == null ? void 0 : d.description))
                }),
                function() {
                    m.removeEventListener("keyup", p), m.removeEventListener("keydown", R), v && yu(i, d == null ? void 0 : d.splitKey).forEach(function(h) {
                        return v.removeHotkey(_u(h, d == null ? void 0 : d.combinationKey, d == null ? void 0 : d.description))
                    })
                }
        }
    }, [i, d, S]), o
}
const aj = {
        keyword: "GLOVES_PHY_ATK",
        name: "장갑 공격력 주문서",
        shortcut: "장공",
        category: "GLOVES",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 3
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    ij = {
        keyword: "GLOVES_SWIFT",
        name: "장갑 민첩성 주문서",
        shortcut: "장민",
        category: "GLOVES",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "dex",
                value: 3
            }, {
                name: "avo",
                value: 1
            }],
            _60: [{
                name: "acc",
                value: 2
            }, {
                name: "dex",
                value: 1
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    uj = {
        keyword: "GLOVES_HEALTH",
        name: "장갑 체력 주문서",
        shortcut: "장체",
        category: "GLOVES",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 30
            }],
            _60: [{
                name: "hp",
                value: 15
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    cj = {
        keyword: "HAT_SWIFT",
        name: "투구 민첩성 주문서",
        shortcut: "투민",
        category: "HAT",
        upgradeValue: {
            _10: [{
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "dex",
                value: 1
            }]
        }
    },
    dj = {
        keyword: "HAT_DEFENCE",
        name: "투구 방어력 주문서",
        shortcut: "투방",
        category: "HAT",
        upgradeValue: {
            _10: [{
                name: "phyDef",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "acc",
                value: 1
            }],
            _60: [{
                name: "phyDef",
                value: 2
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "phyDef",
                value: 1
            }]
        }
    },
    fj = {
        keyword: "HAT_INTEL",
        name: "투구 지력 주문서",
        shortcut: "투지",
        category: "HAT",
        upgradeValue: {
            _10: [{
                name: "intel",
                value: 3
            }],
            _60: [{
                name: "intel",
                value: 2
            }],
            _100: [{
                name: "intel",
                value: 1
            }]
        }
    },
    mj = {
        keyword: "HAT_HEALTH",
        name: "투구 체력 주문서",
        shortcut: "투체",
        category: "HAT",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 30
            }],
            _60: [{
                name: "hp",
                value: 10
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    pj = {
        keyword: "OVERALL_SWIFT",
        name: "전신 갑옷 민첩성 주문서",
        shortcut: "전민",
        category: "OVERALL",
        upgradeValue: {
            _10: [{
                name: "dex",
                value: 5
            }, {
                name: "acc",
                value: 3
            }, {
                name: "move",
                value: 1
            }],
            _60: [{
                name: "dex",
                value: 2
            }, {
                name: "acc",
                value: 1
            }],
            _100: [{
                name: "dex",
                value: 1
            }]
        }
    },
    hj = {
        keyword: "OVERALL_DEFENCE",
        name: "전신 갑옷 방어력 주문서",
        shortcut: "전방",
        category: "OVERALL",
        upgradeValue: {
            _10: [{
                name: "phyDef",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "hp",
                value: 10
            }],
            _60: [{
                name: "phyDef",
                value: 2
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "phyDef",
                value: 1
            }]
        }
    },
    vj = {
        keyword: "OVERALL_INTEL",
        name: "전신 갑옷 지력 주문서",
        shortcut: "전지",
        category: "OVERALL",
        upgradeValue: {
            _10: [{
                name: "intel",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "mp",
                value: 10
            }],
            _60: [{
                name: "intel",
                value: 2
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "intel",
                value: 1
            }]
        }
    },
    gj = {
        keyword: "OVERALL_LUCKY",
        name: "전신 갑옷 행운 주문서",
        shortcut: "전행",
        category: "OVERALL",
        upgradeValue: {
            _10: [{
                name: "luk",
                value: 5
            }, {
                name: "avo",
                value: 3
            }, {
                name: "acc",
                value: 1
            }],
            _60: [{
                name: "luk",
                value: 2
            }, {
                name: "avo",
                value: 1
            }],
            _100: [{
                name: "luk",
                value: 1
            }]
        }
    },
    yj = {
        keyword: "OVERALL_STRENGTH",
        name: "전신 갑옷 힘 주문서",
        shortcut: "전힘",
        category: "OVERALL",
        upgradeValue: {
            _10: [{
                name: "str",
                value: 5
            }, {
                name: "phyDef",
                value: 3
            }, {
                name: "hp",
                value: 5
            }],
            _60: [{
                name: "str",
                value: 2
            }, {
                name: "phyDef",
                value: 1
            }],
            _100: [{
                name: "str",
                value: 1
            }]
        }
    },
    _j = {
        keyword: "TOP_DEFENCE",
        name: "상의 방어력 주문서",
        shortcut: "상방",
        category: "TOP",
        upgradeValue: {
            _10: [{
                name: "phyDef",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "hp",
                value: 10
            }],
            _60: [{
                name: "phyDef",
                value: 2
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "phyDef",
                value: 1
            }]
        }
    },
    Sj = {
        keyword: "TOP_HEALTH",
        name: "상의 체력 주문서",
        shortcut: "상체",
        category: "TOP",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 30
            }],
            _60: [{
                name: "hp",
                value: 15
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    wj = {
        keyword: "TOP_LUCKY",
        name: "상의 행운 주문서",
        shortcut: "상행",
        category: "TOP",
        upgradeValue: {
            _10: [{
                name: "luk",
                value: 3
            }],
            _60: [{
                name: "luk",
                value: 2
            }],
            _100: [{
                name: "luk",
                value: 1
            }]
        }
    },
    Ej = {
        keyword: "TOP_STRENGTH",
        name: "상의 힘 주문서",
        shortcut: "상힘",
        category: "TOP",
        upgradeValue: {
            _10: [{
                name: "str",
                value: 3
            }],
            _60: [{
                name: "str",
                value: 2
            }],
            _100: [{
                name: "str",
                value: 1
            }]
        }
    },
    xj = {
        keyword: "BOTTOM_SWIFT",
        name: "하의 민첩성 주문서",
        shortcut: "하민",
        category: "BOTTOM",
        upgradeValue: {
            _10: [{
                name: "dex",
                value: 3
            }, {
                name: "acc",
                value: 2
            }, {
                name: "move",
                value: 1
            }],
            _60: [{
                name: "dex",
                value: 2
            }, {
                name: "acc",
                value: 1
            }],
            _100: [{
                name: "dex",
                value: 1
            }]
        }
    },
    Nj = {
        keyword: "BOTTOM_DEFENCE",
        name: "하의 방어력 주문서",
        shortcut: "하방",
        category: "BOTTOM",
        upgradeValue: {
            _10: [{
                name: "phyDef",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "hp",
                value: 10
            }],
            _60: [{
                name: "phyDef",
                value: 2
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "phyDef",
                value: 1
            }]
        }
    },
    Rj = {
        keyword: "BOTTOM_JUMP",
        name: "하의 점프 주문서",
        shortcut: "하점",
        category: "BOTTOM",
        upgradeValue: {
            _10: [{
                name: "jump",
                value: 4
            }, {
                name: "avo",
                value: 2
            }],
            _60: [{
                name: "jump",
                value: 2
            }, {
                name: "avo",
                value: 1
            }],
            _100: [{
                name: "jump",
                value: 1
            }]
        }
    },
    kj = {
        keyword: "BOTTOM_HEALTH",
        name: "하의 체력 주문서",
        shortcut: "하체",
        category: "BOTTOM",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 30
            }],
            _60: [{
                name: "hp",
                value: 10
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    Aj = {
        keyword: "SHOES_SWIFT",
        name: "신발 민첩성 주문서",
        shortcut: "신민",
        category: "SHOES",
        upgradeValue: {
            _10: [{
                name: "avo",
                value: 5
            }, {
                name: "acc",
                value: 3
            }, {
                name: "move",
                value: 1
            }],
            _60: [{
                name: "avo",
                value: 2
            }, {
                name: "acc",
                value: 1
            }],
            _100: [{
                name: "avo",
                value: 1
            }]
        }
    },
    Tj = {
        keyword: "SHOES_MOVE",
        name: "신발 이동속도 주문서",
        shortcut: "신속",
        category: "SHOES",
        upgradeValue: {
            _10: [{
                name: "move",
                value: 3
            }],
            _60: [{
                name: "move",
                value: 2
            }],
            _100: [{
                name: "move",
                value: 1
            }]
        }
    },
    jj = {
        keyword: "SHOES_JUMP",
        name: "신발 점프력 주문서",
        shortcut: "신점",
        category: "SHOES",
        upgradeValue: {
            _10: [{
                name: "jump",
                value: 5
            }, {
                name: "dex",
                value: 3
            }, {
                name: "move",
                value: 1
            }],
            _60: [{
                name: "jump",
                value: 2
            }, {
                name: "dex",
                value: 1
            }],
            _100: [{
                name: "jump",
                value: 1
            }]
        }
    },
    Cj = {
        keyword: "ONE_HANDED_SWORD_PHY_ATK",
        name: "한손검 공격력 주문서",
        shortcut: "공격력",
        category: "ONE_HANDED_SWORD",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Lj = {
        keyword: "ONE_HANDED_SWORD_ACC",
        name: "한손검 명중률 주문서",
        shortcut: "명중률",
        category: "ONE_HANDED_SWORD",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Dj = {
        keyword: "ONE_HANDED_AXE_PHY_ATK",
        name: "한손도끼 공격력 주문서",
        shortcut: "공격력",
        category: "ONE_HANDED_AXE",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Pj = {
        keyword: "ONE_HANDED_AXE_ACC",
        name: "한손도끼 명중률 주문서",
        shortcut: "명중률",
        category: "ONE_HANDED_AXE",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Oj = {
        keyword: "ONE_HANDED_BLUNT_PHY_ATK",
        name: "한손둔기 공격력 주문서",
        shortcut: "공격력",
        category: "ONE_HANDED_BLUNT",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    bj = {
        keyword: "ONE_HANDED_BLUNT_ACC",
        name: "한손둔기 명중률 주문서",
        shortcut: "명중률",
        category: "ONE_HANDED_BLUNT",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "str",
                value: 1
            }, {
                name: "phyDef",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Ij = {
        keyword: "TWO_HANDED_SWORD_PHY_ATK",
        name: "두손검 공격력 주문서",
        shortcut: "공격력",
        category: "TWO_HANDED_SWORD",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Mj = {
        keyword: "TWO_HANDED_SWORD_ACC",
        name: "두손검 명중률 주문서",
        shortcut: "명중률",
        category: "TWO_HANDED_SWORD",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Uj = {
        keyword: "TWO_HANDED_AXE_PHY_ATK",
        name: "두손도끼 공격력 주문서",
        shortcut: "공격력",
        category: "TWO_HANDED_AXE",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Fj = {
        keyword: "TWO_HANDED_AXE_ACC",
        name: "두손도끼 명중률 주문서",
        shortcut: "명중률",
        category: "TWO_HANDED_AXE",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Vj = {
        keyword: "TWO_HANDED_BLUNT_PHY_ATK",
        name: "두손둔기 공격력 주문서",
        shortcut: "공격력",
        category: "TWO_HANDED_BLUNT",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    $j = {
        keyword: "TWO_HANDED_BLUNT_ACC",
        name: "두손둔기 명중률 주문서",
        shortcut: "명중률",
        category: "TWO_HANDED_BLUNT",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Hj = {
        keyword: "SPEAR_PHY_ATK",
        name: "창 공격력 주문서",
        shortcut: "창공",
        category: "SPEAR",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Bj = {
        keyword: "SPEAR_ACC",
        name: "창 명중률 주문서",
        shortcut: "명중률",
        category: "SPEAR",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    zj = {
        keyword: "POLEARM_PHY_ATK",
        name: "폴암 공격력 주문서",
        shortcut: "폴공",
        category: "POLEARM",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "str",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "str",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Wj = {
        keyword: "POLEARM_ACC",
        name: "폴암 명중률 주문서",
        shortcut: "폴명",
        category: "POLEARM",
        upgradeValue: {
            _10: [{
                name: "acc",
                value: 5
            }, {
                name: "phyAtk",
                value: 3
            }, {
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "acc",
                value: 3
            }, {
                name: "phyAtk",
                value: 1
            }, {
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "acc",
                value: 1
            }]
        }
    },
    Kj = {
        keyword: "CLAW_PHY_ATK",
        name: "아대 공격력 주문서",
        shortcut: "아공",
        category: "CLAW",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "acc",
                value: 3
            }, {
                name: "luk",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "acc",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Gj = {
        keyword: "DAGGER_PHY_ATK",
        name: "단검 공격력 주문서",
        shortcut: "단공",
        category: "DAGGER",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "luk",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "luk",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    qj = {
        keyword: "BOW_PHY_ATK",
        name: "활 공격력 주문서",
        shortcut: "활공",
        category: "BOW",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "acc",
                value: 3
            }, {
                name: "dex",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "acc",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Yj = {
        keyword: "CROSSBOW_PHY_ATK",
        name: "석궁 공격력 주문서",
        shortcut: "석공",
        category: "CROSSBOW",
        upgradeValue: {
            _10: [{
                name: "phyAtk",
                value: 5
            }, {
                name: "acc",
                value: 3
            }, {
                name: "dex",
                value: 1
            }],
            _60: [{
                name: "phyAtk",
                value: 2
            }, {
                name: "acc",
                value: 1
            }],
            _100: [{
                name: "phyAtk",
                value: 1
            }]
        }
    },
    Qj = {
        keyword: "WAND_MG_ATK",
        name: "완드 마력 주문서",
        shortcut: "완마",
        category: "WAND",
        upgradeValue: {
            _10: [{
                name: "mgAtk",
                value: 5
            }, {
                name: "intel",
                value: 3
            }, {
                name: "mgDef",
                value: 1
            }],
            _60: [{
                name: "mgAtk",
                value: 2
            }, {
                name: "intel",
                value: 1
            }],
            _100: [{
                name: "mgAtk",
                value: 1
            }]
        }
    },
    Xj = {
        keyword: "STAFF_MG_ATK",
        name: "스태프 마력 주문서",
        shortcut: "스마",
        category: "STAFF",
        upgradeValue: {
            _10: [{
                name: "mgAtk",
                value: 5
            }, {
                name: "intel",
                value: 3
            }, {
                name: "mgDef",
                value: 1
            }],
            _60: [{
                name: "mgAtk",
                value: 2
            }, {
                name: "intel",
                value: 1
            }],
            _100: [{
                name: "mgAtk",
                value: 1
            }]
        }
    },
    Jj = {
        keyword: "EARRING_SWIFT",
        name: "귀 장식 민첩 주문서",
        shortcut: "귀민",
        category: "EARRING",
        upgradeValue: {
            _10: [{
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "dex",
                value: 1
            }]
        }
    },
    Zj = {
        keyword: "EARRING_INTEL",
        name: "귀 장식 지력 주문서",
        shortcut: "귀지",
        category: "EARRING",
        upgradeValue: {
            _10: [{
                name: "mgAtk",
                value: 5
            }, {
                name: "intel",
                value: 3
            }, {
                name: "mgDef",
                value: 1
            }],
            _60: [{
                name: "mgAtk",
                value: 2
            }, {
                name: "intel",
                value: 1
            }],
            _100: [{
                name: "mgAtk",
                value: 1
            }]
        }
    },
    eC = {
        keyword: "EARRING_LUCKY",
        name: "귀 장식 행운 주문서",
        shortcut: "귀행",
        category: "EARRING",
        upgradeValue: {
            _10: [{
                name: "luk",
                value: 3
            }],
            _60: [{
                name: "luk",
                value: 2
            }],
            _100: [{
                name: "luk",
                value: 1
            }]
        }
    },
    tC = {
        keyword: "EARRING_HEALTH",
        name: "귀 장식 체력 주문서",
        shortcut: "귀체",
        category: "EARRING",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 30
            }],
            _60: [{
                name: "hp",
                value: 15
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    nC = {
        keyword: "CAPE_MANA",
        name: "망토 마나 주문서",
        shortcut: "망마",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "mp",
                value: 20
            }],
            _60: [{
                name: "mp",
                value: 10
            }],
            _100: [{
                name: "mp",
                value: 5
            }]
        }
    },
    rC = {
        keyword: "CAPE_SWIFT",
        name: "망토 민첩성 주문서",
        shortcut: "망민",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "dex",
                value: 3
            }],
            _60: [{
                name: "dex",
                value: 2
            }],
            _100: [{
                name: "dex",
                value: 1
            }]
        }
    },
    oC = {
        keyword: "CAPE_INTEL",
        name: "망토 지력 주문서",
        shortcut: "망지",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "intel",
                value: 3
            }],
            _60: [{
                name: "intel",
                value: 2
            }],
            _100: [{
                name: "intel",
                value: 1
            }]
        }
    },
    lC = {
        keyword: "CAPE_HEALTH",
        name: "망토 체력 주문서",
        shortcut: "망체",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 20
            }],
            _60: [{
                name: "hp",
                value: 10
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    sC = {
        keyword: "CAPE_LUCKY",
        name: "망토 행운 주문서",
        shortcut: "망행",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "luk",
                value: 3
            }],
            _60: [{
                name: "luk",
                value: 2
            }],
            _100: [{
                name: "luk",
                value: 1
            }]
        }
    },
    aC = {
        keyword: "CAPE_STRENGTH",
        name: "망토 힘 주문서",
        shortcut: "망힘",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "str",
                value: 3
            }],
            _60: [{
                name: "str",
                value: 2
            }],
            _100: [{
                name: "str",
                value: 1
            }]
        }
    },
    iC = {
        keyword: "CAPE_MG_DEF",
        name: "망토 마법방어력 주문서",
        shortcut: "망마방",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "mgDef",
                value: 5
            }, {
                name: "phyDef",
                value: 3
            }, {
                name: "mp",
                value: 10
            }],
            _60: [{
                name: "mgDef",
                value: 3
            }, {
                name: "phyDef",
                value: 1
            }],
            _100: [{
                name: "mgDef",
                value: 1
            }]
        }
    },
    uC = {
        keyword: "CAPE_PHY_DEF",
        name: "망토 물리방어력 주문서",
        shortcut: "망물방",
        category: "CAPE",
        upgradeValue: {
            _10: [{
                name: "phyDef",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "hp",
                value: 10
            }],
            _60: [{
                name: "phyDef",
                value: 3
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "phyDef",
                value: 1
            }]
        }
    },
    cC = {
        keyword: "SHIELD_DEFENCE",
        name: "방패 방어력 주문서",
        shortcut: "방어력",
        category: "SHIELD",
        upgradeValue: {
            _10: [{
                name: "phyDef",
                value: 5
            }, {
                name: "mgDef",
                value: 3
            }, {
                name: "hp",
                value: 10
            }],
            _60: [{
                name: "phyDef",
                value: 2
            }, {
                name: "mgDef",
                value: 1
            }],
            _100: [{
                name: "phyDef",
                value: 1
            }]
        }
    },
    dC = {
        keyword: "SHIELD_HEALTH",
        name: "방패 체력 주문서",
        shortcut: "방체",
        category: "SHIELD",
        upgradeValue: {
            _10: [{
                name: "hp",
                value: 30
            }],
            _60: [{
                name: "hp",
                value: 15
            }],
            _100: [{
                name: "hp",
                value: 5
            }]
        }
    },
    fC = {
        keyword: "SHIELD_LUCKY",
        name: "방패 행운 주문서",
        shortcut: "방행",
        category: "SHIELD",
        upgradeValue: {
            _10: [{
                name: "luk",
                value: 3
            }],
            _60: [{
                name: "luk",
                value: 2
            }],
            _100: [{
                name: "luk",
                value: 1
            }]
        }
    },
    mC = {
        keyword: "SHIELD_STRENGTH",
        name: "방패 힘 주문서",
        shortcut: "방힘",
        category: "SHIELD",
        upgradeValue: {
            _10: [{
                name: "str",
                value: 3
            }],
            _60: [{
                name: "str",
                value: 2
            }],
            _100: [{
                name: "str",
                value: 1
            }]
        }
    },
    Rs = ["GLOVES_PHY_ATK", "GLOVES_SWIFT", "GLOVES_HEALTH", "HAT_SWIFT", "HAT_DEFENCE", "HAT_INTEL", "HAT_HEALTH", "OVERALL_SWIFT", "OVERALL_DEFENCE", "OVERALL_INTEL", "OVERALL_LUCKY", "OVERALL_STRENGTH", "TOP_DEFENCE", "TOP_HEALTH", "TOP_LUCKY", "TOP_STRENGTH", "BOTTOM_SWIFT", "BOTTOM_DEFENCE", "BOTTOM_JUMP", "BOTTOM_HEALTH", "SHOES_SWIFT", "SHOES_MOVE", "SHOES_JUMP", "ONE_HANDED_SWORD_PHY_ATK", "ONE_HANDED_SWORD_ACC", "ONE_HANDED_AXE_PHY_ATK", "ONE_HANDED_AXE_ACC", "ONE_HANDED_BLUNT_PHY_ATK", "ONE_HANDED_BLUNT_ACC", "TWO_HANDED_SWORD_PHY_ATK", "TWO_HANDED_SWORD_ACC", "TWO_HANDED_AXE_PHY_ATK", "TWO_HANDED_AXE_ACC", "TWO_HANDED_BLUNT_PHY_ATK", "TWO_HANDED_BLUNT_ACC", "SPEAR_PHY_ATK", "SPEAR_ACC", "POLEARM_PHY_ATK", "POLEARM_ACC", "CLAW_PHY_ATK", "DAGGER_PHY_ATK", "BOW_PHY_ATK", "CROSSBOW_PHY_ATK", "WAND_MG_ATK", "STAFF_MG_ATK", "EARRING_SWIFT", "EARRING_INTEL", "EARRING_LUCKY", "EARRING_HEALTH", "CAPE_STRENGTH", "CAPE_SWIFT", "CAPE_INTEL", "CAPE_LUCKY", "CAPE_MANA", "CAPE_HEALTH", "CAPE_MG_DEF", "CAPE_PHY_DEF", "SHIELD_DEFENCE", "SHIELD_HEALTH", "SHIELD_LUCKY", "SHIELD_STRENGTH"],
    Or = new Map([
        ["GLOVES_PHY_ATK", aj],
        ["GLOVES_SWIFT", ij],
        ["GLOVES_HEALTH", uj],
        ["HAT_SWIFT", cj],
        ["HAT_DEFENCE", dj],
        ["HAT_INTEL", fj],
        ["HAT_HEALTH", mj],
        ["OVERALL_SWIFT", pj],
        ["OVERALL_DEFENCE", hj],
        ["OVERALL_INTEL", vj],
        ["OVERALL_LUCKY", gj],
        ["OVERALL_STRENGTH", yj],
        ["TOP_DEFENCE", _j],
        ["TOP_HEALTH", Sj],
        ["TOP_LUCKY", wj],
        ["TOP_STRENGTH", Ej],
        ["BOTTOM_SWIFT", xj],
        ["BOTTOM_DEFENCE", Nj],
        ["BOTTOM_JUMP", Rj],
        ["BOTTOM_HEALTH", kj],
        ["SHOES_SWIFT", Aj],
        ["SHOES_MOVE", Tj],
        ["SHOES_JUMP", jj],
        ["ONE_HANDED_SWORD_PHY_ATK", Cj],
        ["ONE_HANDED_SWORD_ACC", Lj],
        ["ONE_HANDED_AXE_PHY_ATK", Dj],
        ["ONE_HANDED_AXE_ACC", Pj],
        ["ONE_HANDED_BLUNT_PHY_ATK", Oj],
        ["ONE_HANDED_BLUNT_ACC", bj],
        ["TWO_HANDED_SWORD_PHY_ATK", Ij],
        ["TWO_HANDED_SWORD_ACC", Mj],
        ["TWO_HANDED_AXE_PHY_ATK", Uj],
        ["TWO_HANDED_AXE_ACC", Fj],
        ["TWO_HANDED_BLUNT_PHY_ATK", Vj],
        ["TWO_HANDED_BLUNT_ACC", $j],
        ["SPEAR_PHY_ATK", Hj],
        ["SPEAR_ACC", Bj],
        ["POLEARM_PHY_ATK", zj],
        ["POLEARM_ACC", Wj],
        ["CLAW_PHY_ATK", Kj],
        ["DAGGER_PHY_ATK", Gj],
        ["BOW_PHY_ATK", qj],
        ["CROSSBOW_PHY_ATK", Yj],
        ["WAND_MG_ATK", Qj],
        ["STAFF_MG_ATK", Xj],
        ["EARRING_SWIFT", Jj],
        ["EARRING_INTEL", Zj],
        ["EARRING_LUCKY", eC],
        ["EARRING_HEALTH", tC],
        ["CAPE_STRENGTH", aC],
        ["CAPE_SWIFT", rC],
        ["CAPE_INTEL", oC],
        ["CAPE_LUCKY", sC],
        ["CAPE_HEALTH", lC],
        ["CAPE_MANA", nC],
        ["CAPE_PHY_DEF", uC],
        ["CAPE_MG_DEF", iC],
        ["SHIELD_DEFENCE", cC],
        ["SHIELD_HEALTH", dC],
        ["SHIELD_STRENGTH", mC],
        ["SHIELD_LUCKY", fC]
    ]);

function pC({
    description: e
}) {
    return a.jsx(a.Fragment, {
        children: a.jsx("span", {
            className: "shortcut-description",
            children: e
        })
    })
}
const Mo = y.memo(pC),
    zs = new Map([
        ["str", "STR"],
        ["dex", "DEX"],
        ["intel", "INT"],
        ["luk", "LUK"],
        ["phyAtk", "물리공격력"],
        ["mgAtk", "마법공격력"],
        ["phyDef", "물리방어력"],
        ["mgDef", "마법방어력"],
        ["acc", "명중률"],
        ["avo", "회피율"],
        ["move", "이동속도"],
        ["jump", "점프력"],
        ["hp", "MaxHP"],
        ["mp", "MaxMP"]
    ]);

function hC({
    statusInfo: e,
    optionSelectHandler: t
}) {
    const [n, r] = y.useState([]);
    return y.useEffect(() => {
        const o = [];
        if (e != null) {
            const l = Object.keys(e);
            for (let s = 0; s < (l == null ? void 0 : l.length); s++) {
                const i = l[s],
                    u = e[i];
                (u.lower > 0 || u.upper > 0) && o.push({
                    name: i,
                    ...e[i]
                })
            }
            r(o)
        }
    }, [e]), a.jsx(a.Fragment, {
        children: (n == null ? void 0 : n.length) > 0 && (n == null ? void 0 : n.map(o => a.jsxs("select", {
            className: "form-select form-select-sm option-select-item",
            onChange: l => t(l, o.name),
            defaultValue: o.normal,
            children: [
                [...Array(o.lower).keys()].reverse().map(l => a.jsx("option", {
                    value: o.normal - (l + 1),
                    children: `${zs.get(o.name)}-${l+1}`
                }, `${o.name}_lower_${l+1}`)), a.jsx("option", {
                    value: o.normal,
                    children: `${zs.get(o.name)} 정옵`
                }), [...Array(o.upper).keys()].map(l => a.jsx("option", {
                    value: o.normal + (l + 1),
                    children: `${zs.get(o.name)}+${l+1}`
                }, `${o.name}_upper_${l+1}`))
            ]
        }, `${o.name}_option`)))
    })
}

function jt({
    name: e,
    value: t
}) {
    return a.jsx(a.Fragment, {
        children: a.jsxs("div", {
            className: "item-status-required",
            children: [a.jsxs("span", {
                className: "item-status-required-description",
                children: ["REQ ", e, " "]
            }), a.jsx("span", {
                className: "item-status-required-info",
                children: `: ${t}`
            })]
        })
    })
}

function vC({
    percent: e,
    currentScroll: t,
    onClick: n
}, r) {
    var l;
    const o = s => {
        var i, u, c;
        if (e === 10) return (i = s == null ? void 0 : s.upgradeValue) == null ? void 0 : i._10;
        if (e === 60) return (u = s == null ? void 0 : s.upgradeValue) == null ? void 0 : u._60;
        if (e === 100) return (c = s == null ? void 0 : s.upgradeValue) == null ? void 0 : c._100
    };
    return a.jsx(a.Fragment, {
        children: a.jsxs("div", {
            className: "scroll-info",
            children: [a.jsx("button", {
                ref: r,
                id: `scroll-button-${e}`,
                onClick: () => n(e),
                onMouseUp: () => document.activeElement.blur(),
                children: a.jsx("img", {
                    src: `/images/scroll/${e}.png`
                })
            }), a.jsxs("span", {
                children: [t == null ? void 0 : t.shortcut, e, "%"]
            }), (l = o(t)) == null ? void 0 : l.map(s => a.jsxs("span", {
                children: [zs.get(s.name), "+", s.value]
            }, `${s.name}${s.value}${e}`))]
        })
    })
}
const Su = y.forwardRef(vC);

function ks({
    isScroll: e,
    percent: t,
    price: n,
    buyCount: r,
    successCount: o,
    inputHandler: l
}) {
    return a.jsx(a.Fragment, {
        children: a.jsxs("div", {
            className: "price-input-container",
            children: [a.jsx("span", {
                className: "price-input-description",
                children: e ? `${t}% 가격: ` : "아이템 가격: "
            }), a.jsx("input", {
                type: "text",
                value: n,
                onChange: l,
                placeholder: 0
            }), a.jsx("span", {
                children: e ? `${o}/${r}개` : `${r}개`
            })]
        })
    })
}
const gC = {
        name: "",
        password: "",
        content: ""
    },
    yC = {
        commentId: null,
        password: ""
    },
    _C = {
        commentId: null
    },
    Zm = 20;

function SC(e) {
    const t = e.substring(0, 10),
        n = e.substring(11, 16);
    return t + " " + n
}

function wC(e) {
    return e.substring(0, 10)
}

function EC({
    info: e,
    handleReport: t,
    handleDelete: n
}) {
    return a.jsx(a.Fragment, {
        children: a.jsxs("div", {
            className: "comment-item-root",
            children: [a.jsxs("div", {
                children: [a.jsxs("div", {
                    className: "comment-item-top-container",
                    children: [a.jsx("article", {
                        className: "comment-item-nickname",
                        children: e.name
                    }), a.jsx("span", {
                        className: "comment-created-time",
                        children: SC(e.createdDate)
                    })]
                }), a.jsx("article", {
                    children: e.content
                })]
            }), a.jsxs("div", {
                className: "comment-item-menu-container",
                children: [a.jsx("div", {
                    className: "comment-item-siren-container",
                    onClick: t,
                    children: a.jsx("img", {
                        className: "comment-item-siren-icon",
                        src: "/images/etc/siren.png"
                    })
                }), a.jsx("div", {
                    className: "comment-item-delete-container",
                    onClick: n,
                    children: a.jsx("img", {
                        className: "comment-item-delete-icon",
                        src: "/images/etc/trashcan.png"
                    })
                })]
            })]
        })
    })
}
var Dc = new Map,
    As = new WeakMap,
    ep = 0,
    xC = void 0;

function NC(e) {
    return e ? (As.has(e) || (ep += 1, As.set(e, ep.toString())), As.get(e)) : "0"
}

function RC(e) {
    return Object.keys(e).sort().filter(t => e[t] !== void 0).map(t => `${t}_${t==="root"?NC(e.root):e[t]}`).toString()
}

function kC(e) {
    const t = RC(e);
    let n = Dc.get(t);
    if (!n) {
        const r = new Map;
        let o;
        const l = new IntersectionObserver(s => {
            s.forEach(i => {
                var u;
                const c = i.isIntersecting && o.some(f => i.intersectionRatio >= f);
                e.trackVisibility && typeof i.isVisible > "u" && (i.isVisible = c), (u = r.get(i.target)) == null || u.forEach(f => {
                    f(c, i)
                })
            })
        }, e);
        o = l.thresholds || (Array.isArray(e.threshold) ? e.threshold : [e.threshold || 0]), n = {
            id: t,
            observer: l,
            elements: r
        }, Dc.set(t, n)
    }
    return n
}

function AC(e, t, n = {}, r = xC) {
    if (typeof window.IntersectionObserver > "u" && r !== void 0) {
        const u = e.getBoundingClientRect();
        return t(r, {
            isIntersecting: r,
            target: e,
            intersectionRatio: typeof n.threshold == "number" ? n.threshold : 0,
            time: 0,
            boundingClientRect: u,
            intersectionRect: u,
            rootBounds: u
        }), () => {}
    }
    const {
        id: o,
        observer: l,
        elements: s
    } = kC(n), i = s.get(e) || [];
    return s.has(e) || s.set(e, i), i.push(t), l.observe(e),
        function() {
            i.splice(i.indexOf(t), 1), i.length === 0 && (s.delete(e), l.unobserve(e)), s.size === 0 && (l.disconnect(), Dc.delete(o))
        }
}

function TC({
    threshold: e,
    delay: t,
    trackVisibility: n,
    rootMargin: r,
    root: o,
    triggerOnce: l,
    skip: s,
    initialInView: i,
    fallbackInView: u,
    onChange: c
} = {}) {
    var f;
    const [d, g] = y.useState(null), S = y.useRef(), [v, _] = y.useState({
        inView: !!i,
        entry: void 0
    });
    S.current = c, y.useEffect(() => {
        if (s || !d) return;
        let h;
        return h = AC(d, (x, k) => {
            _({
                inView: x,
                entry: k
            }), S.current && S.current(x, k), k.isIntersecting && l && h && (h(), h = void 0)
        }, {
            root: o,
            rootMargin: r,
            threshold: e,
            trackVisibility: n,
            delay: t
        }, u), () => {
            h && h()
        }
    }, [Array.isArray(e) ? e.toString() : e, d, o, r, l, s, n, u, t]);
    const R = (f = v.entry) == null ? void 0 : f.target,
        p = y.useRef();
    !d && R && !l && !s && p.current !== R && (p.current = R, _({
        inView: !!i,
        entry: void 0
    }));
    const m = [g, v.inView, v.entry];
    return m.ref = m[0], m.inView = m[1], m.entry = m[2], m
}

function jC({
    isOpen: e,
    passwordInputHandler: t,
    okBtnHandler: n,
    cancelBtnHandler: r,
    isDeleteRequestValid: o,
    errorMsg: l,
    deleteForm: s
}) {
    return a.jsx(a.Fragment, {
        children: e && a.jsx("section", {
            className: "custom-modal-container",
            children: a.jsxs("div", {
                className: "custom-modal-root",
                children: [a.jsx("div", {
                    className: "custom-modal-header",
                    children: a.jsx("div", {
                        className: "custom-modal-title",
                        children: "댓글 삭제하기"
                    })
                }), a.jsxs("div", {
                    className: "custom-modal-body",
                    children: [a.jsx("div", {
                        className: "custom-modal-content",
                        children: a.jsxs("div", {
                            className: "custom-modal-dialog",
                            children: [a.jsx("article", {
                                className: "custom-modal-menu-title",
                                children: "비밀번호"
                            }), a.jsx("input", {
                                className: "custom-modal-input-element",
                                type: "password",
                                placeholder: "비밀번호를 입력하세요",
                                defaultValue: "",
                                value: s.password,
                                onChange: t
                            }), !o && a.jsx("span", {
                                className: "red",
                                children: l
                            })]
                        })
                    }), a.jsxs("div", {
                        className: "custom-modal-button-container",
                        children: [a.jsx("button", {
                            className: "custom-modal-button custom-modal-ok-button",
                            onClick: n,
                            children: "확인"
                        }), a.jsx("button", {
                            className: "custom-modal-button custom-modal-cancel-button",
                            onClick: r,
                            children: "취소"
                        })]
                    })]
                })]
            })
        })
    })
}

function CC({
    isOpen: e,
    okBtnHandler: t,
    cancelBtnHandler: n
}) {
    return a.jsx(a.Fragment, {
        children: e && a.jsx("section", {
            className: "custom-modal-container",
            children: a.jsxs("div", {
                className: "custom-modal-root",
                children: [a.jsx("div", {
                    className: "custom-modal-header",
                    children: a.jsx("div", {
                        className: "custom-modal-title text-center",
                        children: "댓글 신고"
                    })
                }), a.jsxs("div", {
                    className: "custom-modal-body",
                    children: [a.jsx("div", {
                        className: "custom-modal-content",
                        children: a.jsx("div", {
                            className: "custom-modal-dialog text-center",
                            children: a.jsx("article", {
                                className: "custom-modal-menu-title text-center",
                                children: "댓글을 신고하시겠습니까?"
                            })
                        })
                    }), a.jsxs("div", {
                        className: "custom-modal-button-container",
                        children: [a.jsx("button", {
                            className: "custom-modal-button custom-modal-ok-button",
                            onClick: t,
                            children: "확인"
                        }), a.jsx("button", {
                            className: "custom-modal-button custom-modal-cancel-button",
                            onClick: n,
                            children: "취소"
                        })]
                    })]
                })]
            })
        })
    })
}

function LC({
    itemId: e
}) {
    const [t, n] = y.useState([]), [r, o] = y.useState(-1), l = y.useRef(!1), [s, i] = y.useState(0), [u, c] = y.useState(gC), [f, d] = y.useState(!0), [g, S] = y.useState(!0), [v, _] = y.useState(!0), R = y.useRef(!0), [p, m] = y.useState(!1), [h, x] = y.useState(!1), [k, C] = y.useState(yC), [L, M] = y.useState(_C), [oe, H] = y.useState(!0), [ge, Ue] = y.useState(""), [de, Ne] = TC();
    y.useEffect(() => {
        ue.get(`${ze}/api/item/${e}/comment/count`).then(W => {
            const ee = W.data.count;
            i(ee)
        }).catch(W => {
            console.log(W)
        })
    }, []), y.useEffect(() => {
        Xe()
    }, [Ne]);

    function Xe() {
        !R.current || l.current || (l.current = !0, ue.get(`${ze}/api/item/${e}/comment?lastId=${r}&size=${Zm}`, {
            withCredentials: !0
        }).then(W => {
            const ee = W.data,
                ye = [...t, ...ee];
            n(ye), ee.length > 0 && o(ee[ee.length - 1].commentId), ee.length < Zm && (R.current = !1)
        }).catch(W => {
            console.log(W)
        }), l.current = !1)
    }

    function Re() {
        return u.content.length == 0 || u.content.length > 200 ? (d(!1), !1) : (d(!0), !0)
    }

    function Ve() {
        return u.name.length == 0 ? (S(!1), !1) : (S(!0), !0)
    }

    function I() {
        return u.password.length == 0 ? (_(!1), !1) : (_(!0), !0)
    }

    function Y() {
        const W = Re(),
            ee = Ve(),
            ye = I();
        return !(!W || !ee || !ye)
    }

    function b(W) {
        if (W.preventDefault(), !Y()) return;
        ue.post(`${ze}/api/item/${e}/comment`, u, {
            withCredentials: !0
        }).then(ye => {
            const Ee = ye.data,
                yt = {
                    commentId: Ee.commentId,
                    name: Ee.name,
                    content: u.content,
                    createdDate: Ee.createdDate
                };
            n([yt, ...t])
        }).catch(ye => {
            console.log(ye)
        });
        const ee = { ...u
        };
        ee.content = "", c(ee)
    }

    function q(W) {
        const ee = { ...u
        };
        ee.content = W.target.value, c(ee)
    }

    function E(W) {
        const ee = { ...u
        };
        ee.name = W.target.value, c(ee)
    }

    function P(W) {
        const ee = { ...u
        };
        ee.password = W.target.value, c(ee)
    }

    function O(W) {
        m(!0);
        const ee = { ...k
        };
        ee.commentId = W, C(ee)
    }

    function Q(W) {
        const ye = [...t].filter(Ee => Ee.commentId != W);
        n(ye)
    }

    function $() {
        ue.post(`${ze}/api/item/comment/delete`, k, {
            withCredentials: !0
        }).then(W => {
            H(!0), m(!1), Q(k.commentId), alert("댓글이 삭제되었습니다.")
        }).catch(W => {
            const ee = W.response.data.message;
            H(!1), Ue(ee)
        })
    }

    function ne(W) {
        W.preventDefault(), $()
    }

    function te(W) {
        W.preventDefault(), m(!1)
    }

    function G(W) {
        const ee = { ...k
        };
        ee.password = W.target.value, C(ee)
    }

    function me() {
        ue.post(`${ze}/api/item/comment/report`, L).then(W => {
            x(!1), alert("댓글이 신고되었습니다.")
        }).catch(W => {
            console.log(W), alert("요청에 실패하였습니다.")
        })
    }

    function Se(W) {
        const ee = { ...L
        };
        ee.commentId = W, x(!0), M(ee)
    }

    function ce(W) {
        W.preventDefault(), me()
    }

    function he(W) {
        W.preventDefault(), x(!1)
    }
    return a.jsxs(a.Fragment, {
        children: [a.jsxs("section", {
            className: "comment-container bg-light mx-3 mb-3 px-3 py-3",
            children: [a.jsxs("span", {
                className: "comment-area-title",
                children: ["댓글(", s, ")"]
            }), a.jsx("div", {
                className: "comment-content-root",
                children: a.jsxs("form", {
                    onSubmit: b,
                    children: [a.jsx("textarea", {
                        className: "comment-content-area",
                        placeholder: "내용을 입력하세요. (최대 200자)",
                        spellCheck: "false",
                        defaultValue: u.content,
                        value: u.content,
                        onChange: q
                    }), a.jsxs("div", {
                        className: "comment-user-info-input",
                        children: [a.jsxs("div", {
                            className: "comment-user-info",
                            children: [a.jsx("input", {
                                type: "text",
                                placeholder: "닉네임",
                                defaultValue: u.name,
                                value: u.name,
                                onChange: E
                            }), a.jsx("input", {
                                type: "password",
                                placeholder: "비밀번호",
                                defaultValue: u.password,
                                value: u.password,
                                onChange: P
                            })]
                        }), a.jsx("button", {
                            type: "submit",
                            children: "작성하기"
                        })]
                    })]
                })
            }), a.jsxs("div", {
                className: "comment-error-container",
                children: [!g && a.jsx("div", {
                    children: a.jsx("span", {
                        className: "red",
                        children: "이름을 입력해주세요."
                    })
                }), !v && a.jsx("div", {
                    children: a.jsx("span", {
                        className: "red",
                        children: "패스워드를 입력해주세요."
                    })
                }), !f && a.jsx("div", {
                    children: a.jsx("span", {
                        className: "red",
                        children: "댓글은 1~200자를 입력해야합니다."
                    })
                })]
            }), a.jsxs("section", {
                className: "single-comment-container mt-2",
                children: [t.map(W => a.jsx(EC, {
                    info: W,
                    handleReport: () => Se(W.commentId),
                    handleDelete: () => O(W.commentId)
                }, `comment_${e}_${W.commentId}`)), a.jsx("div", {
                    ref: de,
                    style: {
                        height: "10px"
                    }
                })]
            })]
        }), a.jsx(jC, {
            isOpen: p,
            passwordInputHandler: G,
            okBtnHandler: ne,
            cancelBtnHandler: te,
            isDeleteRequestValid: oe,
            errorMsg: ge,
            deleteForm: k
        }), a.jsx(CC, {
            isOpen: h,
            okBtnHandler: ce,
            cancelBtnHandler: he
        })]
    })
}

function DC({
    itemId: e,
    info: t
}) {
    var i;
    const [n, r] = y.useState(MT), o = t == null ? void 0 : t.status;
    y.useEffect(() => {
        l()
    }, []);

    function l() {
        ue.get(`${ze}/api/item/${e}/enhanced`, {
            withCredentials: !0
        }).then(u => {
            r(u.data)
        }).catch(u => {
            console.log(u)
        })
    }

    function s() {
        const u = n.iev;
        return u >= 0 && u <= 5 ? "orange" : u >= 6 && u <= 22 ? "blue" : u >= 23 && u <= 39 ? "purple" : u >= 40 && u <= 56 ? "yellow" : u >= 57 && u <= 73 ? "green" : u > 73 ? "primary-red" : "white"
    }
    return a.jsx(a.Fragment, {
        children: a.jsxs("main", {
            className: "item-best-record-root bg-light mx-3 mb-3 py-2 px-3",
            children: [a.jsxs("span", {
                className: "item-best-record-title",
                children: ["최고기록", ((i = n == null ? void 0 : n.name) == null ? void 0 : i.length) > 0 && ` (이름: ${n.name})`]
            }), a.jsx("div", {
                className: "best-record-container",
                children: a.jsx("section", {
                    className: "item-info-section-container black-border",
                    children: a.jsxs("section", {
                        className: "item-info-section",
                        children: [a.jsxs("span", {
                            className: `item-info-name ${s()}`,
                            children: [t == null ? void 0 : t.name, n.success.total > 0 && `(+${n.success.total})`]
                        }), a.jsxs("div", {
                            className: "item-info-basic",
                            children: [a.jsx("div", {
                                className: "item-img-container",
                                children: a.jsx("img", {
                                    className: "item-img",
                                    src: `/images/item/${e}.png`
                                })
                            }), a.jsxs("div", {
                                className: "item-info-required",
                                children: [a.jsx(jt, {
                                    name: "LEV",
                                    value: t == null ? void 0 : t.required.level
                                }), a.jsx(jt, {
                                    name: "STR",
                                    value: t == null ? void 0 : t.required.str
                                }), a.jsx(jt, {
                                    name: "DEX",
                                    value: t == null ? void 0 : t.required.dex
                                }), a.jsx(jt, {
                                    name: "INT",
                                    value: t == null ? void 0 : t.required.intel
                                }), a.jsx(jt, {
                                    name: "LUK",
                                    value: t == null ? void 0 : t.required.luk
                                }), a.jsx(jt, {
                                    name: "POP",
                                    value: t == null ? void 0 : t.required.pop
                                }), a.jsx("span", {
                                    className: "item-useless-info",
                                    children: "ITEM LEV : -"
                                }), a.jsx("span", {
                                    className: "item-useless-info",
                                    children: "ITEM EXP : -"
                                })]
                            })]
                        }), a.jsxs("div", {
                            className: "item-info-job",
                            children: [a.jsx("span", {
                                className: t != null && t.job.common ? "" : "red",
                                children: "초보자"
                            }), a.jsx("span", {
                                className: t != null && t.job.warrior || t != null && t.job.common ? "" : "red",
                                children: "전사"
                            }), a.jsx("span", {
                                className: t != null && t.job.magician || t != null && t.job.common ? "" : "red",
                                children: "마법사"
                            }), a.jsx("span", {
                                className: t != null && t.job.bowman || t != null && t.job.common ? "" : "red",
                                children: "궁수"
                            }), a.jsx("span", {
                                className: t != null && t.job.thief || t != null && t.job.common ? "" : "red",
                                children: "도적"
                            }), a.jsx("span", {
                                className: t != null && t.job.common ? "" : "red",
                                children: "해적"
                            })]
                        }), a.jsx("hr", {}), a.jsxs("div", {
                            className: "item-info-status",
                            children: [a.jsxs("span", {
                                children: ["장비분류 : ", gy.get(t == null ? void 0 : t.category)]
                            }), (t == null ? void 0 : t.attackSpeed) !== null && (t == null ? void 0 : t.attackSpeed) !== "NONE" && a.jsxs("span", {
                                children: ["공격속도 : ", yy.get(t == null ? void 0 : t.attackSpeed)]
                            }), (o == null ? void 0 : o.str.normal) + n.status.str > 0 && a.jsxs("span", {
                                children: ["STR : +", (o == null ? void 0 : o.str.normal) + n.status.str]
                            }), (o == null ? void 0 : o.dex.normal) + n.status.dex > 0 && a.jsxs("span", {
                                children: ["DEX : +", (o == null ? void 0 : o.dex.normal) + n.status.dex]
                            }), (o == null ? void 0 : o.intel.normal) + n.status.intel > 0 && a.jsxs("span", {
                                children: ["INT : +", (o == null ? void 0 : o.intel.normal) + n.status.intel]
                            }), (o == null ? void 0 : o.luk.normal) + n.status.luk > 0 && a.jsxs("span", {
                                children: ["LUK : +", (o == null ? void 0 : o.luk.normal) + n.status.luk]
                            }), (o == null ? void 0 : o.acc.normal) + n.status.acc > 0 && a.jsxs("span", {
                                children: ["명중률 : +", (o == null ? void 0 : o.acc.normal) + n.status.acc]
                            }), (o == null ? void 0 : o.avo.normal) + n.status.avo > 0 && a.jsxs("span", {
                                children: ["회피율 : +", (o == null ? void 0 : o.avo.normal) + n.status.avo]
                            }), (o == null ? void 0 : o.phyAtk.normal) + n.status.phyAtk > 0 && a.jsxs("span", {
                                children: ["공격력 : +", (o == null ? void 0 : o.phyAtk.normal) + n.status.phyAtk]
                            }), (o == null ? void 0 : o.mgAtk.normal) + n.status.mgAtk > 0 && a.jsxs("span", {
                                children: ["마력 : +", (o == null ? void 0 : o.mgAtk.normal) + n.status.mgAtk]
                            }), (o == null ? void 0 : o.phyDef.normal) + n.status.phyDef > 0 && a.jsxs("span", {
                                children: ["물리방어력 : +", (o == null ? void 0 : o.phyDef.normal) + n.status.phyDef]
                            }), (o == null ? void 0 : o.mgDef.normal) + n.status.mgDef > 0 && a.jsxs("span", {
                                children: ["마법방어력 : +", (o == null ? void 0 : o.mgDef.normal) + n.status.mgDef]
                            }), (o == null ? void 0 : o.hp.normal) + n.status.hp > 0 && a.jsxs("span", {
                                children: ["HP : +", (o == null ? void 0 : o.hp.normal) + n.status.hp]
                            }), (o == null ? void 0 : o.mp.normal) + n.status.mp > 0 && a.jsxs("span", {
                                children: ["MP : +", (o == null ? void 0 : o.mp.normal) + n.status.mp]
                            }), (o == null ? void 0 : o.move.normal) + n.status.move > 0 && a.jsxs("span", {
                                children: ["이동속도 : +", (o == null ? void 0 : o.move.normal) + n.status.move]
                            }), (o == null ? void 0 : o.jump.normal) + n.status.jump > 0 && a.jsxs("span", {
                                children: ["점프력 : +", (o == null ? void 0 : o.jump.normal) + n.status.jump]
                            }), (t == null ? void 0 : t.knockBackPercent) > 0 && a.jsxs("span", {
                                children: ["직접 타격시 넉백 확률 : +", t == null ? void 0 : t.knockBackPercent, "%"]
                            }), a.jsx("span", {
                                children: "업그레이드 가능 횟수 : 0"
                            })]
                        })]
                    })
                })
            }), a.jsx("section", {
                className: "success-scroll-root",
                children: a.jsxs("div", {
                    className: "success-scroll-container",
                    children: [a.jsxs("div", {
                        className: "success-single-scroll-container",
                        children: [a.jsx("img", {
                            src: "/images/scroll/10.png"
                        }), a.jsxs("span", {
                            children: [" × ", n.success.ten]
                        })]
                    }), a.jsxs("div", {
                        className: "success-single-scroll-container",
                        children: [a.jsx("img", {
                            src: "/images/scroll/60.png"
                        }), a.jsxs("span", {
                            children: [" × ", n.success.sixty]
                        })]
                    }), a.jsxs("div", {
                        className: "success-single-scroll-container",
                        children: [a.jsx("img", {
                            src: "/images/scroll/100.png"
                        }), a.jsxs("span", {
                            children: [" × ", n.success.hundred]
                        })]
                    })]
                })
            }), a.jsx("span", {
                className: "item-record-comment",
                children: "※ 기록은 아이템 정옵 기준으로 등록됩니다"
            })]
        })
    })
}
let Ts = null;

function PC() {
    var Xl, Jl;
    const {
        itemId: e
    } = Zk(), t = y.useRef([]), [n, r] = y.useState(null), [o, l] = y.useState(null), [s, i] = y.useState(0), [u, c] = y.useState("WAND_MG_ATK"), [f, d] = y.useState(Xm), [g, S] = y.useState(0), [v, _] = y.useState(0), [R, p] = y.useState(0), [m, h] = y.useState(0), [x, k] = y.useState(0), [C, L] = y.useState(0), [M, oe] = y.useState(0), [H, ge] = y.useState(0), [Ue, de] = y.useState(0), [Ne, Xe] = y.useState(0), [Re, Ve] = y.useState(0), [I, Y] = y.useState(0), [b, q] = y.useState(0), [E, P] = y.useState(0), [O, Q] = y.useState(0), [$, ne] = y.useState(0), te = y.useRef(0), G = y.useRef(0), me = y.useRef(0), Se = y.useRef(0), ce = y.useRef(0), he = y.useRef(0), W = y.useRef(0), ee = y.useRef(0), ye = y.useRef(0), Ee = y.useRef(0), yt = y.useRef(0), rn = y.useRef(0), ct = y.useRef(0), Rt = y.useRef(0), Sn = y.useRef(0), [Rr, wn] = y.useState(0), [En, xn] = y.useState(1), [kr, Ar] = y.useState(0), [Tr, er] = y.useState(0), [wo, Nn] = y.useState(0), [jr, Cr] = y.useState(0), [N, w] = y.useState(0), [j, F] = y.useState(0), [V, B] = y.useState(0), [J, X] = y.useState(0), [Z, re] = y.useState(0), _e = y.useRef(), $e = y.useRef(), Le = y.useRef(), Ke = y.useRef(), Je = y.useRef(), [It, Kt] = y.useState(!1), [kt, on] = y.useState(""), [Vl, di] = y.useState(!1);
    async function $l() {
        var K;
        try {
            const le = await ue.get(`${ze}/api/item/${e}`, {
                    withCredentials: !0
                }),
                ae = le.data,
                U = JSON.parse(JSON.stringify(ae));
            l({ ...le.data
            }), r(ae), S(U.status.str.normal), _(U.status.dex.normal), p(U.status.intel.normal), h(U.status.luk.normal), k(U.status.phyAtk.normal), L(U.status.mgAtk.normal), oe(U.status.phyDef.normal), ge(U.status.mgDef.normal), de(U.status.acc.normal), Xe(U.status.avo.normal), Ve(U.status.move.normal), Y(U.status.jump.normal), q(U.status.hp.normal), P(U.status.mp.normal), Q(U.upgradableCount), ne(U.knockBackPercent), te.current = U.status.str.normal, G.current = U.status.dex.normal, me.current = U.status.intel.normal, Se.current = U.status.luk.normal, ce.current = U.status.phyAtk.normal, he.current = U.status.mgAtk.normal, W.current = U.status.phyDef.normal, ee.current = U.status.mgDef.normal, ye.current = U.status.acc.normal, Ee.current = U.status.avo.normal, yt.current = U.status.move.normal, rn.current = U.status.jump.normal, ct.current = U.status.hp.normal, Rt.current = U.status.mp.normal, Sn.current = U.upgradableCount;
            for (let sn = 0; sn < (Rs == null ? void 0 : Rs.length); sn++) {
                const Zl = Rs[sn];
                Or.get(Zl).category === ae.category && (t.current = [...t.current, Or.get(Zl)])
            }((K = t.current) == null ? void 0 : K.length) > 0 && c(t.current[0])
        } catch (le) {
            console.log(le)
        }
    }
    y.useEffect(() => {
        $l()
    }, []);

    function fi(K) {
        c(() => Or.get(K.target.value))
    }

    function ln(K) {
        mi() && (Hl(K) ? hi(K) : zl(), K === 10 ? er(le => le + 1) : K === 60 ? w(le => le + 1) : K === 100 && X(le => le + 1), Q(le => le - 1))
    }

    function mi() {
        return !(O <= 0)
    }

    function Hl(K) {
        const le = K / 10;
        let ae = Math.floor(Math.random() * 10 + 1);
        return ae >= 1 && ae <= le
    }

    function pi() {
        d(Xm)
    }

    function Bl(K) {
        const le = { ...f
        };
        le.total += 1, K === 10 ? le.ten += 1 : K === 60 ? le.sixty += 1 : K === 100 && (le.hundred += 1), d(le)
    }

    function hi(K) {
        zT(), xi(), Bl(K), K === 10 ? Nn(ae => ae + 1) : K === 60 ? F(ae => ae + 1) : K === 100 && re(ae => ae + 1);
        let le = null;
        K === 10 ? le = Or.get(u.keyword).upgradeValue._10 : K === 60 ? le = Or.get(u.keyword).upgradeValue._60 : K === 100 && (le = Or.get(u.keyword).upgradeValue._100), le == null || le.map(ae => {
            switch (ae.name) {
                case "str":
                    S(U => U + ae.value);
                    break;
                case "dex":
                    _(U => U + ae.value);
                    break;
                case "intel":
                    p(U => U + ae.value);
                    break;
                case "luk":
                    h(U => U + ae.value);
                    break;
                case "phyAtk":
                    k(U => U + ae.value);
                    break;
                case "mgAtk":
                    L(U => U + ae.value);
                    break;
                case "phyDef":
                    oe(U => U + ae.value);
                    break;
                case "mgDef":
                    ge(U => U + ae.value);
                    break;
                case "acc":
                    de(U => U + ae.value);
                    break;
                case "avo":
                    Xe(U => U + ae.value);
                    break;
                case "move":
                    Ve(U => U + ae.value);
                    break;
                case "jump":
                    Y(U => U + ae.value);
                    break;
                case "hp":
                    q(U => U + ae.value);
                    break;
                case "mp":
                    P(U => U + ae.value);
                    break
            }
        }), i(ae => ae + 1)
    }

    function zl() {
        BT(), Ni()
    }
    const vi = K => {
            K.preventDefault(), wn(K.target.value)
        },
        Wl = y.useCallback(K => {
            Ar(K.target.value)
        }, []),
        gi = y.useCallback(K => {
            Cr(K.target.value)
        }, []),
        Kl = y.useCallback(K => {
            B(K.target.value)
        }, []);

    function yi(K, le) {
        const ae = le,
            U = Number(K.target.value);
        switch (ae) {
            case "str":
                te.current = U;
                break;
            case "dex":
                G.current = U;
                break;
            case "intel":
                me.current = U;
                break;
            case "luk":
                Se.current = U;
                break;
            case "phyAtk":
                ce.current = U;
                break;
            case "mgAtk":
                he.current = U;
                break;
            case "phyDef":
                W.current = U;
                break;
            case "mgDef":
                ee.current = U;
                break;
            case "hp":
                ct.current = U;
                break;
            case "mp":
                Rt.current = U;
                break;
            case "avo":
                Ee.current = U;
                break;
            case "acc":
                ye.current = U;
                break;
            case "move":
                yt.current = U;
                break;
            case "jump":
                rn.current = U;
                break
        }
        Lr(), xn(sn => sn - 1)
    }

    function Lr() {
        _i(), pi(), xn(K => K + 1), i(0)
    }

    function _i() {
        S(te.current), _(G.current), p(me.current), h(Se.current), k(ce.current), L(he.current), oe(W.current), ge(ee.current), de(ye.current), Xe(Ee.current), Ve(yt.current), Y(rn.current), q(ct.current), P(Rt.current), Q(Sn.current)
    }

    function Eo() {
        KT(), Lr()
    }

    function Gl() {
        WT(), Lr(), xn(1), er(0), w(0), X(0), Nn(0), F(0), re(0)
    }

    function Si() {
        const K = Yl();
        return K >= 0 && K <= 5 ? s === 0 ? "white" : "orange" : K >= 6 && K <= 22 ? "blue" : K >= 23 && K <= 39 ? "purple" : K >= 40 && K <= 56 ? "yellow" : K >= 57 && K <= 73 ? "green" : "white"
    }
    qt("q", () => {
        _e.current.focus(), ln(10)
    }, {
        keyup: !1,
        keydown: !0
    }), qt("w", () => {
        $e.current.focus(), ln(60)
    }, {
        keyup: !1,
        keydown: !0
    }), qt("e", () => {
        Le.current.focus(), ln(100)
    }, {
        keyup: !1,
        keydown: !0
    }), qt("r", () => {
        Ke.current.focus(), Eo()
    }, {
        keyup: !1,
        keydown: !0
    }), qt("f", () => {
        Je.current.focus(), Gl()
    }, {
        keyup: !1,
        keydown: !0
    }), qt("q", () => {
        _e.current.blur()
    }, {
        keyup: !0,
        keydown: !1
    }), qt("w", () => {
        $e.current.blur()
    }, {
        keyup: !0,
        keydown: !1
    }), qt("e", () => {
        Le.current.blur()
    }, {
        keyup: !0,
        keydown: !1
    }), qt("r", () => {
        Ke.current.blur()
    }, {
        keyup: !0,
        keydown: !1
    }), qt("f", () => {
        Je.current.blur()
    }, {
        keyup: !0,
        keydown: !1
    });
    const tr = y.useRef(),
        ql = "/images/etc/empty.png",
        wi = "/images/etc/gif/success-150.gif",
        Ei = "/images/etc/gif/failure-150.gif";

    function xi() {
        clearTimeout(Ts), tr.current.src = wi, Ts = setTimeout(function() {
            tr.current.src = ql
        }, 900)
    }

    function Ni() {
        clearTimeout(Ts), tr.current.src = Ei, Ts = setTimeout(function() {
            tr.current.src = ql
        }, 600)
    }

    function Yl() {
        let K = [te.current, G.current, me.current, Se.current, ce.current, he.current, W.current, ee.current, ye.current, Ee.current, yt.current, rn.current, ct.current, Rt.current].reduce((ae, U, sn) => ae += U),
            le = [g, v, R, m, x, C, M, H, Ue, Ne, Re, I, b, E].reduce((ae, U, sn) => ae += U);
        return K = K - (ct.current + Rt.current) + ct.current / 10 + Rt.current / 10, le = le - (b + E) + b / 10 + E / 10, le - K
    }
    const [Ri, Rn] = y.useState(!1), [ki, Ql] = y.useState(!1);

    function Ai() {
        Kt(!0)
    }

    function Ti() {
        return {
            name: kt,
            upgradable: o.upgradableCount,
            iev: Yl(),
            scroll: u.keyword,
            success: f,
            status: {
                str: g - te.current,
                dex: v - G.current,
                intel: R - me.current,
                luk: m - Se.current,
                phyAtk: x - ce.current,
                mgAtk: C - he.current,
                phyDef: M - W.current,
                mgDef: H - ee.current,
                acc: Ue - ye.current,
                avo: Ne - Ee.current,
                move: Re - yt.current,
                jump: I - rn.current,
                hp: b - ct.current,
                mp: E - Rt.current
            }
        }
    }

    function ji() {
        if (kt === "") {
            di(!0);
            return
        }
        const K = Ti();
        ue.post(`${ze}/api/item/${e}/enhanced`, K, {
            withCredentials: !0
        }).then(le => {
            const ae = le.data.status;
            Rn(!0), Ql(ae === "SUCCESS")
        }).catch(le => {
            console.log(le)
        }), Kt(!1)
    }

    function Ci() {
        Kt(!1)
    }

    function Li(K) {
        on(K.target.value)
    }

    function Di() {
        Rn(!1)
    }
    return a.jsxs(a.Fragment, {
        children: [a.jsxs("section", {
            className: "shorcut-guide-section bg-success",
            children: [a.jsx("span", {
                className: "shortcut-title",
                children: "단축키"
            }), a.jsxs("div", {
                className: "shortcut-info",
                children: [a.jsx(Mo, {
                    description: "Q-10%적용"
                }), a.jsx(Mo, {
                    description: "W-60%적용"
                }), a.jsx(Mo, {
                    description: "E-100%적용"
                }), a.jsx(Mo, {
                    description: "R-아이템 리셋"
                }), a.jsx(Mo, {
                    description: "F-구매기록 리셋"
                })]
            })]
        }), a.jsxs("section", {
            className: "item-simulator-root",
            children: [a.jsxs("main", {
                className: "item-simulator-section bg-light  my-3 mx-3 py-3 px-3",
                children: [a.jsxs("section", {
                    className: "item-info-and-overflow-message",
                    children: [a.jsx("section", {
                        className: "item-info-section-container",
                        children: a.jsxs("section", {
                            className: "item-info-section mx-1",
                            children: [a.jsxs("span", {
                                className: `item-info-name ${Si()}`,
                                children: [n == null ? void 0 : n.name, s != null && s > 0 && `(+${s})`]
                            }), a.jsxs("div", {
                                className: "item-info-basic",
                                children: [a.jsxs("div", {
                                    className: "item-img-container",
                                    children: [a.jsx("img", {
                                        className: "item-img",
                                        src: `/images/item/${e}.png`
                                    }), a.jsx("img", {
                                        ref: tr,
                                        src: "/images/etc/empty.png",
                                        className: "scroll-animation",
                                        id: "scroll-animation"
                                    })]
                                }), a.jsxs("div", {
                                    className: "item-info-required",
                                    children: [a.jsx(jt, {
                                        name: "LEV",
                                        value: n == null ? void 0 : n.required.level
                                    }), a.jsx(jt, {
                                        name: "STR",
                                        value: n == null ? void 0 : n.required.str
                                    }), a.jsx(jt, {
                                        name: "DEX",
                                        value: n == null ? void 0 : n.required.dex
                                    }), a.jsx(jt, {
                                        name: "INT",
                                        value: n == null ? void 0 : n.required.intel
                                    }), a.jsx(jt, {
                                        name: "LUK",
                                        value: n == null ? void 0 : n.required.luk
                                    }), a.jsx(jt, {
                                        name: "POP",
                                        value: n == null ? void 0 : n.required.pop
                                    }), a.jsx("span", {
                                        className: "item-useless-info",
                                        children: "ITEM LEV : -"
                                    }), a.jsx("span", {
                                        className: "item-useless-info",
                                        children: "ITEM EXP : -"
                                    })]
                                })]
                            }), a.jsxs("div", {
                                className: "item-info-job",
                                children: [a.jsx("span", {
                                    className: n != null && n.job.common ? "" : "red",
                                    children: "초보자"
                                }), a.jsx("span", {
                                    className: n != null && n.job.warrior || n != null && n.job.common ? "" : "red",
                                    children: "전사"
                                }), a.jsx("span", {
                                    className: n != null && n.job.magician || n != null && n.job.common ? "" : "red",
                                    children: "마법사"
                                }), a.jsx("span", {
                                    className: n != null && n.job.bowman || n != null && n.job.common ? "" : "red",
                                    children: "궁수"
                                }), a.jsx("span", {
                                    className: n != null && n.job.thief || n != null && n.job.common ? "" : "red",
                                    children: "도적"
                                }), a.jsx("span", {
                                    className: n != null && n.job.common ? "" : "red",
                                    children: "해적"
                                })]
                            }), a.jsx("hr", {}), a.jsxs("div", {
                                className: "item-info-status",
                                children: [a.jsxs("span", {
                                    children: ["장비분류 : ", gy.get(n == null ? void 0 : n.category)]
                                }), (n == null ? void 0 : n.attackSpeed) !== null && (n == null ? void 0 : n.attackSpeed) !== "NONE" && a.jsxs("span", {
                                    children: ["공격속도 : ", yy.get(n == null ? void 0 : n.attackSpeed)]
                                }), g > 0 && a.jsxs("span", {
                                    children: ["STR : +", g]
                                }), v > 0 && a.jsxs("span", {
                                    children: ["DEX : +", v]
                                }), R > 0 && a.jsxs("span", {
                                    children: ["INT : +", R]
                                }), m > 0 && a.jsxs("span", {
                                    children: ["LUK : +", m]
                                }), Ue > 0 && a.jsxs("span", {
                                    children: ["명중률 : +", Ue]
                                }), Ne > 0 && a.jsxs("span", {
                                    children: ["회피율 : +", Ne]
                                }), x > 0 && a.jsxs("span", {
                                    children: ["공격력 : +", x]
                                }), C > 0 && a.jsxs("span", {
                                    children: ["마력 : +", C]
                                }), M > 0 && a.jsxs("span", {
                                    children: ["물리방어력 : +", M]
                                }), H > 0 && a.jsxs("span", {
                                    children: ["마법방어력 : +", H]
                                }), b > 0 && a.jsxs("span", {
                                    children: ["HP : +", b]
                                }), E > 0 && a.jsxs("span", {
                                    children: ["MP : +", E]
                                }), Re > 0 && a.jsxs("span", {
                                    children: ["이동속도 : +", Re]
                                }), I > 0 && a.jsxs("span", {
                                    children: ["점프력 : +", I]
                                }), $ > 0 && a.jsxs("span", {
                                    children: ["직접 타격시 넉백 확률 : +", $, "%"]
                                }), a.jsxs("span", {
                                    children: ["업그레이드 가능 횟수 : ", O]
                                })]
                            })]
                        })
                    }), a.jsx("section", {
                        className: "overflow-message",
                        children: O <= 0 && a.jsx("span", {
                            className: "d-flex red scroll-overflow-msg",
                            children: "강화 횟수를 초과하였습니다"
                        })
                    }), a.jsx("section", {
                        className: "item-record-challenge-section",
                        children: a.jsx("button", {
                            className: "item-record-challenge-btn",
                            onClick: Ai,
                            onMouseUp: () => document.activeElement.blur(),
                            children: "기록 도전"
                        })
                    })]
                }), a.jsx("div", {
                    children: a.jsx("section", {
                        className: "d-flex justify-content-center",
                        children: a.jsxs("section", {
                            className: "item-controller-section mx-1",
                            children: [a.jsx("select", {
                                className: "form-select form-select-sm",
                                onChange: K => fi(K),
                                defaultValue: u,
                                children: (t == null ? void 0 : t.current) != null && ((Xl = t.current) == null ? void 0 : Xl.length) > 0 && ((Jl = t.current) == null ? void 0 : Jl.map(K => {
                                    if (K === void 0) return;
                                    const le = K.keyword;
                                    return a.jsx("option", {
                                        value: le,
                                        children: K.name
                                    }, `${le}`)
                                }))
                            }), a.jsx("section", {
                                className: "option-select-container",
                                children: a.jsx(hC, {
                                    statusInfo: n == null ? void 0 : n.status,
                                    optionSelectHandler: yi
                                })
                            }), a.jsxs("div", {
                                className: "scroll-select",
                                children: [a.jsx(Su, {
                                    ref: _e,
                                    percent: 10,
                                    currentScroll: u,
                                    onClick: ln
                                }), a.jsx(Su, {
                                    ref: $e,
                                    percent: 60,
                                    currentScroll: u,
                                    onClick: ln
                                }), a.jsx(Su, {
                                    ref: Le,
                                    percent: 100,
                                    currentScroll: u,
                                    onClick: ln
                                }), a.jsx("div", {
                                    className: "scroll-info",
                                    children: a.jsx("button", {
                                        ref: Ke,
                                        onClick: Eo,
                                        id: "reset-button",
                                        onMouseUp: () => document.activeElement.blur(),
                                        children: a.jsx("img", {
                                            src: "/images/etc/reset.png"
                                        })
                                    })
                                })]
                            }), a.jsxs("div", {
                                className: "item-price-info",
                                children: [a.jsx(ks, {
                                    isScroll: !1,
                                    price: Rr,
                                    buyCount: En,
                                    inputHandler: vi
                                }, "item-price"), a.jsx(ks, {
                                    isScroll: !0,
                                    percent: 10,
                                    price: kr,
                                    buyCount: Tr,
                                    successCount: wo,
                                    inputHandler: Wl
                                }, "scroll-price-10"), a.jsx(ks, {
                                    isScroll: !0,
                                    percent: 60,
                                    price: jr,
                                    buyCount: N,
                                    successCount: j,
                                    inputHandler: gi
                                }, "scroll-price-60"), a.jsx(ks, {
                                    isScroll: !0,
                                    percent: 100,
                                    price: V,
                                    buyCount: J,
                                    successCount: Z,
                                    inputHandler: Kl
                                }, "scroll-price-100"), a.jsxs("section", {
                                    className: "total-price-info-section",
                                    children: [a.jsxs("div", {
                                        className: "total-price-info",
                                        children: [a.jsx("img", {
                                            src: "/images/etc/meso.png"
                                        }), a.jsx("span", {
                                            children: (En * Rr + Tr * kr + N * jr + J * V).toLocaleString()
                                        })]
                                    }), a.jsx("button", {
                                        ref: Je,
                                        className: "total-price-reset-btn",
                                        id: "purchase-reset-button",
                                        onClick: Gl,
                                        onMouseUp: () => document.activeElement.blur(),
                                        children: "구매기록 리셋"
                                    })]
                                })]
                            })]
                        })
                    })
                })]
            }), a.jsx(DC, {
                itemId: e,
                info: o
            })]
        }), It && a.jsx("div", {
            className: "custom-modal-container",
            children: a.jsxs("div", {
                className: "custom-modal-root",
                children: [a.jsx("div", {
                    className: "custom-modal-header",
                    children: a.jsx("div", {
                        className: "custom-modal-title text-center",
                        children: "기록으로 등록하시겠습니까?"
                    })
                }), a.jsxs("div", {
                    className: "custom-modal-body",
                    children: [a.jsx("div", {
                        className: "custom-modal-content",
                        children: a.jsxs("div", {
                            className: "custom-modal-dialog",
                            children: [a.jsxs("article", {
                                className: "custom-modal-menu-title",
                                children: ["이름", a.jsx("span", {
                                    className: "red",
                                    children: " (※ 부적절한 이름 입력 시 삭제처리 됩니다.)"
                                })]
                            }), a.jsx("input", {
                                className: "custom-modal-input-element",
                                type: "text",
                                placeholder: "이름을 입력하세요.",
                                defaultValue: "",
                                value: kt,
                                onChange: Li
                            }), Vl && a.jsx("span", {
                                className: "red",
                                children: "이름을 입력해주세요"
                            })]
                        })
                    }), a.jsxs("div", {
                        className: "custom-modal-button-container",
                        children: [a.jsx("button", {
                            className: "custom-modal-button custom-modal-ok-button",
                            onClick: ji,
                            children: "예"
                        }), a.jsx("button", {
                            className: "custom-modal-button custom-modal-cancel-button",
                            onClick: Ci,
                            children: "아니오"
                        })]
                    })]
                })]
            })
        }), Ri && a.jsx("div", {
            className: "custom-modal-container",
            children: a.jsxs("div", {
                className: "custom-modal-root",
                children: [a.jsx("div", {
                    className: "custom-modal-header",
                    children: a.jsx("div", {
                        className: "custom-modal-title text-center",
                        children: "도전 결과"
                    })
                }), a.jsxs("div", {
                    className: "custom-modal-body",
                    children: [a.jsx("div", {
                        className: "custom-modal-content",
                        children: a.jsx("div", {
                            className: "text-center",
                            children: ki ? "등록에 성공하였습니다!" : "등록에 실패했습니다. 더 좋은 아이템을 만들어보세요!"
                        })
                    }), a.jsx("div", {
                        className: "custom-modal-button-container",
                        children: a.jsx("button", {
                            className: "custom-modal-button custom-modal-ok-button",
                            onClick: Di,
                            children: "예"
                        })
                    })]
                })]
            })
        }), a.jsx(LC, {
            itemId: e
        })]
    })
}

function Uo({
    jobId: e,
    name: t,
    value: n,
    selectHandler: r
}) {
    return a.jsxs("div", {
        className: "form-check form-check-inline",
        children: [a.jsx("input", {
            className: "form-check-input",
            type: "checkbox",
            id: e,
            value: n,
            onClick: r
        }), a.jsx("label", {
            className: "form-check-label",
            htmlFor: e,
            children: t
        })]
    })
}

function OC() {
    si();
    const [e, t] = y.useState(1), [n, r] = y.useState(""), [o, l] = y.useState(0), [s, i] = y.useState(0), [u, c] = y.useState(0), [f, d] = y.useState(0), [g, S] = y.useState(0), [v, _] = y.useState(0), [R, p] = y.useState({
        common: !1,
        warrior: !1,
        bowman: !1,
        magician: !1,
        thief: !1
    }), [m, h] = y.useState("ONE_HANDED_SWORD"), [x, k] = y.useState(0), [C, L] = y.useState(0), [M, oe] = y.useState(0), [H, ge] = y.useState(0), [Ue, de] = y.useState(0), [Ne, Xe] = y.useState(0), [Re, Ve] = y.useState(0), [I, Y] = y.useState(0), [b, q] = y.useState(0), [E, P] = y.useState(0), [O, Q] = y.useState(0), [$, ne] = y.useState(0), [te, G] = y.useState(0), [me, Se] = y.useState(0), [ce, he] = y.useState(0), [W, ee] = y.useState(0), [ye, Ee] = y.useState(0), [yt, rn] = y.useState(0), [ct, Rt] = y.useState(0), [Sn, Rr] = y.useState(0), [wn, En] = y.useState(0), [xn, kr] = y.useState(0), [Ar, Tr] = y.useState(0), [er, wo] = y.useState(0), [Nn, jr] = y.useState(0), [Cr, N] = y.useState(0), [w, j] = y.useState(0), [F, V] = y.useState(0), [B, J] = y.useState(0), [X, Z] = y.useState(0), [re, _e] = y.useState(0), [$e, Le] = y.useState(0), [Ke, Je] = y.useState(0), [It, Kt] = y.useState(0), [kt, on] = y.useState(0), [Vl, di] = y.useState(0), [$l, fi] = y.useState(0), [ln, mi] = y.useState(0), [Hl, pi] = y.useState(0), [Bl, hi] = y.useState(0), [zl, vi] = y.useState(0), [Wl, gi] = y.useState(0), [Kl, yi] = y.useState("NORMAL"), [Lr, _i] = y.useState(7), [Eo, Gl] = y.useState(0), Si = T => {
        T.preventDefault();
        const nr = {
            id: e,
            name: n,
            requiredJob: R,
            required: {
                level: o,
                str: s,
                dex: u,
                intel: f,
                luk: g,
                pop: v
            },
            category: m,
            status: {
                str: {
                    normal: x,
                    lower: C,
                    upper: M
                },
                dex: {
                    normal: H,
                    lower: Ue,
                    upper: Ne
                },
                intel: {
                    normal: Re,
                    lower: I,
                    upper: b
                },
                luk: {
                    normal: E,
                    lower: O,
                    upper: $
                },
                phyAtk: {
                    normal: te,
                    lower: me,
                    upper: ce
                },
                mgAtk: {
                    normal: W,
                    lower: ye,
                    upper: yt
                },
                phyDef: {
                    normal: ct,
                    lower: Sn,
                    upper: wn
                },
                mgDef: {
                    normal: xn,
                    lower: Ar,
                    upper: er
                },
                acc: {
                    normal: Nn,
                    lower: Cr,
                    upper: w
                },
                avo: {
                    normal: F,
                    lower: B,
                    upper: X
                },
                move: {
                    normal: re,
                    lower: $e,
                    upper: Ke
                },
                jump: {
                    normal: It,
                    lower: kt,
                    upper: Vl
                },
                hp: {
                    normal: $l,
                    lower: ln,
                    upper: Hl
                },
                mp: {
                    normal: Bl,
                    lower: zl,
                    upper: Wl
                }
            },
            upgradableCount: Lr,
            attackSpeed: Kl,
            knockBackPercent: Eo
        };
        ue.post(`${ze}/api/item/new`, nr, {
            withCredentials: !0
        }).then(kn => {
            alert("등록성공")
        }).catch(kn => {
            console.log(kn)
        })
    }, tr = T => {
        t(T.target.value)
    }, ql = T => {
        r(T.target.value)
    }, wi = T => {
        l(T.target.value)
    }, Ei = T => {
        i(T.target.value)
    }, xi = T => {
        c(T.target.value)
    }, Ni = T => {
        d(T.target.value)
    }, Yl = T => {
        S(T.target.value)
    }, Ri = T => {
        _(T.target.value)
    }, Rn = T => {
        const nr = T.target.value,
            kn = T.target.checked,
            Mt = { ...R
            };
        nr === "common" ? kn ? Mt.common = !0 : Mt.common = !1 : nr === "warrior" ? kn ? Mt.warrior = !0 : Mt.warrior = !1 : nr === "bowman" ? kn ? Mt.bowman = !0 : Mt.bowman = !1 : nr === "magician" ? kn ? Mt.magician = !0 : Mt.magician = !1 : nr === "thief" && (kn ? Mt.thief = !0 : Mt.thief = !1), p(Mt)
    }, ki = T => {
        h(T.target.value)
    }, Ql = T => {
        k(T.target.value)
    }, Ai = T => {
        L(T.target.value)
    }, Ti = T => {
        oe(T.target.value)
    }, ji = T => {
        ge(T.target.value)
    }, Ci = T => {
        de(T.target.value)
    }, Li = T => {
        Xe(T.target.value)
    }, Di = T => {
        Ve(T.target.value)
    }, Xl = T => {
        Y(T.target.value)
    }, Jl = T => {
        q(T.target.value)
    }, K = T => {
        P(T.target.value)
    }, le = T => {
        Q(T.target.value)
    }, ae = T => {
        ne(T.target.value)
    }, U = T => {
        G(T.target.value)
    }, sn = T => {
        Se(T.target.value)
    }, Zl = T => {
        he(T.target.value)
    }, Ny = T => {
        ee(T.target.value)
    }, Ry = T => {
        Ee(T.target.value)
    }, ky = T => {
        rn(T.target.value)
    }, Ay = T => {
        Rt(T.target.value)
    }, Ty = T => {
        Rr(T.target.value)
    }, jy = T => {
        En(T.target.value)
    }, Cy = T => {
        kr(T.target.value)
    }, Ly = T => {
        Tr(T.target.value)
    }, Dy = T => {
        wo(T.target.value)
    }, Py = T => {
        fi(T.target.value)
    }, Oy = T => {
        mi(T.target.value)
    }, by = T => {
        pi(T.target.value)
    }, Iy = T => {
        hi(T.target.value)
    }, My = T => {
        jr(T.target.value)
    }, Uy = T => {
        N(T.target.value)
    }, Fy = T => {
        j(T.target.value)
    }, Vy = T => {
        V(T.target.value)
    }, $y = T => {
        J(T.target.value)
    }, Hy = T => {
        Z(T.target.value)
    }, By = T => {
        _e(T.target.value)
    }, zy = T => {
        Le(T.target.value)
    }, Wy = T => {
        Je(T.target.value)
    }, Ky = T => {
        Kt(T.target.value)
    }, Gy = T => {
        on(T.target.value)
    }, qy = T => {
        di(T.target.value)
    }, Yy = T => {
        vi(T.target.value)
    }, Qy = T => {
        gi(T.target.value)
    }, Xy = T => {
        _i(T.target.value)
    }, Jy = T => {
        yi(T.target.value)
    }, Zy = T => {
        Gl(T.target.value)
    };
    return a.jsxs(a.Fragment, {
        children: [a.jsx("h1", {
            className: "text-center mt-3 mb-3",
            children: "아이템 등록"
        }), a.jsx("form", {
            onSubmit: Si,
            children: a.jsxs("div", {
                className: "container d-grid gap-2",
                children: [a.jsxs("div", {
                    className: "row",
                    children: [a.jsxs("div", {
                        className: "col-6",
                        children: [a.jsx("label", {
                            htmlFor: "item-id",
                            className: "form-label",
                            children: "아이템 ID"
                        }), a.jsx("input", {
                            type: "text",
                            id: "item-id",
                            className: "form-control form-control-sm",
                            value: e,
                            onChange: tr
                        })]
                    }), a.jsxs("div", {
                        className: "col-6",
                        children: [a.jsx("label", {
                            htmlFor: "item-name",
                            className: "form-label",
                            children: "아이템 이름"
                        }), a.jsx("input", {
                            type: "text",
                            id: "item-name",
                            className: "form-control form-control-sm",
                            value: n,
                            onChange: ql
                        })]
                    })]
                }), a.jsx("div", {
                    className: "justify-content-start",
                    children: a.jsxs("div", {
                        className: "col-4",
                        children: [a.jsx("label", {
                            htmlFor: "required-level",
                            className: "form-label",
                            children: "요구레벨"
                        }), a.jsx("input", {
                            type: "text",
                            id: "required-level",
                            className: "form-control form-control-sm",
                            value: o,
                            onChange: wi
                        })]
                    })
                }), a.jsxs("div", {
                    className: "row",
                    children: [a.jsxs("div", {
                        className: "col-2",
                        children: [a.jsx("label", {
                            htmlFor: "required-str",
                            className: "form-label",
                            children: "요구 STR"
                        }), a.jsx("input", {
                            type: "text",
                            id: "required-str",
                            className: "form-control form-control-sm",
                            value: s,
                            onChange: Ei
                        })]
                    }), a.jsxs("div", {
                        className: "col-2",
                        children: [a.jsx("label", {
                            htmlFor: "required-dex",
                            className: "form-label",
                            children: "요구 DEX"
                        }), a.jsx("input", {
                            type: "text",
                            id: "required-dex",
                            className: "form-control form-control-sm",
                            value: u,
                            onChange: xi
                        })]
                    }), a.jsxs("div", {
                        className: "col-2",
                        children: [a.jsx("label", {
                            htmlFor: "required-int",
                            className: "form-label",
                            children: "요구 INT"
                        }), a.jsx("input", {
                            type: "text",
                            id: "required-int",
                            className: "form-control form-control-sm",
                            value: f,
                            onChange: Ni
                        })]
                    }), a.jsxs("div", {
                        className: "col-2",
                        children: [a.jsx("label", {
                            htmlFor: "required-luk",
                            className: "form-label",
                            children: "요구 LUK"
                        }), a.jsx("input", {
                            type: "text",
                            id: "required-luk",
                            className: "form-control form-control-sm",
                            value: g,
                            onChange: Yl
                        })]
                    }), a.jsxs("div", {
                        className: "col-2",
                        children: [a.jsx("label", {
                            htmlFor: "required-pop",
                            className: "form-label",
                            children: "요구 POP"
                        }), a.jsx("input", {
                            type: "text",
                            id: "required-pop",
                            className: "form-control form-control-sm",
                            value: v,
                            onChange: Ri
                        })]
                    })]
                }), a.jsx("label", {
                    htmlFor: "required-job",
                    className: "form-label mt-2",
                    children: "요구 직업"
                }), a.jsxs("section", {
                    id: "required-job",
                    children: [a.jsx(Uo, {
                        name: "공통",
                        jobId: "common_job_id",
                        value: "common",
                        selectHandler: Rn
                    }), a.jsx(Uo, {
                        name: "전사",
                        jobId: "warrior_job_id",
                        value: "warrior",
                        selectHandler: Rn
                    }), a.jsx(Uo, {
                        name: "궁수",
                        jobId: "bowman_job_id",
                        value: "bowman",
                        selectHandler: Rn
                    }), a.jsx(Uo, {
                        name: "마법사",
                        jobId: "magician_job_id",
                        value: "magician",
                        selectHandler: Rn
                    }), a.jsx(Uo, {
                        name: "도적",
                        jobId: "theif_job_id",
                        value: "thief",
                        selectHandler: Rn
                    })]
                }), a.jsx("div", {
                    className: "row justify-content-start text-start",
                    children: a.jsxs("div", {
                        className: "col-12",
                        children: [a.jsx("label", {
                            htmlFor: "required-job-select",
                            className: "form-label",
                            children: "장비 분류"
                        }), a.jsxs("select", {
                            id: "required-job-select",
                            className: "form-select form-select-sm",
                            "aria-label": "job select",
                            onChange: ki,
                            value: m,
                            children: [a.jsx("option", {
                                value: "ONE_HANDED_SWORD",
                                children: "한손검"
                            }), a.jsx("option", {
                                value: "TWO_HANDED_SWORD",
                                children: "두손검"
                            }), a.jsx("option", {
                                value: "ONE_HANDED_AXE",
                                children: "한손도끼"
                            }), a.jsx("option", {
                                value: "TWO_HANDED_AXE",
                                children: "두손도끼"
                            }), a.jsx("option", {
                                value: "ONE_HANDED_BLUNT",
                                children: "한손둔기"
                            }), a.jsx("option", {
                                value: "TWO_HANDED_BLUNT",
                                children: "두손둔기"
                            }), a.jsx("option", {
                                value: "SPEAR",
                                children: "창"
                            }), a.jsx("option", {
                                value: "POLEARM",
                                children: "폴암"
                            }), a.jsx("option", {
                                value: "BOW",
                                children: "활"
                            }), a.jsx("option", {
                                value: "CROSSBOW",
                                children: "석궁"
                            }), a.jsx("option", {
                                value: "WAND",
                                children: "완드"
                            }), a.jsx("option", {
                                value: "STAFF",
                                children: "스태프"
                            }), a.jsx("option", {
                                value: "DAGGER",
                                children: "단검"
                            }), a.jsx("option", {
                                value: "CLAW",
                                children: "아대"
                            }), a.jsx("option", {
                                value: "HAT",
                                children: "모자"
                            }), a.jsx("option", {
                                value: "GLOVES",
                                children: "장갑"
                            }), a.jsx("option", {
                                value: "SHOES",
                                children: "신발"
                            }), a.jsx("option", {
                                value: "OVERALL",
                                children: "전신"
                            }), a.jsx("option", {
                                value: "TOP",
                                children: "상의"
                            }), a.jsx("option", {
                                value: "BOTTOM",
                                children: "하의"
                            }), a.jsx("option", {
                                value: "SHIELD",
                                children: "방패"
                            }), a.jsx("option", {
                                value: "EARRING",
                                children: "귀고리"
                            }), a.jsx("option", {
                                value: "CAPE",
                                children: "망토"
                            })]
                        })]
                    })
                }), a.jsx("section", {
                    className: "row",
                    children: a.jsxs("div", {
                        className: "col-12",
                        children: [a.jsx("label", {
                            htmlFor: "upgradable-count-select",
                            className: "form-label",
                            children: "공격 속도"
                        }), a.jsxs("select", {
                            id: "upgradable-count-select",
                            className: "form-select form-select-sm",
                            "aria-label": "job select",
                            onChange: Jy,
                            value: Kl,
                            children: [a.jsx("option", {
                                value: "NONE",
                                children: "-- 없음 --"
                            }), a.jsx("option", {
                                value: "VERY_SLOW",
                                children: "매우 느림"
                            }), a.jsx("option", {
                                value: "SLOW",
                                children: "느림"
                            }), a.jsx("option", {
                                value: "NORMAL",
                                children: "보통"
                            }), a.jsx("option", {
                                value: "FAST",
                                children: "빠름"
                            }), a.jsx("option", {
                                value: "VERY_FAST",
                                children: "매우 빠름"
                            })]
                        })]
                    })
                }), a.jsxs("section", {
                    className: "row justify-content-start text-start",
                    children: [a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-str",
                                className: "form-label",
                                children: "STR"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-str",
                                className: "form-control form-control-sm",
                                value: x,
                                onChange: Ql
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-str-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-str-lower",
                                className: "form-control form-control-sm",
                                value: C,
                                onChange: Ai
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-str-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-str-upper",
                                className: "form-control form-control-sm",
                                value: M,
                                onChange: Ti
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-dex",
                                className: "form-label",
                                children: "DEX"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-dex",
                                className: "form-control form-control-sm",
                                value: H,
                                onChange: ji
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-dex-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-dex-lower",
                                className: "form-control form-control-sm",
                                value: Ue,
                                onChange: Ci
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-dex-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-dex-upper",
                                className: "form-control form-control-sm",
                                value: Ne,
                                onChange: Li
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-intel",
                                className: "form-label",
                                children: "INT"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-intel",
                                className: "form-control form-control-sm",
                                value: Re,
                                onChange: Di
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-intel-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-intel-lower",
                                className: "form-control form-control-sm",
                                value: I,
                                onChange: Xl
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-intel-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-intel-upper",
                                className: "form-control form-control-sm",
                                value: b,
                                onChange: Jl
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-luk",
                                className: "form-label",
                                children: "LUK"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-luk",
                                className: "form-control form-control-sm",
                                value: E,
                                onChange: K
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-luk-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-luk-lower",
                                className: "form-control form-control-sm",
                                value: O,
                                onChange: le
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-luk-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-luk-upper",
                                className: "form-control form-control-sm",
                                value: $,
                                onChange: ae
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-phyAtk",
                                className: "form-label",
                                children: "공격력"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-phyAtk",
                                className: "form-control form-control-sm",
                                value: te,
                                onChange: U
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-phyAtk-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-phyAtk-lower",
                                className: "form-control form-control-sm",
                                value: me,
                                onChange: sn
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-phyAtk-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-phyAtk-upper",
                                className: "form-control form-control-sm",
                                value: ce,
                                onChange: Zl
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mgAtk",
                                className: "form-label",
                                children: "마력"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mgAtk",
                                className: "form-control form-control-sm",
                                value: W,
                                onChange: Ny
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mgAtk-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mgAtk-lower",
                                className: "form-control form-control-sm",
                                value: ye,
                                onChange: Ry
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mgAtk-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mgAtk-upper",
                                className: "form-control form-control-sm",
                                value: yt,
                                onChange: ky
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-phyDef",
                                className: "form-label",
                                children: "물리방어력"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-phyDef",
                                className: "form-control form-control-sm",
                                value: ct,
                                onChange: Ay
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-phyDef-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-phyDef-lower",
                                className: "form-control form-control-sm",
                                value: Sn,
                                onChange: Ty
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-phyDef-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-phyDef-upper",
                                className: "form-control form-control-sm",
                                value: wn,
                                onChange: jy
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mgDef",
                                className: "form-label",
                                children: "마법방어력"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mgDef",
                                className: "form-control form-control-sm",
                                value: xn,
                                onChange: Cy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mgDef-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mgDef-lower",
                                className: "form-control form-control-sm",
                                value: Ar,
                                onChange: Ly
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mgDef-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mgDef-upper",
                                className: "form-control form-control-sm",
                                value: er,
                                onChange: Dy
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-acc",
                                className: "form-label",
                                children: "명중률"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-acc",
                                className: "form-control form-control-sm",
                                value: Nn,
                                onChange: My
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-acc-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-acc-lower",
                                className: "form-control form-control-sm",
                                value: Cr,
                                onChange: Uy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-acc-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-acc-upper",
                                className: "form-control form-control-sm",
                                value: w,
                                onChange: Fy
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-acc",
                                className: "form-label",
                                children: "회피율"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-acc",
                                className: "form-control form-control-sm",
                                value: F,
                                onChange: Vy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-acc-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-acc-lower",
                                className: "form-control form-control-sm",
                                value: B,
                                onChange: $y
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-acc-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-acc-upper",
                                className: "form-control form-control-sm",
                                value: X,
                                onChange: Hy
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-move",
                                className: "form-label",
                                children: "이동속도"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-move",
                                className: "form-control form-control-sm",
                                value: re,
                                onChange: By
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-move-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-move-lower",
                                className: "form-control form-control-sm",
                                value: $e,
                                onChange: zy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-move-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-move-upper",
                                className: "form-control form-control-sm",
                                value: Ke,
                                onChange: Wy
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-jump",
                                className: "form-label",
                                children: "점프력"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-jump",
                                className: "form-control form-control-sm",
                                value: It,
                                onChange: Ky
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-jump-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-jump-lower",
                                className: "form-control form-control-sm",
                                value: kt,
                                onChange: Gy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-jump-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-jump-upper",
                                className: "form-control form-control-sm",
                                value: Vl,
                                onChange: qy
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-hp",
                                className: "form-label",
                                children: "HP"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-hp",
                                className: "form-control form-control-sm",
                                value: $l,
                                onChange: Py
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-hp-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-hp-lower",
                                className: "form-control form-control-sm",
                                value: ln,
                                onChange: Oy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-hp-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-hp-upper",
                                className: "form-control form-control-sm",
                                value: Hl,
                                onChange: by
                            })]
                        })]
                    }), a.jsxs("div", {
                        className: "row",
                        children: [a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mp",
                                className: "form-label",
                                children: "MP"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mp",
                                className: "form-control form-control-sm",
                                value: Bl,
                                onChange: Iy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mp-lower",
                                className: "form-label",
                                children: "하옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mp-lower",
                                className: "form-control form-control-sm",
                                value: zl,
                                onChange: Yy
                            })]
                        }), a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-mp-upper",
                                className: "form-label",
                                children: "상옵"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-mp-upper",
                                className: "form-control form-control-sm",
                                value: Wl,
                                onChange: Qy
                            })]
                        })]
                    }), a.jsx("div", {
                        className: "row",
                        children: a.jsxs("div", {
                            className: "col-2",
                            children: [a.jsx("label", {
                                htmlFor: "item-knockBack",
                                className: "form-label",
                                children: "타격 넉백 확률"
                            }), a.jsx("input", {
                                type: "text",
                                id: "item-knockBack",
                                className: "form-control form-control-sm",
                                value: Eo,
                                onChange: Zy
                            })]
                        })
                    })]
                }), a.jsx("section", {
                    className: "row",
                    children: a.jsxs("div", {
                        className: "col-12",
                        children: [a.jsx("label", {
                            htmlFor: "upgradable-count-select",
                            className: "form-label",
                            children: "업그레이드 가능 횟수"
                        }), a.jsxs("select", {
                            id: "upgradable-count-select",
                            className: "form-select form-select-sm",
                            "aria-label": "job select",
                            onChange: Xy,
                            value: Lr,
                            children: [a.jsx("option", {
                                value: 0,
                                children: "0"
                            }), a.jsx("option", {
                                value: 5,
                                children: "5"
                            }), a.jsx("option", {
                                value: 7,
                                children: "7"
                            }), a.jsx("option", {
                                value: 10,
                                children: "10"
                            })]
                        })]
                    })
                }), a.jsx("button", {
                    className: "btn btn-success btn-sm mb-3 mt-3",
                    type: "submit",
                    children: "등록"
                })]
            })
        })]
    })
}

function bC() {
    const e = Cm(oi);
    return Cm(ri), e === "ADMIN" ? a.jsx(mA, {}) : a.jsx(fA, {
        to: "/"
    })
}

function IC() {
    const [e, t] = y.useState([]), n = y.useRef([]);
    y.useEffect(() => {
        ue.get(`${ze}/api/manage/report-comments`, {
            withCredentials: !0
        }).then(s => {
            t(s.data.reports.comments)
        }).catch(s => {
            console.log(s)
        })
    }, []);

    function r() {
        console.log("handleCommentDeleteClicked");
        const s = [];
        n.current.forEach(i => {
            s.push(i.commentId)
        }), ue.delete(`${ze}/api/manage/report-comments`, {
            data: {
                comments: {
                    ids: s
                }
            }
        }, {
            withCredentials: !0
        }).then(i => {
            const u = [...e],
                c = [];
            u.forEach(f => {
                const d = f.commentId;
                s.includes(d) || c.push(f)
            }), t(c)
        }).catch(i => {
            console.log(i)
        })
    }

    function o() {
        console.log("handleReportDeleteClicked");
        const s = [];
        n.current.forEach(i => {
            s.push(i.reportId)
        }), ue.delete(`${ze}/api/manage/report-comments/list`, {
            data: {
                reports: {
                    ids: s
                }
            }
        }, {
            withCredentials: !0
        }).then(i => {
            const u = [...e],
                c = [];
            u.forEach(f => {
                const d = f.reportId;
                s.includes(d) || c.push(f)
            }), t(c)
        }).catch(i => {
            console.log(i)
        })
    }

    function l(s, i, u) {
        if (s) {
            const c = {
                commentId: i,
                reportId: u
            };
            n.current = [...n.current, c], console.log(n.current)
        } else n.current = n.current.filter(c => (console.log(`elem.reportId = ${c.reportId}, reportId = ${u}`), c.reportId != u)), console.log(n.current)
    }
    return a.jsx(a.Fragment, {
        children: a.jsxs("main", {
            className: "py-3 px-3",
            children: [a.jsx("h3", {
                className: "text-center",
                children: "신고댓글 관리"
            }), a.jsx("section", {
                children: a.jsx("div", {
                    className: "my-2",
                    children: a.jsxs("div", {
                        children: [a.jsx("button", {
                            type: "button",
                            className: "btn btn-danger btn-sm me-2",
                            onClick: r,
                            children: "댓글 삭제"
                        }), a.jsx("button", {
                            type: "button",
                            className: "btn btn-success btn-sm",
                            onClick: o,
                            children: "신고 삭제"
                        })]
                    })
                })
            }), a.jsx("section", {
                className: "table-responsive",
                children: a.jsxs("table", {
                    className: "table table-striped",
                    children: [a.jsx("thead", {
                        className: "table-light",
                        children: a.jsxs("tr", {
                            children: [a.jsx("th", {
                                className: "text-center text-nowrap",
                                children: "선택"
                            }), a.jsx("th", {
                                className: "text-nowrap text-center",
                                children: "신고ID"
                            }), a.jsx("th", {
                                className: "text-nowrap text-center",
                                children: "댓글ID"
                            }), a.jsx("th", {
                                className: "text-nowrap",
                                children: "이름"
                            }), a.jsx("th", {
                                className: "text-nowrap",
                                children: "내용"
                            }), a.jsx("th", {
                                className: "text-nowrap",
                                children: "작성일"
                            }), a.jsx("th", {
                                className: "text-nowrap text-center",
                                children: "신고횟수"
                            })]
                        })
                    }), a.jsx("tbody", {
                        children: e == null ? void 0 : e.map(s => a.jsxs("tr", {
                            children: [a.jsx("td", {
                                className: "text-center text-nowrap",
                                children: a.jsx("input", {
                                    className: "form-check-input checkbox-lg",
                                    type: "checkbox",
                                    "aria-label": "...",
                                    defaultChecked: !1,
                                    onChange: i => l(i.target.checked, s.commentId, s.reportId)
                                })
                            }), a.jsx("td", {
                                className: "text-nowrap text-center",
                                children: s.reportId
                            }), a.jsx("td", {
                                className: "text-nowrap text-center",
                                children: s.commentId
                            }), a.jsx("td", {
                                className: "text-nowrap",
                                children: s.name
                            }), a.jsx("td", {
                                children: s.content
                            }), a.jsx("td", {
                                className: "text-nowrap",
                                children: wC(s.createdDate)
                            }), a.jsx("td", {
                                className: "text-nowrap text-center text-danger",
                                children: a.jsx("b", {
                                    children: s.count
                                })
                            })]
                        }, `${s.reportId}_${s.commentId}`))
                    })]
                })
            })]
        })
    })
}

function MC() {
    return a.jsx(a.Fragment, {
        children: a.jsxs(hA, {
            children: [a.jsx(lr, {
                path: "/",
                element: a.jsx($T, {})
            }), a.jsx(lr, {
                path: "/login",
                element: a.jsx(HT, {})
            }), a.jsx(lr, {
                path: "/item/:itemId",
                element: a.jsx(PC, {})
            }), a.jsxs(lr, {
                element: a.jsx(bC, {}),
                children: [a.jsx(lr, {
                    element: a.jsx(OC, {}),
                    path: "/manage/item/new",
                    exact: !0
                }), a.jsx(lr, {
                    element: a.jsx(IC, {}),
                    path: "/manage/comment",
                    exact: !0
                })]
            })]
        })
    })
}

function UC() {
    const e = Lm(oi),
        t = Lm(ri);
    return y.useEffect(() => {
        const r = setInterval(async () => {
            console.log("session check");
            try {
                const o = await ue.get(`${ze}/api/auth/check`);
                e(o.data.role), o.data.role === xc ? t(!1) : t(!0)
            } catch {
                e(xc), t(!1)
            }
        }, 3e5);
        return () => {
            clearInterval(r)
        }
    }, [e, t]), null
}

function FC() {
    return a.jsx(a.Fragment, {
        children: a.jsxs(gk, {
            children: [a.jsx(UC, {}), a.jsx(PT, {}), a.jsx(MC, {})]
        })
    })
}
ue.defaults.withCredentials = !0;
wu.createRoot(document.getElementById("root")).render(a.jsx(yA, {
    children: a.jsxs("div", {
        className: "row gongnomok-global",
        children: [a.jsx("div", {
            className: "col col-lg-0 col-xxl-2"
        }), a.jsx("div", {
            className: "col-lg-12 col-xxl-8",
            children: a.jsx(FC, {})
        }), a.jsx("div", {
            className: "col-lg-0 col-xxl-2"
        })]
    })
}));