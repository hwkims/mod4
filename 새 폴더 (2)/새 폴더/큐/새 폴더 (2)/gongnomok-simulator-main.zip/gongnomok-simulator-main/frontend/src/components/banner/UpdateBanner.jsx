export default function UpdateBanner() {
  return (
    <>
    </>
  )
}