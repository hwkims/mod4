// export const BASE_URI = "http://localhost:8080" // 로컬 HTTP주소
export const BASE_URI = "https://gongnomok.site" // 운영 서버 주소
// export const BASE_URI = "https://dev.gongnomok.site" // 개발 서버 주소
// export const BASE_URI = "http://35.216.38.200"