export default function FeedbackBanner() {
  return (
    <>
      <div className="feedback-banner-root banner">
        버그, 건의사항은 <a href="https://forms.gle/Wsf2tfZz9xfDJyat8">[링크]</a>로 부탁드립니다
      </div>
    </>
  );
}