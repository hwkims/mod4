export const GUEST = "GUEST"
export const USER = "USER"
export const ADMIN = "ADMIN"
