export default function InformBanner() {
  return (
    <>
      <div className="inform-banner-root banner">
        <div>5/15 ~ 최고기록이 초기화 되었습니다</div>
      </div>
    </>
  )
}