export const INIT_COMMENT_FORM = {
  name: "",
  password: "",
  content: "",
}

export const INIT_COMMENT_DELETE_FORM = {
  commentId: null,
  password: ""
}

export const INIT_COMMENT_REPORT_FORM = {
  commentId: null
}

export const DEFAULT_COMMENT_FETCH_SIZE = 20;