export const DEFAULT_ITEM_CONDITION = {
  name: "",
  job: null,
  minLevel: 0,
  category: null
}