// let animationTimer = 0;

// const successGifPath = '/images/gif/success.gif';
// const failureGifPath = '/images/gif/failure.gif';

// export function playSuccessEffect() {
//   // clearTimeout(animationTimer);
//   // // let gifImg = document.getElementById('holy-cross-earring-intel-gif-img');
//   // // 이곳에 새로운 경로를 넣어야 함
  
//   // gifImg.hidden = false;
//   // gifImg.src = successGifPath;
//   // animationTimer = setTimeout(function () {
//   //     // gifImg.src = holyCrossEarringIntelImgPath
//   //     gifImg.hidden = true;
//   // }, 1000);
// }

// export function playFailureEffect() {
//   // clearTimeout(animationTimer);
//   // // let gifImg = document.getElementById('holy-cross-earring-intel-gif-img');
//   // gifImg.hidden = false;
//   // gifImg.src = failureGifPath;
//   // animationTimer = setTimeout(function () {
//   //     // gifImg.src = holyCrossEarringIntelImgPath
//   //     gifImg.hidden = true;
//   // }, 1000);
// }