export const INITIAL_SEARCH_CONDITION = {
  name: "",
  jobs: {
    warrior: false,
    bowman: false,
    magician: false,
    thief: false
  },
  minLevel: 0,
  category: "ALL"
}