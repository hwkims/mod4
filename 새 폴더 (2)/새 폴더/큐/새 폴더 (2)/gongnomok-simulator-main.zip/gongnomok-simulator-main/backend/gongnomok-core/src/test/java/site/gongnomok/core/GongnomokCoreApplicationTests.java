package site.gongnomok.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GongnomokCoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
