package site.gongnomok.core.banword.fetcher;

import java.util.List;

/**
 *
 * @author Jaehoon So
 * @version 1.0.0
 */
public interface BanWordFetcher {

    public List<String> fetchBanWords();

}
