package site.gongnomok.core.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public final class AdminConfirmResponse {

    private final String message;

}
