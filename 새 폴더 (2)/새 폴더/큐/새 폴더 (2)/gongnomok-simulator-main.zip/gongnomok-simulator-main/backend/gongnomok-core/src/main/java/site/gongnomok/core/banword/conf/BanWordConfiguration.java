package site.gongnomok.core.banword.conf;


import org.springframework.context.annotation.Configuration;

@Configuration
public class BanWordConfiguration {
}
