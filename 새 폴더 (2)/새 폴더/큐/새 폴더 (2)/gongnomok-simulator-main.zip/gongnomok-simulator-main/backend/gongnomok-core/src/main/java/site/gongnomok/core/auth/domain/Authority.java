package site.gongnomok.core.auth.domain;

public enum Authority {
    GUEST,
    MEMBER,
    ADMIN,
    MASTER
}
