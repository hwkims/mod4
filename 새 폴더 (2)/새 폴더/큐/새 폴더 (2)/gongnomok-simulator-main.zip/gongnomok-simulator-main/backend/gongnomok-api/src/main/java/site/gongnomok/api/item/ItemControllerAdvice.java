package site.gongnomok.api.item;


import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@Slf4j
@RestControllerAdvice(assignableTypes = ItemController.class)
public class ItemControllerAdvice {
}
