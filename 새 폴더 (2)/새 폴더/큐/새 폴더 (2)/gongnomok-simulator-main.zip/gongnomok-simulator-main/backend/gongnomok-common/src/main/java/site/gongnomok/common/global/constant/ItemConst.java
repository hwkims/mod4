package site.gongnomok.common.global.constant;

public class ItemConst {

    public static final long RANKING_ITEM_NUMBER = 5;

}
