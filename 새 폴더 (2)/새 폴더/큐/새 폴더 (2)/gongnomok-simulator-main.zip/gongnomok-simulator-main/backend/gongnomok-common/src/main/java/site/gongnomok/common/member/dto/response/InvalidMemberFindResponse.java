package site.gongnomok.common.member.dto.response;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class InvalidMemberFindResponse {
    private String message;
}
