package site.gongnomok.common.enhanceditem.dto.response;

public enum EnhanceResult {
    SUCCESS, FAIL
}
