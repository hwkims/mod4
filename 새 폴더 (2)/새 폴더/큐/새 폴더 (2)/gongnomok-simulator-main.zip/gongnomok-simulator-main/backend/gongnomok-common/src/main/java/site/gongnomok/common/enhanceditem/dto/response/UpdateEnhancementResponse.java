package site.gongnomok.common.enhanceditem.dto.response;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class UpdateEnhancementResponse {

    public EnhanceResult status;

}
