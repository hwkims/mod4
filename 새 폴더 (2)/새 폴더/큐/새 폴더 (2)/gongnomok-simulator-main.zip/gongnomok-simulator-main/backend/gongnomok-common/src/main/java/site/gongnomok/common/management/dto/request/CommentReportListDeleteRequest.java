package site.gongnomok.common.management.dto.request;


import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class CommentReportListDeleteRequest {

    private CommentReportIdList reports;
}
