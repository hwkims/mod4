package site.gongnomok.common.member.constant;

public class MemberConst {
    public static final String loginMember = "LOGIN_MEMBER";
}
