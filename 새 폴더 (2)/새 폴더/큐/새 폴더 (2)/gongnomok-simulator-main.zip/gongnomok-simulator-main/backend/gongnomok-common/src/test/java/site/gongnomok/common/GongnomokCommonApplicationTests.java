package site.gongnomok.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GongnomokCommonApplicationTests {

    @Test
    void contextLoads() {
    }

}
