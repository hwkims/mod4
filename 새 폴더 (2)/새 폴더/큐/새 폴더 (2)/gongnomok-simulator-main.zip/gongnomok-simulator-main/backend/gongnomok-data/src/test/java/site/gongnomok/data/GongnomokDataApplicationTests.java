package site.gongnomok.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GongnomokDataApplicationTests {

    @Test
    void contextLoads() {
    }

}
