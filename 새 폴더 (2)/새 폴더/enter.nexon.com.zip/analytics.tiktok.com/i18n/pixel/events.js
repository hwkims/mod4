window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'test_2_single_track';
window[window["TiktokAnalyticsObject"]]._cc = 'KR';;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = 'b65cdff2-3dbd-11ef-9e7a-ea66368154e1';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnrichIpv6": true,
    "EnrichIpv6V2": false,
    "EventBuilder": true,
    "HistoryObserver": true,
    "Identify": true,
    "Monitor": false,
    "PageData": false,
    "PangleCookieMatching": true,
    "PerformanceInteraction": false,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._aam = {
    "in_form": false,
    "selectors": {
        "[class*=Btn]": 9,
        "[class*=Button]": 11,
        "[class*=btn]": 8,
        "[class*=button]": 10,
        "[id*=Btn]": 14,
        "[id*=Button]": 16,
        "[id*=btn]": 13,
        "[id*=button]": 15,
        "[role*=button]": 12,
        "button[type='button']": 6,
        "button[type='menu']": 7,
        "button[type='reset']": 5,
        "button[type='submit']": 4,
        "input[type='button']": 1,
        "input[type='image']": 2,
        "input[type='submit']": 3
    },
    "exclude_selectors": ["[class*=cancel]", "[role*=cancel]", "[id*=cancel]", "[class*=back]", "[role*=back]", "[id*=back]", "[class*=return]", "[role*=return]", "[id*=return]"],
    "phone_regex": "^\\+?[0-9\\-\\.\\(\\)\\s]{7,25}$",
    "phone_selectors": ["phone", "mobile", "contact", "pn"],
    "restricted_keywords": ["ssn", "unique", "cc", "card", "cvv", "cvc", "cvn", "creditcard", "billing", "security", "social", "pass", "zip", "address", "license", "gender", "health", "age", "nationality", "party", "sex", "political", "affiliation", "appointment", "politics", "family", "parental"]
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
! function() {
    var n = [{
            id: "MWU2NDEzYzJiMA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiMQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiMg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiMw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiNA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiNQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiNg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiNw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !1
            }
        }, {
            id: "MWU2NDEzYzJiOA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiOQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiMTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiMTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !1,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiMTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiMTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiMTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }, {
            id: "MWU2NDEzYzJiMTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                Monitor: !0,
                CompetitorInsight: !0
            }
        }],
        i = {
            "info": {
                "pixelCode": "CNNTUSBC77UCDEI9VO10",
                "name": "넥슨_기업브랜딩",
                "status": 0,
                "setupMode": 0,
                "partner": "",
                "advertiserID": "7345040548425744385",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": {
                    "auto_email": true,
                    "auto_phone_number": true
                },
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {}
                },
                "DiagnosticsConsole": true,
                "PangleCookieMatching": false,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                }
            },
            "rules": []
        },
        t = "https://analytics.tiktok.com/i18n/pixel/static/";

    function o() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function e() {
        return window && window[o()]
    }

    function a(i, t) {
        t = e()[t];
        return t && t[i] || {}
    }
    var d, r, c = e();
    c || (c = [], window && (window[o()] = c)), Object.assign(i, {
        options: a(i.info.pixelCode, "_o")
    }), d = i, c._i || (c._i = {}), (r = d.info.pixelCode) && (c._i[r] || (c._i[r] = []), Object.assign(c._i[r], d), c._i[r]._load = +new Date), Object.assign(i.info, {
        loadStart: a(i.info.pixelCode, "_t"),
        loadEnd: a(i.info.pixelCode, "_i")._load
    }), d = function(i, t, o) {
        var a = 0 < arguments.length && void 0 !== i ? i : {},
            d = 1 < arguments.length ? t : void 0,
            i = 2 < arguments.length ? o : void 0,
            t = function(i, t) {
                for (var o = 0; o < i.length; o++)
                    if (t.call(null, i[o], o)) return i[o]
            }(n, function(i) {
                for (var t = i.map, o = Object.keys(t), n = function(i) {
                        return !(!a[i] || !d[i]) === t[i]
                    }, e = 0; e < o.length; e++)
                    if (!n.call(null, o[e], e)) return !1;
                return !0
            });
        return t ? "".concat(i, "main.").concat(t.id, ".js") : "".concat(i, "main.").concat(n[0].id, ".js")
    }(c._plugins, i.plugins, t), r = i.info.pixelCode, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(d) : ((c = document.createElement("script")).type = "text/javascript", c.async = !0, c.src = d, c.setAttribute("data-id", r), (d = document.getElementsByTagName("script")[0]) && d.parentNode && d.parentNode.insertBefore(c, d))
}();