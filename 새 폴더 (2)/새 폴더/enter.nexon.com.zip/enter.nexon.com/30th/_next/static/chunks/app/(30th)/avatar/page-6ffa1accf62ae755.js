(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [452], {
        897: function(a, e, t) {
            Promise.resolve().then(t.bind(t, 1601))
        },
        6409: function(a, e, t) {
            "use strict";
            t.d(e, {
                J: function() {
                    return s
                }
            });
            var n = t(216),
                r = t(3773);
            let l = {
                male: [{
                    index: "",
                    url: "avatar/male/(male)_01_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_01_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_02_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_02_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_03_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_03_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_04_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_04_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_05_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_05_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_06_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_06_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_07_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_07_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_08_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_08_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_09_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_09_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_10_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_10_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_11_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_11_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_12_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_12_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_13_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_13_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_14_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_14_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_15_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_15_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_16_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_16_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_17_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_17_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }, {
                    index: "",
                    url: "avatar/male/(male)_18_cmodelm.png",
                    type: "avatar",
                    fileUrl: "avatar/male/(male)_18_cmodelm.png",
                    assetKey: "",
                    gender: "male"
                }],
                female: [{
                    index: "",
                    url: "avatar/female/(female)_01_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_01_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_02_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_02_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_03_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_03_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_04_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_04_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_05_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_05_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_06_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_06_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_07_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_07_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_08_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_08_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_09_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_09_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_10_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_10_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_11_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_11_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_12_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_12_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_13_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_13_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_14_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_14_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_15_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_15_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_16_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_16_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_17_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_17_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }, {
                    index: "",
                    url: "avatar/female/(female)_18_cmodelf.png",
                    type: "avatar",
                    fileUrl: "avatar/female/(female)_18_cmodelf.png",
                    assetKey: "",
                    gender: "female"
                }]
            };

            function s() {
                return {
                    async getStoreItems(a) {
                        var e, t;
                        if ("avatar" === a.type) return l[a.gender];
                        let r = await n.I.request({
                            method: "GET",
                            url: "/30th/avatar/items",
                            params: a
                        });
                        return (null !== (t = null == r ? void 0 : null === (e = r.data) || void 0 === e ? void 0 : e.data) && void 0 !== t ? t : {}).items
                    },
                    async getAvatarItem(a) {
                        var e, t;
                        let r = await n.I.request({
                            method: "GET",
                            url: "/30th/avatar/item",
                            params: a
                        });
                        return null !== (t = null == r ? void 0 : null === (e = r.data) || void 0 === e ? void 0 : e.data) && void 0 !== t ? t : {}
                    },
                    saveAvatar: a => n.I.request({
                        method: "POST",
                        url: "/30th/avatar",
                        data: a
                    }),
                    async getAvatar() {
                        var a, e;
                        let t = await n.I.request({
                            method: "GET",
                            url: "/30th/avatar"
                        });
                        return null !== (e = null == t ? void 0 : null === (a = t.data) || void 0 === a ? void 0 : a.data) && void 0 !== e ? e : {}
                    },
                    submitContest(a) {
                        let e = (0, r.W)();
                        return n.I.request({
                            method: "POST",
                            url: "/30th/avatar/contest",
                            data: { ...a,
                                categoryId: e
                            }
                        })
                    }
                }
            }
        },
        1601: function(a, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                default: function() {
                    return I
                }
            });
            var n = t(6063),
                r = t(4617),
                l = t(4673),
                s = t.n(l),
                i = t(3720),
                o = t.n(i),
                v = t(1586),
                m = t(3962),
                c = t(2729),
                _ = t(5145),
                d = t(6409),
                f = t(1280),
                u = t(500),
                g = t(1774),
                p = t(4202),
                x = t(2230),
                h = t(9167),
                y = t(158),
                A = t(9745),
                b = t(992),
                j = t(3773),
                C = t(1003);
            let E = (0, g.default)(() => Promise.all([t.e(198), t.e(161), t.e(921)]).then(t.bind(t, 4921)), {
                    loadableGenerated: {
                        webpack: () => [4921]
                    },
                    ssr: !1
                }),
                N = (0, g.default)(() => Promise.all([t.e(198), t.e(836), t.e(161), t.e(397)]).then(t.bind(t, 3397)), {
                    loadableGenerated: {
                        webpack: () => [3397]
                    },
                    ssr: !1
                }),
                k = s().bind(o()),
                w = [{
                    id: "avatar-maker",
                    text: "아바타 만들기",
                    a2sValue: "Create"
                }, {
                    id: "contest",
                    text: "베스트 드레서 콘테스트",
                    a2sValue: "Bestdresser"
                }, {
                    id: "hall-of-fame",
                    text: "명예의 전당",
                    a2sValue: "HOF"
                }],
                U = "Avatar_Main";

            function K() {
                let a = (0, r.useContext)(v.InfaceContext),
                    e = (0, r.useRef)(null),
                    t = (0, r.useRef)(null),
                    {
                        randomContestItems: l
                    } = (0, p.OM)(),
                    [s, i] = (0, r.useState)(!1),
                    [o, g] = (0, r.useState)(0),
                    [K, q] = (0, r.useState)(!1),
                    [I, S] = (0, r.useState)(""),
                    P = (0, r.useRef)(null),
                    {
                        data: T,
                        mutate: O
                    } = (0, m.ZP)(() => a.loaded ? "saved-avatar-data" : null, async () => {
                        let a = await (0, d.J)().getAvatar();
                        if (null == a || !a.avatarInfo) return null; {
                            let e = null == a ? void 0 : a.avatarInfo;
                            try {
                                return JSON.parse(e)
                            } catch (a) {
                                return null
                            }
                        }
                    }),
                    {
                        data: J,
                        mutate: Z
                    } = (0, m.ZP)(() => a.userProfile ? "my-content" : null, async () => {
                        var e;
                        let {
                            userProfile: t
                        } = a, n = t.local_session_user_id, r = (0, j.W)(), l = await (0, f.V)().getMyContents({
                            guid: n,
                            categoryId: r
                        });
                        return null == l ? void 0 : null === (e = l.data) || void 0 === e ? void 0 : e.data[0]
                    });
                (0, r.useEffect)(() => {
                    window.addEventListener("scroll", function() {
                        if (!e.current || !t.current) return;
                        let a = t.current.getBoundingClientRect();
                        return window.innerHeight - a.y > 100 ? g(2) : e.current.getBoundingClientRect().y < 100 ? g(1) : g(0)
                    })
                }, []), (0, r.useEffect)(() => {
                    (async function() {
                        var a, e, t;
                        let n = sessionStorage.getItem(c.mb);
                        sessionStorage.getItem(c.R0) && (null === (t = window.inface) || void 0 === t ? void 0 : null === (e = t.auth) || void 0 === e ? void 0 : null === (a = e.isSignedIn) || void 0 === a ? void 0 : a.call(e)) && (sessionStorage.removeItem(c.R0), S(n), q(!0), O())
                    })()
                }, [O]);
                let R = async () => {
                    (a.userProfile || await _.lp.openEnterMaker()) && q(!0)
                };
                return (0, r.useEffect)(() => {
                    if (!P.current) return;
                    let a = P.current;
                    x.Z.create(a, {
                        resize: !0
                    }), window.performance.now()
                }, []), (0, n.jsxs)("section", {
                    className: k("avatar-event-container"),
                    children: [(0, n.jsx)(h.Hn, {
                        sharingUrl: "https://enter.nexon.com/30th/avatar",
                        sharingA2S: {
                            object: U,
                            name: "Anchor"
                        },
                        children: w.map((a, e) => (0, n.jsx)(A.Z, {
                            "data-a2s-web-obj": U,
                            "data-a2s-option-name": "Anchor",
                            "data-a2s-option-value": a.a2sValue,
                            "data-a2s-option-pagecode": "65478",
                            children: (0, n.jsx)("a", {
                                className: k("anchor", e === o && "on"),
                                href: "#".concat(a.id),
                                children: a.text
                            })
                        }, a.id))
                    }), (0, n.jsx)("div", {
                        className: k("avatar-main-section"),
                        children: (0, n.jsxs)("div", {
                            className: k("avatar-main-container"),
                            children: [(0, n.jsxs)("div", {
                                className: k("avatar-main-title"),
                                children: [(0, n.jsx)("div", {
                                    className: k("avatar-main-title-star-1")
                                }), (0, n.jsx)("div", {
                                    className: k("avatar-main-title-star-2")
                                }), (0, n.jsx)("div", {
                                    className: k("avatar-main-title-star-3")
                                })]
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-qplay-ui")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-character-01")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-character-02")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-textbox-01")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-textbox-02")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-textbox-03")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-textbox-04")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-main-textbox-05")
                            })]
                        })
                    }), (0, n.jsxs)("div", {
                        className: k("avatar-maker-section"),
                        id: "avatar-maker",
                        children: [(0, n.jsx)("div", {
                            className: k("avatar-maker-event-line-container"),
                            children: Array.from({
                                length: 2
                            }).map((a, e) => (0, n.jsx)("div", {
                                className: k("avatar-maker-event-line")
                            }, e))
                        }), (0, n.jsxs)("div", {
                            className: k("avatar-maker-container"),
                            children: [(0, n.jsx)("div", {
                                className: k("avatar-maker-title")
                            }), (0, n.jsxs)("div", {
                                className: k("avatar-maker-notice"),
                                children: ["* 아바타는 계속 만들 수 있으나, ", (0, n.jsx)("span", {
                                    className: k("mobile-block")
                                }), "콘테스트 제출은 넥슨ID 당 1회만 가능합니다."]
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-balloon-01")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-balloon-02")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-balloon-03")
                            }), (0, n.jsxs)("div", {
                                className: k("avatar-maker-qplay-ui"),
                                children: [!T && (0, n.jsx)(h.Nn, {
                                    className: k("avatar-maker-default-avatar")
                                }), T && (0, n.jsx)("div", {
                                    className: k("avatar-ui-wrapper"),
                                    children: (0, n.jsxs)("div", {
                                        className: k("avatar-ui-container"),
                                        children: [(0, n.jsx)("div", {
                                            className: k("avatar-ui-my-avatar"),
                                            children: (0, n.jsx)(E, {
                                                avatarData: T,
                                                className: k("canvas-container")
                                            }, JSON.stringify(T))
                                        }), (0, n.jsx)("div", {
                                            className: k("avatar-ui-wearing-items-wrapper"),
                                            children: (0, n.jsx)("ul", {
                                                className: k("avatar-ui-wearing-items"),
                                                children: T && Array.from({
                                                    length: 8
                                                }).map((a, e) => {
                                                    var t;
                                                    let r = c.P[e],
                                                        l = null === (t = T[r]) || void 0 === t ? void 0 : t.store;
                                                    return (0, n.jsx)("li", {
                                                        className: k("wearing-item-slot", "wearing-item-".concat(r)),
                                                        children: l && (0, n.jsx)("div", {
                                                            className: k("wearing-item-image-container"),
                                                            children: (0, n.jsx)(b.default, {
                                                                alt: "착용 아이템",
                                                                width: "92",
                                                                height: "102",
                                                                className: k("wearing-item-image"),
                                                                src: (0, u.xn)(c.Wl, l.fileUrl)
                                                            })
                                                        })
                                                    }, r)
                                                })
                                            })
                                        })]
                                    })
                                })]
                            }), (0, n.jsx)(A.Z, {
                                "data-a2s-web-obj": U,
                                "data-a2s-option-name": "Avatar",
                                "data-a2s-option-type": T ? "Edit" : "Create",
                                children: (0, n.jsx)("button", {
                                    className: k("goto-avatar-maker-button", T && "edit-avatar-button"),
                                    onClick: () => {
                                        (0, C.k)("event", "avatar_아바타만들기"), R()
                                    }
                                })
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-textbox-01")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-textbox-02")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-textbox-03")
                            }), (0, n.jsx)("div", {
                                className: k("avatar-maker-character-group")
                            })]
                        })]
                    }), (0, n.jsx)("div", {
                        className: k("contest-section", !(l && l.length > 0) && "no-current-avatar"),
                        id: "contest",
                        ref: e,
                        children: (0, n.jsxs)("div", {
                            className: k("contest-container"),
                            children: [(0, n.jsx)("div", {
                                className: k("contest-title")
                            }), (0, n.jsx)("div", {
                                className: k("contest-item-01")
                            }), (0, n.jsx)("div", {
                                className: k("contest-item-02")
                            }), (0, n.jsx)("div", {
                                className: k("contest-item-03")
                            }), (0, n.jsx)("div", {
                                className: k("contest-item-04")
                            }), (0, n.jsxs)("div", {
                                className: k("contest-tv"),
                                children: [(0, n.jsx)("div", {
                                    className: k("contest-tv-avatar"),
                                    children: J && (0, n.jsx)(b.default, {
                                        alt: "내 아바타",
                                        width: "288",
                                        height: "364",
                                        className: k("contest-tv-my-avatar"),
                                        src: J.thumbnailUrl
                                    })
                                }), !J && (0, n.jsx)("div", {
                                    className: k("contest-tv-bubble")
                                })]
                            }), J ? (0, n.jsx)(A.Z, {
                                "data-a2s-web-obj": U,
                                "data-a2s-option-name": "Bestdresser",
                                "data-a2s-option-type": "My",
                                "data-a2s-option-pagecode": "65478",
                                children: (0, n.jsx)(y.default, {
                                    className: k("contest-my-avatar-button"),
                                    href: "/avatar-contest/items?detail=".concat(J.contentId),
                                    target: "_blank",
                                    children: "제출한 아바타 보러가기"
                                })
                            }) : (0, n.jsx)(A.Z, {
                                "data-a2s-web-obj": U,
                                "data-a2s-option-name": "Bestdresser",
                                "data-a2s-option-type": "Create",
                                "data-a2s-option-pagecode": "65478",
                                children: (0, n.jsx)("button", {
                                    className: k("contest-participate-button"),
                                    onClick: () => {
                                        (0, C.k)("event", "avatar_콘테스트참여하기"), R()
                                    },
                                    children: "아바타 만들고 콘테스트 참여하기"
                                })
                            }), (0, n.jsx)("div", {
                                className: k("contest-notice")
                            }), (0, n.jsxs)("div", {
                                className: k("contest-aqua-avatar-01"),
                                children: [(0, n.jsx)("div", {
                                    className: k("contest-aqua-avatar-textbox-01")
                                }), (0, n.jsx)("div", {
                                    className: k("contest-aqua-avatar-bg-01")
                                }), (0, n.jsx)("div", {
                                    className: k("contest-avatar-01")
                                }), (0, n.jsx)("div", {
                                    className: k("contest-aqua-01")
                                })]
                            }), (0, n.jsxs)("div", {
                                className: k("contest-aqua-avatar-02"),
                                children: [(0, n.jsx)("div", {
                                    className: k("contest-aqua-avatar-bg-02")
                                }), (0, n.jsx)("div", {
                                    className: k("contest-avatar-02")
                                }), (0, n.jsx)("div", {
                                    className: k("contest-aqua-02")
                                })]
                            }), (0, n.jsx)("div", {
                                className: k("contest-gift")
                            }), (0, n.jsxs)("ul", {
                                className: k("contest-gift-announcement"),
                                children: [(0, n.jsx)("li", {
                                    children: "* 차수별 1회에 한해 참여작을 제출할 수 있습니다."
                                }), (0, n.jsx)("li", {
                                    children: "* 추천 수, 명예의 전당 등재 여부와 상관없이 콘테스트 참여 기준으로 추첨이 진행됩니다."
                                }), (0, n.jsx)("li", {
                                    children: "* 당첨자 발표 및 상품 수령에 대한 자세한 내용은 유의사항을 통해 확인하실 수 있습니다."
                                })]
                            }), l && l.length > 0 && (0, n.jsxs)(n.Fragment, {
                                children: [(0, n.jsxs)("div", {
                                    className: k("contest-codi-section"),
                                    children: [(0, n.jsx)("div", {
                                        className: k("contest-current-codi")
                                    }), (0, n.jsxs)("div", {
                                        className: k("contest-codi-list"),
                                        children: [(0, n.jsx)("div", {
                                            className: k("contest-codi-list-item", "contest-empty")
                                        }), (0, n.jsx)("div", {
                                            className: k("contest-codi-list-item", "contest-empty")
                                        }), l.map(a => (0, n.jsx)("div", {
                                            className: k("contest-codi-list-item", "contest-not-empty"),
                                            children: (0, n.jsx)(b.default, {
                                                alt: "다른 코디",
                                                width: "288",
                                                height: "364",
                                                className: k("contest-codi-image"),
                                                src: a.thumbnailUrl
                                            })
                                        }, a.contentId)), (0, n.jsx)("div", {
                                            className: k("contest-codi-list-item", "contest-empty")
                                        }), (0, n.jsx)("div", {
                                            className: k("contest-codi-list-item", "contest-empty")
                                        })]
                                    })]
                                }), (0, n.jsx)(A.Z, {
                                    "data-a2s-web-obj": U,
                                    "data-a2s-option-name": "Contest_Other",
                                    "data-a2s-option-pagecode": "65478",
                                    children: (0, n.jsx)(y.default, {
                                        className: k("goto-contest-button"),
                                        href: "/avatar-contest",
                                        target: "_blank"
                                    })
                                })]
                            })]
                        })
                    }), (0, n.jsxs)("div", {
                        className: k("honor-section", !s && "yet"),
                        id: "hall-of-fame",
                        ref: t,
                        children: [(0, n.jsx)("canvas", {
                            className: k("confetti-canvas"),
                            ref: P
                        }), (0, n.jsxs)("div", {
                            className: k("honor-container"),
                            children: [(0, n.jsx)("div", {
                                className: k("honor-title")
                            }), s && (0, n.jsx)("div", {
                                className: k("honor-list"),
                                children: (0, n.jsx)("div", {
                                    className: k("honor-list-item")
                                })
                            }), (0, n.jsx)("div", {
                                className: k("honor-teaser")
                            })]
                        })]
                    }), (0, n.jsxs)("div", {
                        className: k("footer-container"),
                        children: [(0, n.jsx)("div", {
                            className: k("footer-notice")
                        }), (0, n.jsxs)("ul", {
                            className: k("footer-notice-list"),
                            children: [(0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "아바타는 횟수 제한 없이 생성할 수 있으나, 콘테스트 제출은 넥슨ID 당 차수별 1회만 할 수 있습니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "콘테스트 제출 시 넥슨 홈페이지 닉네임과 제출 단계에서 입력한 코디 제목 및 설명이 노출되며 참여 이후에는 정보를 변경 또는 삭제할 수 없습니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "부적절한 닉네임, 코디 제목 및 설명 등이 확인될 경우 제출한 콘테스트 참여작이 삭제될 수 있으며, 삭제 시 재참여할 수 없습니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "비정상적인 방법(타인의 넥슨ID/개인정보 도용 등)으로 이벤트에 참여하거나 보상을 수령할 경우, 추첨에서 제외되거나 당첨이 취소될 수 있습니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "차수별 이벤트 기간에 참여작을 제출한 분들을 대상으로 추첨이 진행됩니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "추첨은 추천 수, 명예의 전당 등재 여부와 상관없이 참여 여부를 기준으로 진행됩니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "추첨 결과는 다음 달 14일 별도 공지사항 및 넥슨쪽지를 통해 안내 드리겠습니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "[1차 콘테스트 당첨 발표일] 2024년 8월 14일(수)"
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "[2차 콘테스트 당첨 발표일] 2024년 9월 14일(토)"
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "1차 콘테스트에서 '온라인 문화상품권 3만원' 당첨 시, 상품 지급을 위한 개인정보 수집이 진행됩니다."
                            }), (0, n.jsx)("li", {
                                className: k("footer-notice-list-item"),
                                children: "상품별 자세한 수령 방법은 당첨 안내 공지사항을 통해 안내 드리겠습니다."
                            })]
                        })]
                    }), (0, n.jsx)("div", {
                        className: k("css-preloader")
                    }), K && (0, n.jsx)(N, {
                        onClose: () => {
                            q(!1), S(""), O(), Z()
                        },
                        tempSavedAvatar: I,
                        userProfile: null == a ? void 0 : a.userProfile
                    })]
                })
            }
            var q = t(6413);

            function I() {
                return (0, q.Z)(), (0, n.jsx)(K, {})
            }
        },
        2729: function(a, e, t) {
            "use strict";
            t.d(e, {
                $h: function() {
                    return s
                },
                JP: function() {
                    return l
                },
                P: function() {
                    return r
                },
                R0: function() {
                    return o
                },
                Wl: function() {
                    return n
                },
                mb: function() {
                    return i
                },
                yg: function() {
                    return v
                }
            });
            let n = "https://enter.nexon.com/qplay-avatar-assets/",
                r = ["hair", "clothes", "eye", "ear", "mouth", "bg", "effect", "wing"],
                l = {
                    avatar: "아바타",
                    hair: "헤어",
                    clothes: "의상",
                    face: "얼굴",
                    eye: "눈",
                    ear: "귀",
                    mouth: "입",
                    bg: "배경",
                    accessory: "소품",
                    effect: "이펙트",
                    wing: "날개"
                },
                s = [{
                    assetType: "avatar"
                }, {
                    assetType: "hair"
                }, {
                    assetType: "clothes"
                }, {
                    assetType: "face",
                    children: [{
                        assetType: "eye"
                    }, {
                        assetType: "ear"
                    }, {
                        assetType: "mouth"
                    }]
                }, {
                    assetType: "bg"
                }, {
                    assetType: "accessory",
                    children: [{
                        assetType: "effect"
                    }, {
                        assetType: "wing"
                    }]
                }],
                i = "tempSavedAvatar",
                o = "requestOpenAvatarModal",
                v = {
                    bg: {
                        depth: 100
                    },
                    wing: {
                        depth: 200
                    },
                    bgDeco: {
                        depth: 300
                    },
                    avatar: {
                        depth: 400
                    },
                    eye: {
                        depth: 500
                    },
                    mouth: {
                        depth: 600
                    },
                    avatarHead: {
                        depth: 700
                    },
                    hair: {
                        depth: 800
                    },
                    clothes: {
                        depth: 900
                    },
                    ear: {
                        depth: 1e3
                    },
                    eye1: {
                        depth: 1100
                    },
                    mouth1: {
                        depth: 1200
                    },
                    bgDesk: {
                        depth: 1300
                    },
                    effect: {
                        depth: 1400
                    }
                }
        },
        6413: function(a, e, t) {
            "use strict";
            var n = t(4617),
                r = t(8254);
            e.Z = function() {
                let a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    {
                        baseScale: e = 1,
                        changeScale: t = .75,
                        targetViewportWidth: l = 1e3
                    } = a;
                (0, n.useEffect)(() => {
                    let a = !1,
                        n = function() {
                            let n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                            try {
                                let {
                                    forceToBase: r = !1
                                } = n, l = document.querySelector("meta[name=viewport]");
                                if (a) {
                                    a = !1;
                                    return
                                }
                                let s = [() => window.innerWidth < 360, () => {
                                    let {
                                        navigator: a
                                    } = window;
                                    return a.userAgent.includes("SM-F")
                                }].some(a => a());
                                s && (a = !0);
                                let i = s ? t : e,
                                    o = r ? e : i;
                                l.setAttribute("content", "width=device-width, initial-scale=".concat(o, ", maximum-scale=").concat(o, ", minimum-scale=").concat(o, ", user-scalable=no"))
                            } catch (a) {
                                r.Tb(a)
                            }
                        };
                    return n(), window.addEventListener("resize", n), () => {
                        window.removeEventListener("resize", n), n({
                            forceToBase: !0
                        })
                    }
                }, [e, t, l])
            }
        },
        3720: function(a) {
            a.exports = {
                "mobile-block": "C_AvatarEvent_mobile-block__D35XD",
                "avatar-event-container": "C_AvatarEvent_avatar-event-container__6WJwV",
                anchor: "C_AvatarEvent_anchor__tyrwR",
                on: "C_AvatarEvent_on__GUgj2",
                "avatar-main-section": "C_AvatarEvent_avatar-main-section__kPLkq",
                "avatar-main-container": "C_AvatarEvent_avatar-main-container__4PmYO",
                "avatar-main-title": "C_AvatarEvent_avatar-main-title__RazJE",
                "avatar-main-title-star-1": "C_AvatarEvent_avatar-main-title-star-1__NVCSW",
                twinkle: "C_AvatarEvent_twinkle__Y2Ix6",
                "avatar-main-title-star-2": "C_AvatarEvent_avatar-main-title-star-2__tO5nu",
                "avatar-main-title-star-3": "C_AvatarEvent_avatar-main-title-star-3__x01Hq",
                "avatar-main-qplay-ui": "C_AvatarEvent_avatar-main-qplay-ui__2BKYr",
                "avatar-main-character-01": "C_AvatarEvent_avatar-main-character-01__KKFbz",
                "avatar-main-character-02": "C_AvatarEvent_avatar-main-character-02__AC3v8",
                "avatar-main-textbox-01": "C_AvatarEvent_avatar-main-textbox-01__XqZIy",
                "malpoongsun-up": "C_AvatarEvent_malpoongsun-up__iOoS5",
                "avatar-main-textbox-02": "C_AvatarEvent_avatar-main-textbox-02__1hggT",
                "avatar-main-textbox-03": "C_AvatarEvent_avatar-main-textbox-03__d_qth",
                "avatar-main-textbox-04": "C_AvatarEvent_avatar-main-textbox-04__Bl_Et",
                "avatar-main-textbox-05": "C_AvatarEvent_avatar-main-textbox-05__Is21S",
                "avatar-maker-section": "C_AvatarEvent_avatar-maker-section__S0Aiz",
                "avatar-maker-event-line-container": "C_AvatarEvent_avatar-maker-event-line-container__2xboT",
                "rolling-banner": "C_AvatarEvent_rolling-banner__1Ytf3",
                "avatar-maker-event-line": "C_AvatarEvent_avatar-maker-event-line__K1AkZ",
                "avatar-maker-container": "C_AvatarEvent_avatar-maker-container__s14sO",
                "avatar-maker-title": "C_AvatarEvent_avatar-maker-title__G7Gm6",
                "avatar-maker-notice": "C_AvatarEvent_avatar-maker-notice__0CSKF",
                "avatar-maker-qplay-ui": "C_AvatarEvent_avatar-maker-qplay-ui__YXrXr",
                "avatar-ui-wrapper": "C_AvatarEvent_avatar-ui-wrapper__rOfIM",
                "avatar-ui-container": "C_AvatarEvent_avatar-ui-container__EjFUt",
                "avatar-ui-my-avatar": "C_AvatarEvent_avatar-ui-my-avatar__21uAg",
                "canvas-container": "C_AvatarEvent_canvas-container__hV703",
                "avatar-ui-wearing-items-wrapper": "C_AvatarEvent_avatar-ui-wearing-items-wrapper__wOiIz",
                "avatar-ui-wearing-items": "C_AvatarEvent_avatar-ui-wearing-items__EJHE9",
                "wearing-item-slot": "C_AvatarEvent_wearing-item-slot___xFTg",
                "wearing-item-image-container": "C_AvatarEvent_wearing-item-image-container__Q7Vy9",
                "wearing-item-image": "C_AvatarEvent_wearing-item-image__DcfcK",
                "avatar-maker-default-avatar": "C_AvatarEvent_avatar-maker-default-avatar__yQt4C",
                "goto-avatar-maker-button": "C_AvatarEvent_goto-avatar-maker-button__Ujp_o",
                "edit-avatar-button": "C_AvatarEvent_edit-avatar-button__Bvbsi",
                "avatar-maker-character-group": "C_AvatarEvent_avatar-maker-character-group__lrJ56",
                "avatar-maker-balloon-01": "C_AvatarEvent_avatar-maker-balloon-01__Q5L_j",
                "doongdoong-balloon-01": "C_AvatarEvent_doongdoong-balloon-01__UXH0v",
                "avatar-maker-balloon-02": "C_AvatarEvent_avatar-maker-balloon-02__SeLnS",
                "doongdoong-balloon-02": "C_AvatarEvent_doongdoong-balloon-02__ra_20",
                "avatar-maker-balloon-03": "C_AvatarEvent_avatar-maker-balloon-03__Va2kf",
                "doongdoong-balloon-03": "C_AvatarEvent_doongdoong-balloon-03__uZL0n",
                "avatar-maker-textbox-01": "C_AvatarEvent_avatar-maker-textbox-01__W_JRt",
                "show-malpoonsun": "C_AvatarEvent_show-malpoonsun__fcQDc",
                "avatar-maker-textbox-02": "C_AvatarEvent_avatar-maker-textbox-02__vjMNT",
                "avatar-maker-textbox-03": "C_AvatarEvent_avatar-maker-textbox-03__ydX_i",
                "contest-section": "C_AvatarEvent_contest-section___JuD_",
                "no-current-avatar": "C_AvatarEvent_no-current-avatar__g3Amr",
                "contest-container": "C_AvatarEvent_contest-container__B5dAl",
                "contest-title": "C_AvatarEvent_contest-title__Vflke",
                "contest-item-01": "C_AvatarEvent_contest-item-01__6Wr10",
                "doongdoong-item": "C_AvatarEvent_doongdoong-item__a7Fer",
                "contest-item-02": "C_AvatarEvent_contest-item-02__iI2Ve",
                "contest-item-03": "C_AvatarEvent_contest-item-03__HgyUi",
                "contest-item-04": "C_AvatarEvent_contest-item-04__QnD3m",
                "contest-tv": "C_AvatarEvent_contest-tv__dyAP_",
                "contest-tv-avatar": "C_AvatarEvent_contest-tv-avatar__XKRwP",
                "contest-tv-my-avatar": "C_AvatarEvent_contest-tv-my-avatar__GoUMM",
                "contest-tv-bubble": "C_AvatarEvent_contest-tv-bubble__Hes0F",
                "contest-my-avatar-button": "C_AvatarEvent_contest-my-avatar-button__HEYLW",
                "contest-participate-button": "C_AvatarEvent_contest-participate-button__3koa5",
                "contest-notice": "C_AvatarEvent_contest-notice__vlM9I",
                "contest-aqua-avatar-01": "C_AvatarEvent_contest-aqua-avatar-01__SPJxS",
                "contest-aqua-avatar-textbox-01": "C_AvatarEvent_contest-aqua-avatar-textbox-01__RZvyf",
                "contest-aqua-avatar-bg-01": "C_AvatarEvent_contest-aqua-avatar-bg-01__24699",
                "contest-avatar-01": "C_AvatarEvent_contest-avatar-01__vP8CN",
                "contest-aqua-01": "C_AvatarEvent_contest-aqua-01__70lQ1",
                "contest-aqua-avatar-02": "C_AvatarEvent_contest-aqua-avatar-02__iF4lM",
                "contest-aqua-avatar-bg-02": "C_AvatarEvent_contest-aqua-avatar-bg-02__8J_nd",
                "contest-avatar-02": "C_AvatarEvent_contest-avatar-02__idx6B",
                "contest-aqua-02": "C_AvatarEvent_contest-aqua-02__45xXf",
                "contest-gift": "C_AvatarEvent_contest-gift__L_zJh",
                "contest-gift-announcement": "C_AvatarEvent_contest-gift-announcement__Wqv7I",
                "contest-codi-section": "C_AvatarEvent_contest-codi-section__K95dl",
                "contest-current-codi": "C_AvatarEvent_contest-current-codi__LHo2w",
                "contest-codi-list": "C_AvatarEvent_contest-codi-list__kRmBG",
                "contest-codi-list-item": "C_AvatarEvent_contest-codi-list-item__yYUlB",
                "contest-empty": "C_AvatarEvent_contest-empty__sc9_h",
                "contest-not-empty": "C_AvatarEvent_contest-not-empty__i5hU9",
                "contest-codi-image": "C_AvatarEvent_contest-codi-image__kkI3r",
                "goto-contest-button": "C_AvatarEvent_goto-contest-button__VMIHR",
                "next-event-notice": "C_AvatarEvent_next-event-notice__edZJm",
                "honor-section": "C_AvatarEvent_honor-section__9uPzP",
                yet: "C_AvatarEvent_yet__lQoyr",
                "honor-container": "C_AvatarEvent_honor-container__ONz66",
                "honor-title": "C_AvatarEvent_honor-title__JUeip",
                "honor-notice": "C_AvatarEvent_honor-notice__YPdV_",
                "honor-list": "C_AvatarEvent_honor-list__yuoKa",
                "honor-list-item": "C_AvatarEvent_honor-list-item__P3fzB",
                "honor-teaser": "C_AvatarEvent_honor-teaser__sdd2H",
                "footer-container": "C_AvatarEvent_footer-container__16xGQ",
                "footer-notice": "C_AvatarEvent_footer-notice__g2x6m",
                "footer-notice-list": "C_AvatarEvent_footer-notice-list__u221C",
                "footer-notice-list-item": "C_AvatarEvent_footer-notice-list-item__ZwhqF",
                "css-preloader": "C_AvatarEvent_css-preloader__QH_AD",
                "confetti-canvas": "C_AvatarEvent_confetti-canvas__OdG5v"
            }
        }
    },
    function(a) {
        a.O(0, [47, 158, 720, 202, 492, 810, 851, 744], function() {
            return a(a.s = 897)
        }), _N_E = a.O()
    }
]);