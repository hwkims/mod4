(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [470], {
        5277: function(n, e, t) {
            Promise.resolve().then(t.bind(t, 8389))
        },
        8389: function(n, e, t) {
            "use strict";
            t.r(e), t.d(e, {
                default: function() {
                    return i
                }
            });
            var u = t(6063),
                o = t(8254),
                r = t(4617);

            function i(n) {
                let {
                    error: e
                } = n;
                return (0, r.useEffect)(() => {
                    o.Tb(e), setTimeout(() => {
                        window.location.href = "https://bulletin.nexon.com/nxk/error.html"
                    }, 300)
                }, [e]), (0, u.jsx)("html", {
                    children: (0, u.jsx)("body", {})
                })
            }
        }
    },
    function(n) {
        n.O(0, [492, 810, 851, 744], function() {
            return n(n.s = 5277)
        }), _N_E = n.O()
    }
]);