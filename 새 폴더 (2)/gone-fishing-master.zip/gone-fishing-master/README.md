GA Project 01

–

# ⬺ GONE FISHING! ⬺
A simple fishing game made with HTML, CSS and Javascript.

You are on a fishing trip for a week and will need to play through 5 days.
For each day, you are required to get a specified score in order to proceed to the next day.

Simply move your cursor to catch the fishes! Rare, purple fishes can get you more points but are much faster.
Avoid obstacles such a trashes, jellyfishes and sharks as each come with their own consequences.

–

↓↓ Play it here ↓↓

https://shirleytwl.github.io/gone-fishing/
