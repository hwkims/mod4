
    
    uV.dV.Gf = "/pluginfree/jsp/nppfs.key.jsp"; // 키발급 경로
    uV.dV.zf = "/pluginfree/jsp/nppfs.remove.jsp"; // 키삭제 경로
    uV.dV.zo = "/pluginfree/jsp/nppfs.keypad.jsp"; // 마우스입력기 페이지
    uV.dV.eP = "/pluginfree/jsp/nppfs.ready.jsp"; // 초기화상태 확인경로 
    uV.dV.Fz = "/pluginfree/jsp/nppfs.install.jsp"; // 설치안내 페이지