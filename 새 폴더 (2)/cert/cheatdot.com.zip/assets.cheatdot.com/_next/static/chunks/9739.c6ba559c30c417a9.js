"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9739], {
        39739: function(n, a, e) {
            e.r(a);
            var r = e(10209);
            e(63959);
            var s = e(28330),
                t = e.n(s),
                u = e(25439),
                c = e.n(u);
            a.default = () => (0, r.jsx)(t(), {
                href: "/auth/login",
                className: [c().btn, c().btn_primary].join(" "),
                children: "로그인"
            })
        }
    }
]);